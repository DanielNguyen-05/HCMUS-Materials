#pragma once
#include<string>

std::string add1(std::string year);
void createClassAccountFromfile(std::string classname);
void createStaffAccount();