#pragma once
#include "user.hpp"

struct AcademicStaff : Users {
    
};
