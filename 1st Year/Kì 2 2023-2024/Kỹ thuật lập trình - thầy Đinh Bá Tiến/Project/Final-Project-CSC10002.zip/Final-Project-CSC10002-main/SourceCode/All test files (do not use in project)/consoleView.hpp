#pragma once
#include <string>

void programInterface();
void chooseRole();
void loginFail();
void staffMainMenu(std::string username);
void changePasswordFail();
void createNewSchoolYear();
void isNOTcreated();

