#pragma once
#include "user.hpp"
#include <string>

void mainMenuOfStaff(std::string name);

void mainMenuOfStudent(std::string name);