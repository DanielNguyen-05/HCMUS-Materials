#pragma once
#include <string>

void homePage();
void programInterface();
void loginFail();
void staffMainMenu(std::string username);
void changePasswordFail();
void createNewSchoolYear();
void isNOTcreated();
void editSchoolYearMenu();
void generalClassMenu();
void inputSchoolYearFail();
void listSchoolYear();
void viewListOfGeneralClass(std::string year);
void inputClassFail();
void editGeneralClassMenu();
void createSchoolYearFail();
void semesterMainMenu();
void inputSemesterFail();
void createSemesterFail();
void createClassFail();
void editSemesterMenu();
void inputCourseFail();
void createCourseFail();
void modifyCourseMenu();
void importStudent();
void inputStudentFail();
void editCoursePointMenu();
void studentChooseYear(std::string username);
void studentMenu();
void studentView();
