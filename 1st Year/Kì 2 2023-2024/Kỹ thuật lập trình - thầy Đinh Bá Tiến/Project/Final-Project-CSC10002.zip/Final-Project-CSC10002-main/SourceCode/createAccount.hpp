#pragma once
#include <string>

void createStudentAccount(std::string username);
void createStaffAccount();
std::string addOne(std::string year);
void createClassAccountFromfile(std::string classname);