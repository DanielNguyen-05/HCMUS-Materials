#include "23127165_HeaderFile_Ex04.hpp"

int main()
{
    int* arr;
    int n;

    inputArray(arr, n);
    int result = findMode(arr, n);
    printMode(result);

    delete[] arr;
    
    return 0;
}