#pragma once

// This is an input function
void inputArray(int* &arr, int &n);

// This is a function to find the mode of the array
int findMode(int* arr, int n);

// This is a function used to print out the mode of the array
void printMode(int result);