#pragma once

// This is an input function
void inputArray(double** &arr, int &n);

// This is a function to find out results as per the question's requirements
void createReport(double** arr, int n, double &result1, double &result2, double &result3);

// This is a function that prints out the report
void printReport(double result1, double result2, double result3);