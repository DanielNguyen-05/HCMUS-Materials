#include "23127165_HeaderFile_Ex09.hpp"
#include <iostream>
#include <iomanip>

void inputArray(double** &arr, int &n)
{
    std::cout << "Input the number of monkeys: ";
    std::cin >> n;
    arr = new double*[n];
    std::cout << "Input the pounds of food each of its " << n << " monkeys eats each day during a typical week:" << "\n";
    for(int i = 0; i < n; i++)
    {
        std::cout << "\n";
        *(arr + i) = new double[7];
        int j = 0;
        for (int j = 0; j < 7; j++)
        {
            switch (j) 
            {
                case 0:
                {
                    std::cout << "Input the pounds of food eaten by the monkey " << i + 1 << " on Monday: ";
                    break;
                }
                case 1:
                {
                    std::cout << "Input the pounds of food eaten by the monkey " << i + 1 << " on Tuesday: ";
                    break;
                }
                case 2:
                {
                    std::cout << "Input the pounds of food eaten by the monkey " << i + 1 << " on Wednesday: ";
                    break;
                }
                case 3:
                {
                    std::cout << "Input the pounds of food eaten by the monkey " << i + 1 << " on Thursday: ";
                    break;
                }
                case 4:
                {
                    std::cout << "Input the pounds of food eaten by the monkey " << i + 1 << " on Friday: ";
                    break;
                }
                case 5:
                {
                    std::cout << "Input the pounds of food eaten by the monkey " << i + 1 << " on Saturday: ";
                    break;
                }
                case 6:
                {
                    std::cout << "Input the pounds of food eaten by the monkey " << i + 1 << " on Sunday: ";
                    break;
                }
            }
            std::cin >> *(*(arr + i) + j);
        } 
    }
}

/* 
Test case:
    Test 1:
        Input: 3 
               1.1 1.1 1.1 1.1 1.1 1.1 1.1 
               2.2 2.2 2.2 2.2 2.2 2.2 2.2 
               3.3 3.3 3.3 3.3 3.3 3.3 3.3 
        Output:     Report: 
               Average amount of food eaten per day by the whole family of monkeys is: 6.60 pounds
               The least amount of food eaten during the week by any one monkey is: 7.70 pounds
               The greatest amount of food eaten during the week by any one monkey is: 23.10 pounds
    Test 2:
        Input: 5 
               10.33 10.33 10.33 10.33 10.33 10.33 10.33 
               7.82 7.82 7.82 7.82 7.82 7.82 7.82 
               9.26 9.26 9.26 9.26 9.26 9.26 9.26
               3.77 3.77 3.77 3.77 3.77 3.77 3.77 
               8.11 8.11 8.11 8.11 8.11 8.11 8.11 
        Output:     Report: 
               Average amount of food eaten per day by the whole family of monkeys is: 39.29 pounds
               The least amount of food eaten during the week by any one monkey is: 26.39 pounds
               The greatest amount of food eaten during the week by any one monkey is: 72.31 pounds 
*/
void createReport(double** arr, int n, double &result1, double &result2, double &result3)
{
    double sum = 0;
    double weekly_sum = 0;
    double least_amount = 9999999.99;
    double greatest_amount = -1.01;

    for (int i = 0; i < n; i++)
    {
        weekly_sum = 0;
        for (int j = 0; j < 7; j++)
        {
            weekly_sum += *(*(arr + i) + j);
        }
        sum += weekly_sum;
        if (least_amount > weekly_sum) least_amount = weekly_sum;
        if (greatest_amount < weekly_sum) greatest_amount = weekly_sum;
    }
    result1 = sum / 7.0;
    result2 = least_amount;
    result3 = greatest_amount;
}

void printReport(double result1, double result2, double result3)
{
    std::cout << "\n" << "\t" << "Report: " << "\n";
    std::cout << "Average amount of food eaten per day by the whole family of monkeys is: " << std::fixed << std::setprecision(2) << result1 << " pounds" << "\n";
    std::cout << "The least amount of food eaten during the week by any one monkey is: " << std::fixed << std::setprecision(2) << result2 << " pounds" << "\n";
    std::cout << "The greatest amount of food eaten during the week by any one monkey is: " << std::fixed << std::setprecision(2) << result3 << " pounds" << "\n";
}