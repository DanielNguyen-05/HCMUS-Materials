#include "23127165_HeaderFile_Ex09.hpp"

int main()
{
    double** arr;
    int n;
    double result1;
    double result2;
    double result3;

    inputArray(arr, n);
    createReport(arr, n, result1, result2, result3);
    printReport(result1, result2, result3);
    
    for (int i = 0; i < n; i++)
    {
        delete[] *(arr + i);
    }
    delete[] arr;
    
    return 0;
}