#include "23127165_HeaderFile_Ex02.hpp"

int main()
{
    int x, y;
    input(&x, &y);
    int result = doSomething(&x, &y);
    print(&x, &y, result);
    
    return 0;
}