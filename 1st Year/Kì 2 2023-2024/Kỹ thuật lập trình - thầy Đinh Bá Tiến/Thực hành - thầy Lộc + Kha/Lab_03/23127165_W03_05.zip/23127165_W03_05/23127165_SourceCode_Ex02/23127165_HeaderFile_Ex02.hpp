#pragma once

// This is the rewrited function using pointers instead of reference variables
int doSomething(int *x, int *y);

// This is the input function to input the value of x and y
void input(int *x, int *y);

// This is the output function to print out the last value of x and y, and the sum of them
void print(int *x, int *y, int result);