#include "23127165_HeaderFile_Ex02.hpp"
#include <iostream>

/*
Test case:
    Test 1:
        Input: 5 10
        Output: 
                After: x = 100, y = 50
                The sum of x and y = 150
    Test 2:
        Input: 3 5
        Output: 
                After: x = 50, y = 30
                The sum of x and y = 80
*/
int doSomething(int *x, int *y)
{
    int temp = *x;
    *x = *y * 10;
    *y = temp * 10; 
    return *x + *y;
}

void input(int *x, int *y)
{
    std::cout << "Input x = ";
    std::cin >> *x;
    std::cout << "Input y = ";
    std::cin >> *y;
}

void print(int *x, int *y, int result)
{
    std::cout << "After: x = " << *x << ", y = " << *y << "\n";
    std::cout << "The sum of x and y = " << result << "\n";
}