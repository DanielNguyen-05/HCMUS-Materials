#include "23127165_HeaderFile_Ex03.hpp"
#include <iostream>
#include <cstring>

/* 
Test case:
    Test 1:
        Input: Dang 
        Output: False
    Test 2:
        Input: DanaD
        Output: True
*/
bool isPalindrome(char* cstr)
{
    char* front = cstr; // the pointer front points to the first character of string
    char* back = cstr + strlen(cstr) - 1; // the pointer back points to the last character of string before null character
    while (front < back)
    {
        if (*front != *back) return false; // If the characters don't match, it's not a palindrome
        front++;                           // Move front pointer backward the string
        back--;                            // Move back pointer fordward in the string
    }
    return true;
}

void input(char* cstr) 
{
    std::cout << "Input a string: ";
    std::cin.getline(cstr, 10000);
}

void print(char* cstr)
{
    if (isPalindrome(cstr) == true) std::cout << "True" << "\n";
    else std::cout << "False" << "\n";
}