#include "23127165_HeaderFile_Ex03.hpp"

int main()
{
    char cstr[10000];
    input(cstr);
    print(cstr);
    
    return 0;
}