#pragma once

// This is a function which checks the string cstr is a palindrome or not.
bool isPalindrome(char* cstr);

// This the input function to input the string cstr
void input(char *cstr);

// This is the output function to print out the string cstr is a palindrome or not
void print(char* cstr);