#include "23127165_HeaderFile_Ex06.hpp"
#include <iostream>

void inputArray(int* &arr, int &n)
{
    std::cout << "Input the size of the array: ";
    std::cin >> n;
    arr = new int[n];
    for (int i = 0; i < n; i++)
    {
        std::cin >> *(arr + i);
    }
}

/* 
Test case:
    Test 1:
        Input: 5
               1 2 3 4 5 
        Output: 1 2 3 4 5 0 0 0 0 0
    Test 2:
        Input: 3 
               9 6 22 
        Output: 9 6 22 0 0 0 
*/
int* doubleArray(int* arr, int n)
{
    int* new_arr = new int[2 * n];
    for (int i = 0; i < n; i++)
    {
        *(new_arr + i) = *(arr + i);
        *(new_arr + i + n) = 0;
    }
    return new_arr;
}

void printArray(int* new_arr, int n)
{
    for (int i = 0; i < 2 * n; i++)
    {
        std::cout << *(new_arr + i) << " ";
    }
}