#include "23127165_HeaderFile_Ex06.hpp"

int main()
{
    int* arr;
    int n;

    inputArray(arr, n);
    int* new_arr = doubleArray(arr, n);
    printArray(new_arr, n);
    
    delete[] arr;
    delete[] new_arr;

    return 0;
}