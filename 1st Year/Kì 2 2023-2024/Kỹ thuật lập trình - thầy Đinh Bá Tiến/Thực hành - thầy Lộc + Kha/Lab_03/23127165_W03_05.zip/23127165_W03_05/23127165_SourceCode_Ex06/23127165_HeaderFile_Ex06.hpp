#pragma once

// This is an input array
void inputArray(int* &arr, int &n);

// This function has been updated as per the question's requirements
int* doubleArray(int* arr, int n);

// This is a function used to print out the array
void printArray(int* new_arr, int n);
