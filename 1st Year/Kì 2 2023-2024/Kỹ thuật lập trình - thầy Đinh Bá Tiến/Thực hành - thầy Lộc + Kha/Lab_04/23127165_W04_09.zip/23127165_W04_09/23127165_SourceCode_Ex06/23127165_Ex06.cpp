#include "23127165_HeaderFile_Ex06.hpp"

int main()
{
    Node* pHead = nullptr;

    inputList(pHead);
    Node* tmp_head = sumList(pHead);
    printList(tmp_head);

    deleteList(pHead, tmp_head);

    return 0;
}