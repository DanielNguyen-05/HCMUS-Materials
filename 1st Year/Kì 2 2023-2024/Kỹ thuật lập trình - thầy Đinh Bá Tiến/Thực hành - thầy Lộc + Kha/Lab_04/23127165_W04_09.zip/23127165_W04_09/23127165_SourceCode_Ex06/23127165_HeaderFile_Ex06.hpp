#pragma once

struct Node
{
    int data;
    Node* pNext;
};

// This function is used to create a new node
Node* makeNode(int n);

// This function is used to input a list from a file
void inputList(Node* &pHead);

// This function is used to create a new linked list of sum
Node* sumList(Node* pHead);

// This function is used to print the new list to a file
void printList(Node* tmp_head);

// This function is used to delete the 2 lists
void deleteList(Node* &pHead, Node* &tmp_head);