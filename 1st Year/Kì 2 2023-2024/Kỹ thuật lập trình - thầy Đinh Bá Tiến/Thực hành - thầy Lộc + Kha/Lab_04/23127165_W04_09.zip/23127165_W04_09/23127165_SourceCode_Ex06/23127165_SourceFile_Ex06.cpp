#include "23127165_HeaderFile_Ex06.hpp"
#include <iostream>
#include <fstream>

/*
        Test case 1:
    Input: 1 2 2 4 2 6 0
    Output: 1 3 5 9 11 17

        Test case 2:
    Input: 1 2 3 4 5 6 0
    Output: 1 3 6 10 15 21

        Test case 3:
    Input: 1 0
    Output: 1
*/

Node* makeNode(int n)
{
    Node* pNode = new Node;
    pNode->data = n;
    pNode->pNext = nullptr;
    return pNode;
}

void inputList(Node* &pHead)
{
    std::ifstream fin("InputFile_Testcase1.txt");
    if (!fin.is_open())
    {
        std::cout << "Error: File not found!";
        return;
    }
    int n;
    while (fin >> n)
    {
        if (n == 0) break;
        Node* pNode = makeNode(n);
        if (pHead == nullptr) pHead = pNode;
        else
        {
            Node* cur = pHead;
            while (cur->pNext != nullptr) cur = cur->pNext;
            cur->pNext = pNode;
        }
    }
    fin.close();
}

Node* sumList(Node* pHead)
{
    if (pHead == nullptr) return nullptr;
    Node* tmp_head = new Node;
    tmp_head->data = pHead->data ;
    tmp_head->pNext = nullptr;
    Node* tmp_tail = tmp_head;
    int sum = pHead->data;

    while (pHead->pNext != nullptr)
    {
        sum += pHead->pNext->data;
        Node* pNode = makeNode(sum);
        tmp_tail->pNext = pNode;
        tmp_tail = tmp_tail->pNext;
        pHead = pHead->pNext;
    }
    return tmp_head;
}

void printList(Node* tmp_head)
{
    std::ofstream fout("OutputFile_Testcase1.txt");
    if (!fout.is_open())
    {
        std::cout << "Error: File not found!";
        return;
    }
    Node* cur = tmp_head;
    while (cur != nullptr)
    {
        fout << cur->data << " ";
        cur = cur->pNext;
    }
    fout.close();
}

void deleteList(Node* &pHead, Node* &tmp_head)
{
    Node* cur1 = pHead;
    Node* tmp1;
    while (cur1 != nullptr)
    {
        tmp1 = cur1;
        cur1 = cur1->pNext;
        delete tmp1;
    }
    Node* cur2 = tmp_head;
    Node* tmp2;
    while (cur2 != nullptr)
    {
        tmp2 = cur2;
        cur2 = cur2->pNext;
        delete tmp2;
    }
}