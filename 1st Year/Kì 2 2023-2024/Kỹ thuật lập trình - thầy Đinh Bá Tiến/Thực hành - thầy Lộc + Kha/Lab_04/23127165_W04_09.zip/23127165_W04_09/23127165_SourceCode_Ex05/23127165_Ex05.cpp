#include "23127165_HeaderFile_Ex05.hpp"

int main()
{
    int x;
    Node* pHead = nullptr;

    inputList(pHead, x);
    sortedList(pHead, x);
    printList(pHead);
    
    deleteList(pHead);

    return 0;
}