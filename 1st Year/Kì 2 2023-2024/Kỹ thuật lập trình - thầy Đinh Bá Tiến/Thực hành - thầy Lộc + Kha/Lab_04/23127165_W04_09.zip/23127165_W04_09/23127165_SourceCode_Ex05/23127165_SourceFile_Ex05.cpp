#include "23127165_HeaderFile_Ex05.hpp"
#include <iostream>
#include <fstream>

/*
        Test case 1:
    Input: 27
           10 20 30 40 50 60 0
    Output: 10 20 27 30 40 50 60

        Test case 2:
    Input: 66
           10 20 30 40 50 60 0
    Output: 10 20 30 40 50 60 66

        Test case 3:
    Input: 6
           10 20 30 40 50 60 0
    Output: 6 10 20 30 40 50 60
    
        Test case 4:
    Input: 99
           0
    Output: 99
*/

Node* makeNode(int n)
{
    Node* pNode = new Node;
    pNode->data = n;
    pNode->pNext = nullptr;
    return pNode;
}

void inputList(Node* &pHead, int &x)
{
    std::ifstream fin("InputFile_Testcase1.txt");
    if (!fin.is_open())
    {
        std::cout << "Error: File not found!";
        return;
    }
    fin >> x;
    int n;
    while (fin >> n)
    {
        if (n == 0) break;
        Node* pNode = makeNode(n);
        if (pHead == nullptr) pHead = pNode;
        else
        {
            Node* cur = pHead;
            while (cur->pNext != nullptr) cur = cur->pNext;
            cur->pNext = pNode;
        }
    }
    fin.close();
}

void sortedList(Node* &pHead, int x)
{
    Node* pNode = makeNode(x);
    if (pHead == nullptr) 
    {
        pHead = pNode;
        return;
    }
    if (pNode->data < pHead->data)
    {
        pNode->pNext = pHead;
        pHead = pNode;
        return;
    }
    Node* cur = pHead;
    while (cur->pNext != nullptr)
    {
        if (pNode->data < cur->pNext->data) 
        {
            pNode->pNext = cur->pNext;
            cur->pNext = pNode;
            return;
        }
        cur = cur->pNext;
    }
    cur->pNext = pNode;
}


void printList(Node* pHead)
{
    std::ofstream fout("OutputFile_Testcase1.txt");
    if (!fout.is_open())
    {
        std::cout << "Error: File not found!";
        return;
    }
    Node* cur = pHead;
    while (cur != nullptr)
    {
        fout << cur->data << " ";
        cur = cur->pNext;
    }
    fout.close();
}

void deleteList(Node* &pHead)
{
    Node* cur = pHead;
    Node* tmp;
    while (cur != nullptr)
    {
        tmp = cur;
        cur = cur->pNext;
        delete tmp;
    }
}