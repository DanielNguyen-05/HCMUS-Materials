#pragma once

struct Node
{
    int data;
    Node* pNext;
};

// This function is used to create a new node
Node* makeNode(int n);

// This function is used to input a new integer x and a list from a file
void inputList(Node* &pHead, int &x);

// This function is used to insert a new integer x into the linked list so that it remains sorted the list
void sortedList(Node* &pHead, int x);

// This function is used to print the sorted list to a file
void printList(Node* pHead);

// This function is used to delete the list
void deleteList(Node* &pHead);