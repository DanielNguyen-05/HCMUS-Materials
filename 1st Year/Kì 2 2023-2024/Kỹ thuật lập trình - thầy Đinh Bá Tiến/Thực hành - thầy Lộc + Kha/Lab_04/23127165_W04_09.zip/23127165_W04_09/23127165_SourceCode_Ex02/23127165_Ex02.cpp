#include "23127165_HeaderFile_Ex02.hpp"

int main()
{
    Node* pHead = nullptr;

    inputList(pHead);
    removeDuplicates(pHead);
    printList(pHead);
    
    deleteList(pHead);
    
    return 0;
}