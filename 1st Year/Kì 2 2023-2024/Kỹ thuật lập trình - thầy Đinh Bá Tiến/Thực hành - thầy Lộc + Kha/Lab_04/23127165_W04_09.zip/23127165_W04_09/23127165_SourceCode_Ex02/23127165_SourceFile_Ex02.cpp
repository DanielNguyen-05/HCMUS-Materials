#include "23127165_HeaderFile_Ex02.hpp"
#include <iostream>
#include <fstream>

/*
        Test case 1:
    Input (file): 1 2 2 4 2 6 0 
    Ouput (file): 1 2 4 6 

        Test case 2:
    Input (file): 2 2 2 2 2 2 0 
    Ouput (file): 2

        Test case 3:
    Input (file): 1 2 3 4 5 6 0 
    Ouput (file): 1 2 3 4 5 6
*/

Node* makeNode (int n)
{
    Node* pNode = new Node;
    pNode->data = n;
    pNode->pNext = nullptr;
    return pNode;
}

void inputList(Node* &pHead)
{
    std::ifstream fin("InputFile_Testcase1.txt");
    if (!fin.is_open())
    {
        std::cout << "Error: File not found!";
        return;
    }
    int n;
    while (fin >> n)
    {
        if (n == 0) break;
        Node* pNode = makeNode(n);
        if (pHead == nullptr) pHead = pNode;
        else
        {
            Node* cur = pHead;
            while (cur->pNext != nullptr) cur = cur->pNext;
            cur->pNext = pNode;
        }
    }
    fin.close();
}

void removeDuplicates(Node* pHead)
{
    if (pHead == nullptr) return;
    int* arr = new int[1000001];
    for (int i = 0; i < 1000001; i++)
    {
        *(arr + i) = 0;
    }
    Node* cur = pHead;
    Node* prev = nullptr;
    while (cur != nullptr)
    {
        (*(arr + cur->data))++;
        if (*(arr + cur->data) > 1)
        {
            if (prev != nullptr) prev->pNext = cur->pNext;
            else pHead = cur->pNext;
            Node* tmp = cur;
            cur = cur->pNext;
            delete tmp;
        }
        else
        {
            prev = cur;
            cur = cur->pNext;
        }
    }
    delete[] arr;
}

void printList(Node* pHead)
{
    std::ofstream fout("OutputFile_Testcase1.txt");
    if (!fout.is_open())
    {
        std::cout << "Error: File not found!";
        return;
    }
    Node* cur = pHead;
    while (cur != nullptr)
    {
        fout << cur->data << " ";
        cur = cur->pNext;
    }
    fout.close();
}

void deleteList(Node* &pHead)
{
    Node* cur = pHead;
    Node* tmp;
    while (cur != nullptr)
    {
        tmp = cur;
        cur = cur->pNext;
        delete tmp;
    }
}