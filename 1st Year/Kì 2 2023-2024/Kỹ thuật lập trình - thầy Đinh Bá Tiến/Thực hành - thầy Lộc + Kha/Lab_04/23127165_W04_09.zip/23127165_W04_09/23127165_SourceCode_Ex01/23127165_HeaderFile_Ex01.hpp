#pragma once

struct Node
{
    int data;
    Node* pNext;
};

// This function is used to create a new node
Node* makeNode(int n);

// This function is used to input a list from a file
void inputList(Node* &pHead);

// This function asks user to input x to remove
void inputX(int &x);

// This function is used to delete all nodes with value x
void deleteAllX(Node* &pHead, int x);

// This function is used to print the list to a file
void printList (Node* pHead);

// This function is used to delete the list
void deleteList(Node* &pHead);