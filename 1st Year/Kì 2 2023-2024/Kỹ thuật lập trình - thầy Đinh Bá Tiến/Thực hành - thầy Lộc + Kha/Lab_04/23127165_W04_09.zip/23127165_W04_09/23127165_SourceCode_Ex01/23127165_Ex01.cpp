#include "23127165_HeaderFile_Ex01.hpp"

int main()
{
    int x;
    Node* pHead = nullptr;

    inputList(pHead);
    inputX(x);
    deleteAllX(pHead, x);
    printList(pHead);
    
    deleteList(pHead);

    return 0;
}