#include "23127165_HeaderFile_Ex01.hpp"
#include <iostream>
#include <fstream>

/*
        Test case 1:
    Input (file): 1 2 2 4 2 6 0 
    User enter: 2 
    Ouput (file): 1 4 6

        Test case 2:
    Input (file): 1 2 2 4 2 6 0 
    User enter: 3 
    Ouput (file): 1 2 2 4 2 6

        Test case 3:
    Input (file): 1 1 1 1 1 1 0 
    User enter: 1 
    Ouput (file): 
*/

Node* makeNode(int n)
{
    Node* pNode = new Node;
    pNode->data = n;
    pNode->pNext = nullptr;
    return pNode;
}

void inputList(Node* &pHead)
{
    std::ifstream fin("InputFile_Testcase1.txt");
    if (!fin.is_open())
    {
        std::cout << "Error: File not found!";
        return;
    }
    int n;
    while (fin >> n)
    {
        if (n == 0) break;
        Node* pNode = makeNode(n);
        if (pHead == nullptr) pHead = pNode;
        else
        {
            Node* cur = pHead;
            while (cur->pNext != nullptr) cur = cur->pNext;
            cur->pNext = pNode;
        }
    }
    fin.close();
}

void inputX(int &x)
{
    std::cout << "Enter a value x to remove: ";
    std::cin >> x;
}

void deleteAllX(Node* &pHead, int x)
{
    if (pHead == nullptr) return;
    Node* cur = pHead;
    while (cur != nullptr && cur->pNext != nullptr)
    {
        while (cur->pNext != nullptr && cur->pNext->data == x)
        {
            Node* tmp = cur->pNext;
            cur->pNext = cur->pNext->pNext;
            delete tmp;
        }
        cur = cur->pNext;
    }
    if (pHead != nullptr && pHead->data == x)
    {
        Node* tmp = pHead;
        pHead = pHead->pNext;
        delete tmp;
    }
}

void printList(Node* pHead)
{
    std::ofstream fout("OutputFile_Testcase1.txt");
    if (!fout.is_open())
    {
        std::cout << "Error: File not found!";
        return;
    }
    Node* cur = pHead;
    while (cur != nullptr)
    {
        fout << cur->data << " ";
        cur = cur->pNext;
    }
    fout.close();
}

void deleteList(Node* &pHead)
{
    Node* cur = pHead;
    Node* tmp;
    while (cur != nullptr)
    {
        tmp = cur;
        cur = cur->pNext;
        delete tmp;
    }
}
