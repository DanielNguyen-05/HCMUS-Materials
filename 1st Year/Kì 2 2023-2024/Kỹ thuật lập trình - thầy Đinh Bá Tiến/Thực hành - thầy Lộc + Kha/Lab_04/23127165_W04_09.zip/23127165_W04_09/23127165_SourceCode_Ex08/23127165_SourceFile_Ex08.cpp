#include "23127165_HeaderFile_Ex08.hpp"
#include <iostream>
#include <fstream>

/*
        Test case 1:
    Input: 10 30 50 70 90 110 0
           20 40 60 0
    Output: 10 20 30 40 50 60 70 90 110
    
        Test case 2:
    Input: 1 2 4 0
           3 9 5 6 0
    Output: 1 3 2 9 4 5 6 

        Test case 3:
    Input: 0
           1 3 5 7 0
    Output: 1 3 5 7

        Test case 4:
    Input: 2 4 6 8 0
           0
    Output: 2 4 6 8

        Test case 5:
    Input: 0
           0
    Output:
*/

Node* makeNode(int n)
{
    Node* pNode = new Node;
    pNode->data = n;
    pNode->pNext = nullptr;
    return pNode;
}

void inputList(Node* &pHead1, Node* &pHead2)
{
    std::ifstream fin("InputFile_Testcase1.txt");
    if (!fin.is_open())
    {
        std::cout << "Error: File not found!";
        return;
    }
    int n1;
    while (fin >> n1)
    {
        if (n1 == 0) break;
        Node* pNode1 = makeNode(n1);
        if (pHead1 == nullptr) pHead1 = pNode1;
        else
        {
            Node* cur1 = pHead1;
            while (cur1->pNext != nullptr) cur1 = cur1->pNext;
            cur1->pNext = pNode1;
        }
    }
    int n2;
    while (fin >> n2)
    {
        if (n2 == 0) break;
        Node* pNode2 = makeNode(n2);
        if (pHead2 == nullptr) pHead2 = pNode2;
        else
        {
            Node* cur2 = pHead2;
            while (cur2->pNext != nullptr) cur2 = cur2->pNext;
            cur2->pNext = pNode2;
        }
    }
    fin.close();
}

void combineList(Node* &pHead1, Node* &pHead2)
{
    if (pHead1 == nullptr)
    {
        pHead1 = pHead2;
        return;
    }
    if (pHead2 == nullptr) return;
    Node* cur1 = pHead1;
    Node* cur2 = pHead2;
    while (cur1 != nullptr && cur2 != nullptr)
    {
        Node* tmp1 = cur1->pNext;
        Node* tmp2 = cur2->pNext;
        cur1->pNext = cur2;
        cur2->pNext = tmp1;
        cur1 = tmp1;
        cur2 = tmp2;
    }
    if (cur1 == nullptr && cur2 != nullptr)
    {
        Node* tail = pHead1;
        while (tail->pNext != nullptr)
        {
            tail = tail->pNext;
        }
        tail->pNext = cur2;
    }
}

void printList(Node* pHead1)
{
    std::ofstream fout("OutputFile_Testcase1.txt");
    if (!fout.is_open())
    {
        std::cout << "Error: File not found!";
        return;
    }
    Node* cur = pHead1;
    while (cur != nullptr)
    {
        fout << cur->data << " ";
        cur = cur->pNext;
    }
    fout.close();
}

void deleteList(Node* &pHead1)
{
    Node* cur = pHead1;
    Node* tmp;
    while (cur != nullptr)
    {
        tmp = cur;
        cur = cur->pNext;
        delete tmp;
    }
}