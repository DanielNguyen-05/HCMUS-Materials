#include "23127165_HeaderFile_Ex08.hpp"

int main()
{
    Node* pHead1 = nullptr;
    Node* pHead2 = nullptr;

    inputList(pHead1, pHead2);
    combineList(pHead1, pHead2);
    printList(pHead1);

    deleteList(pHead1);

    return 0;
}