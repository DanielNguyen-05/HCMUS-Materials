#pragma once

struct Node
{
    int data;
    Node* pNext;
};

// This function is used to create a new node
Node* makeNode(int n);

// This function is used to input two lists from a file
void inputList(Node* &pHead1, Node* &pHead2);

// This function is used to combine their nodes into one list
void combineList(Node* &pHead1, Node* &pHead2);

// This function is used to print the combined list to a file
void printList(Node* pHead1);

// This function is used to delete the list
void deleteList(Node* &pHead1);
