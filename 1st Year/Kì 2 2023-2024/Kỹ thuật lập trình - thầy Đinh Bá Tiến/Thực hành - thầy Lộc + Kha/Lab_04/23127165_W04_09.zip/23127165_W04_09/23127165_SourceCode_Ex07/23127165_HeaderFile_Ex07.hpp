#pragma once

struct Node
{
    int data;
    Node* pNext;
};

// This function is used to create a new node
Node* makeNode(int n);

// This function is used to input a list from a file
void inputList(Node* &pHead);

// This function is used to re-arrange its nodes into two lists
void rearrangeList(Node* &pHead, Node* &new_pHead);

// This function is used to print the 2 lists to a file
void printList(Node* pHead, Node* new_pHead);

// This function is used to delete the 2 lists
void deleteList(Node* &pHead, Node* &new_pHead);
