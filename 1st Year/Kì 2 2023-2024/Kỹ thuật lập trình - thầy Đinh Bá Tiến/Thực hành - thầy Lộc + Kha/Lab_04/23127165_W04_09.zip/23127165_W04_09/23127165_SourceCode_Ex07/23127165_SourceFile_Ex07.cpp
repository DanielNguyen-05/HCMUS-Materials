#include "23127165_HeaderFile_Ex07.hpp"
#include <iostream>
#include <fstream>

/*
        Test case 1:
    Input: 10 20 30 40 50 0
    Output: 10 30 50
            20 40 
            
        Test case 2:
    Input: 10 20 0
    Output: 10
            20 

        Test case 3:
    Input: 10 0
    Output: 10
*/

Node* makeNode(int n)
{
    Node* pNode = new Node;
    pNode->data = n;
    pNode->pNext = nullptr;
    return pNode;
}

void inputList(Node* &pHead)
{
    std::ifstream fin("InputFile_Testcase1.txt");
    if (!fin.is_open())
    {
        std::cout << "Error: File not found!";
        return;
    }
    int n;
    while (fin >> n)
    {
        if (n == 0) break;
        Node* pNode = makeNode(n);
        if (pHead == nullptr) pHead = pNode;
        else
        {
            Node* cur = pHead;
            while (cur->pNext != nullptr) cur = cur->pNext;
            cur->pNext = pNode;
        }
    }
    fin.close();
}

void rearrangeList(Node* &pHead, Node* &new_pHead)
{
    if (pHead == nullptr) return;
    Node* cur1 = pHead;
    Node* cur2 = nullptr;
    int i = 1;
    while (cur1 != nullptr)
    {
        if (i % 2 == 1 && cur1->pNext != nullptr)
        {
            Node* tmp = cur1->pNext;
            cur1->pNext = cur1->pNext->pNext;
            tmp->pNext = nullptr;
            if (new_pHead == nullptr) 
            {
                new_pHead = tmp;
                cur2 = new_pHead;
            }
            else
            {
                cur2->pNext = tmp;
                cur2 = cur2->pNext;
            }
        }
        else cur1 = cur1->pNext;
        i++;
    }
}

void printList(Node* pHead, Node* new_pHead)
{
    std::ofstream fout("OutputFile_Testcase1.txt");
    if (!fout.is_open())
    {
        std::cout << "Error: File not found!";
        return;
    }
    Node* cur1 = pHead;
    while (cur1 != nullptr)
    {
        fout << cur1->data << " ";
        cur1 = cur1->pNext;
    }
    fout << "\n";
    Node* cur2 = new_pHead;
    while (cur2 != nullptr)
    {
        fout << cur2->data << " ";
        cur2 = cur2->pNext;
    }
    fout.close();
}

void deleteList(Node* &pHead, Node* &new_pHead)
{
    Node* cur1 = pHead;
    Node* tmp1;
    while (cur1 != nullptr)
    {
        tmp1 = cur1;
        cur1 = cur1->pNext;
        delete tmp1;
    }
    Node* cur2 = new_pHead;
    Node* tmp2;
    while (cur2 != nullptr)
    {
        tmp2 = cur2;
        cur2 = cur2->pNext;
        delete tmp2;
    }
}