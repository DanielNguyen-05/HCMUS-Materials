#include "23127165_HeaderFile_Ex07.hpp"

int main()
{
    Node* pHead = nullptr;
    Node* new_pHead = nullptr;

    inputList(pHead);
    rearrangeList(pHead, new_pHead);
    printList(pHead, new_pHead);

    deleteList(pHead, new_pHead);

    return 0;
}