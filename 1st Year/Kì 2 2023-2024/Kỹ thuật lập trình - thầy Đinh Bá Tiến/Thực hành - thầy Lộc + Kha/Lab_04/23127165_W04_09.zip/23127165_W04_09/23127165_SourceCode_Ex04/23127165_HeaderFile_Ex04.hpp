#pragma once

struct Node
{
    int data;
    Node* pNext;
};

// This function is used to create a new node
Node* makeNode(int n);

// This function is used to input a list from a file
void inputList(Node* &pHead);

// This function is used to insert even numbers before nodes in the list
void insertEvenNum(Node* &pHead);

// This function is used to print the list to a file
void printList(Node* pHead);

// This function is used to delete the list
void deleteList(Node* &pHead);