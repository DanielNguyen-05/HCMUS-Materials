#include "23127165_HeaderFile_Ex04.hpp"
#include <iostream>
#include <fstream>

/*
        Test case 1:
    Input (file): 1 2 2 4 2 6 0
    Output (file): 2 1 4 2 6 2 8 4 10 2 12 6

        Test case 2:
    Input (file): 1 0
    Output (file): 2 1

        Test case 3:
    Input (file): 0
    Output (file): 
*/

Node* makeNode(int n)
{
    Node* pNode = new Node;
    pNode->data = n;
    pNode->pNext = nullptr;
    return pNode;
}

void inputList(Node* &pHead)
{
    std::ifstream fin("InputFile_Testcase1.txt");
    if (!fin.is_open())
    {
        std::cout << "Error: File not found!";
        return;
    }
    int n;
    while (fin >> n)
    {
        if (n == 0) break;
        Node* pNode = makeNode(n);
        if (pHead == nullptr) pHead = pNode;
        else
        {
            Node* cur = pHead;
            while (cur->pNext != nullptr) cur = cur->pNext;
            cur->pNext = pNode;
        }
    }
    fin.close();
}

void insertEvenNum(Node* &pHead)
{
    if (pHead == nullptr) return;
    int i = 2;
    Node* cur = pHead;
    while (cur != nullptr)
    {
        Node* pNode = makeNode(i);
        if (cur == pHead)
        {
            pNode->pNext = cur;
            pHead = pNode;
        }
        else
        {   
            if (cur->pNext == nullptr) return;
            pNode->pNext = cur->pNext;
            cur->pNext = pNode;
            cur = cur->pNext->pNext;
        }
        i += 2;
    }
}

void printList(Node* pHead)
{
    std::ofstream fout("OutputFile_Testcase1.txt");
    if (!fout.is_open())
    {
        std::cout << "Error: File not found!";
        return;
    }
    Node* cur = pHead;
    while (cur != nullptr)
    {
        fout << cur->data << " ";
        cur = cur->pNext;
    }
    fout.close();
}

void deleteList(Node* &pHead)
{
    Node* cur = pHead;
    Node* tmp;
    while (cur != nullptr)
    {
        tmp = cur;
        cur = cur->pNext;
        delete tmp;
    }
}