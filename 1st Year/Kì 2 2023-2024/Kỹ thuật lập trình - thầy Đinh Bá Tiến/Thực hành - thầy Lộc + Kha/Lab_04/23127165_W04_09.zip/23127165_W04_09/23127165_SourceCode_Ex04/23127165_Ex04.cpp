#include "23127165_HeaderFile_Ex04.hpp"

int main()
{
    Node* pHead = nullptr;

    inputList(pHead);
    insertEvenNum(pHead);
    printList(pHead);
    
    deleteList(pHead);

    return 0;
}