#include "23127165_HeaderFile_Ex04.hpp"

/*
            Testcase 1:
    Input: 
        String 1: 99
        String 2: 2
    Output: The answer: 101

            Testcase 2:
    Input: 
        String 1: 1234567890123456788990067688472384753872743875427847328473990352742
        String 2: 36254394742958743957340957348573409572075028758758827592735
    Output: The answer: 1234567926377851531948811645813342102446153447502876087232817945477

            Testcase 3:
    Input: 
        String 1: 1234567890123456788990067688472384753872743875427847328473990352742
        String 2: 0
    Output: The answer: 1234567890123456788990067688472384753872743875427847328473990352742

            Testcase 4:
    Input: 
        String 1: 0
        String 2: 36254394742958743957340957348573409572075028758758827592735
    Output: The answer: 36254394742958743957340957348573409572075028758758827592735

            Testcase 5:
    Input: 
        String 1: 0
        String 2: 0
    Output: The answer: 0
*/

int main()
{
    Node* pHead = nullptr;
    std::string str1, str2;
    inputTwoStrings(str1, str2);
    sumTwoStrings(pHead, str1, str2);
    printList(pHead);

    deleteList(pHead);
    return 0;
}