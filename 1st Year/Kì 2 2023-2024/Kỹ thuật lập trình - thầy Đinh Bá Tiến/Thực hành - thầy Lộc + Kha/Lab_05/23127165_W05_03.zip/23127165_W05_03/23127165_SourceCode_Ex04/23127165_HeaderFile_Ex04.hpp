#pragma once
#include <iostream>
#include <string>

struct Node
{
    std::string data;
    Node* pPrev;
    Node* pNext;
};

// This function is used to input two strings from the user
void inputTwoStrings(std::string& str1, std::string& str2);

// This function is used to add a new node to the end of the doubly linked list
void addNodeLater(Node* &pHead, std::string data);

// This function is used to sum two strings and store the result in a doubly linked list
void sumTwoStrings(Node* &pHead, std::string str1, std::string str2);

// This function is used to print the doubly linked list
void printList(Node* pHead);

// This function is used to delete the doubly linked list
void deleteList(Node* &pHead);