#include "23127165_HeaderFile_Ex04.hpp"
#include <iostream>
#include <string>

void inputTwoStrings(std::string& str1, std::string& str2)
{
    std::cout << "String 1: ";
    std::cin >> str1;
    std::cout << "String 2: ";
    std::cin >> str2;
}

void addNodeLater(Node* &pHead, std::string data)
{
    Node* cur = pHead;
    if (cur == nullptr)
    {
        cur = new Node;
        cur->data = data;
        cur->pPrev = nullptr;
        cur->pNext = nullptr;
        pHead = cur;
    }
    else
    {
        while (cur->pNext != nullptr) cur = cur->pNext;
        Node* tmp = new Node;
        tmp->data = data;
        tmp->pPrev = cur;
        tmp->pNext = nullptr;
        cur->pNext = tmp;
    }
}

void sumTwoStrings(Node* &pHead, std::string str1, std::string str2)
{
    int surplus = 0;

    while (!str1.empty() || !str2.empty())
    {
        int a = 0, b = 0;
        if (!str1.empty())
        {
            a = str1.back() - '0';
            str1.pop_back();
        }
        if (!str2.empty())
        {
            b = str2.back() - '0';
            str2.pop_back();
        }
        int sum = a + b + surplus;
        surplus = sum / 10;
        sum = sum % 10;
        addNodeLater(pHead, std::to_string(sum));
    }
    if (surplus != 0)
    {
        addNodeLater(pHead, std::to_string(surplus));
    }
}

void printList(Node* pHead)
{
    Node* cur = pHead;
    while (cur->pNext != nullptr) cur = cur->pNext;
    std::cout << "The answer: ";
    while (cur != nullptr)
    {
        std::cout << cur->data;
        cur = cur->pPrev;
    }
}

void deleteList(Node* &pHead)
{
    Node* cur = pHead;
    while (cur != nullptr)
    {
        Node* tmp = cur;
        cur = cur->pNext;
        delete tmp;
    }
    pHead = nullptr;
}