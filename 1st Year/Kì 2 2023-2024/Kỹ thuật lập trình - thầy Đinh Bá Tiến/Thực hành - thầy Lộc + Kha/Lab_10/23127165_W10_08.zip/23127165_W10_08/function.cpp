#include "23127165_header.hpp"
#include <iostream>
#include <string>
#include <vector>
#include <fstream>

using namespace std;

bool isAccountExists(const std::vector<User>& users, const std::string& username) {
        for (const auto& user : users) {
                if (user.username == username) {
                        return true;
                }
        }
        std::string filename = username + ".txt";
        std::ifstream file(filename);
        if (file) {
                file.close();
                return true;
        }
        return false;
}

void createAccount (std::vector<User>& users) {
        std::string username, password, email;
        std::cin.ignore();
        std::cout << "Enter username: ";
        std::getline(std::cin, username);

        if (isAccountExists(users, username)) {
                std::cout << "\nAccount already exists." << std::endl;
                return;
        }

        std::cout << "Enter email: ";
        std::getline(std::cin, email);
        std::cout << "Enter password: ";
        std::getline(std::cin, password);

        User user(username, email, password);

        users.push_back(user);

        std::string filename = username +  ".txt";
        std::ofstream file(filename, std::ios::app);
        if (file.is_open()) {
                file << user.username << "," << user.email << "," << user.password << std::endl;
                file.close();
                std::cout << "\nAccount created successfully." << std::endl;
        } else {
                std::cout << "Failed to create account file." << std::endl;
        }
}

void login (std::vector<User>& users) {
    std::string username, password;
    cin.ignore();
    std::cout << "\n";
    std::cout << "Enter username: ";
    std::getline(std::cin, username);
    std::cout << "Enter password: ";
    std::getline(std::cin, password);

    for (const auto& user : users) {
        if (username == user.username && password == user.password) {
            std::cout << "\nLogin successful!" << std::endl;
            return;
        }
    }
    std::cout << "Login failed. Incorrect username or password." << std::endl;

}

void postMessage (std::vector<User>& users, const std::string& username) {
    std::string message;
    std::cin.ignore();
    std::cout << "Enter your message: ";
    std::getline(std::cin, message);
    std::cout << "\nMessage posted successfully." << std::endl;

    std::string messagefilename = username + "_message.txt";
    std::ofstream file(messagefilename, std::ios::app);
    if (file.is_open()) {
        file << message << "\n";
    }
    file.close();
}

void followUser (const std::string& username) {
    std::string followUsername;
    cin.ignore();
    std::cout << "\nEnter username to follow: ";
    std::getline(std::cin, followUsername);

    std::cout << "\nUser followed successfully." << std::endl;

    std::string followFilename = username + "_follow.txt";
    std::ofstream file(followFilename, std::ios::app);
    if (file.is_open()) {
        file << followUsername << "\n";
    }
    file.close();
}

void displayUserMessages(const std::string& username) {
        std::string messageFilename = username + "_messages.txt";
        std::ifstream messageFile(messageFilename);
        std::string message;

        if (messageFile.is_open()) {
                int k = 1;
                while (std::getline(messageFile, message)) {
                        std::cout << k << ". " << username << ": " << message << std::endl;
                        k++;
                }
                messageFile.close();
        }
}

void viewFeed (const std::string& username) {
        std::string followFilename = username + "_follow.txt";
        std::ifstream followFile(followFilename);
        std::string followedUser;

        displayUserMessages(username);

        if (followFile.is_open()) {
                while (std::getline(followFile, followedUser)) {
                        displayUserMessages(followedUser);
                }
                followFile.close();
        } else {
                std::cout << "No users followed yet." << std::endl;
        }
}

void viewProfile (const std::string& username) {
        std::cout << "\n";
    std::cout << "Profile:\n";
    std::cout << "Username: " << username << "\n";
    std::cout << "Followed Users: ";

    std::string followFilename = username + "_follow.txt";
    std::ifstream followFile(followFilename);
    std::string followedUser;

    if (followFile.is_open()) {
        while (std::getline(followFile, followedUser)) {
            std::cout << followedUser << " ";
        }
        followFile.close();
    } else {
        std::cout << "No users followed yet.";
    }
    std::cout << "\n";
}
