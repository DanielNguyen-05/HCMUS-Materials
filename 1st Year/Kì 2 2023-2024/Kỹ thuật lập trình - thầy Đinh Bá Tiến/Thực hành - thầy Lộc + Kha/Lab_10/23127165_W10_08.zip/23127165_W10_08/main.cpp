#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include "23127165_header.hpp"
#include "function.cpp"

int main() {
        std::vector<User> users;
        int choice;
        std::cout << "Menu:" << "\n";
        std::cout << "1. Create Account" << "\n";
        std::cout << "2. Login" << "\n";
        std::cout << "3. Exit" << "\n\n";
        std::cout << "Enter your choice: ";
        std::cin >> choice;

        if (choice == 1) goto label1;
        else if (choice == 2) goto label2;
        else if (choice == 3) return 0;
        else std::cout << "Invalid choice." << std::endl;

        label1:
                createAccount(users);
                int choice1;
                std::cout << "\n";
                std::cout << "Menu:" << "\n";
                std::cout << "1. Create Account" << "\n";
                std::cout << "2. Login" << "\n";
                std::cout << "3. Exit" << "\n\n";
                std::cout << "Enter your choice: ";
                std::cin >> choice1;

                if (choice1 == 1) goto label1;
                else if (choice1 == 2) {
                        login(users);
                        goto label2;
                }
                else if (choice1 == 3) return 0;
                else std::cout << "Invalid choice." << std::endl;


        label2:
                login(users);
                int choice2;
                std::cout << "\n";
                std::cout << "Menu:\n";
                std::cout << "1. Post Message\n";
                std::cout << "2. Follow User\n";
                std::cout << "3. View Feed\n";
                std::cout << "4. View Profile\n";
                std::cout << "5. Logout\n\n";
                std::cout << "Enter your choice: ";
                std::cin >> choice2;

                if (choice2 == 1) goto label21;
                else if (choice2 == 2) goto label22;
                else if (choice2 == 3) goto label23;
                else if (choice2 == 4) goto label24;
                else if (choice2 == 5) goto label25;
                else std::cout << "Invalid choice." << std::endl;

        label21:
                postMessage(users, users[0].username);
                int choice3;
                std::cout << "\n";
                std::cout << "Menu:\n";
                std::cout << "1. Post Message\n";
                std::cout << "2. Follow User\n";
                std::cout << "3. View Feed\n";
                std::cout << "4. View Profile\n";
                std::cout << "5. Logout\n\n";
                std::cout << "Enter your choice: ";
                std::cin >> choice3;

                if (choice3 == 1) goto label21;
                else if (choice3 == 2) goto label22;
                else if (choice3 == 3) goto label23;
                else if (choice3 == 4) goto label24;
                else if (choice3 == 5) goto label25;
                else std::cout << "Invalid choice." << std::endl;
        
        label22:
                followUser(users[0].username);
                int choice4;
                std::cout << "\n";
                std::cout << "Menu:\n";
                std::cout << "1. Post Message\n";
                std::cout << "2. Follow User\n";
                std::cout << "3. View Feed\n";
                std::cout << "4. View Profile\n";
                std::cout << "5. Logout\n\n";
                std::cout << "Enter your choice: ";
                std::cin >> choice4;

                if (choice4 == 1) goto label21;
                else if (choice4 == 2) goto label22;
                else if (choice4 == 3) goto label23;
                else if (choice4 == 4) goto label24;
                else if (choice4 == 5) goto label25;
                else std::cout << "Invalid choice." << std::endl;

        label23:
                viewFeed(users[0].username);
                int choice5;
                std::cout << "\n";
                std::cout << "Menu:\n";
                std::cout << "1. Post Message\n";
                std::cout << "2. Follow User\n";
                std::cout << "3. View Feed\n";
                std::cout << "4. View Profile\n";
                std::cout << "5. Logout\n\n";
                std::cout << "Enter your choice: ";
                std::cin >> choice5;

                if (choice5 == 1) goto label21;
                else if (choice5 == 2) goto label22;
                else if (choice5 == 3) goto label23;
                else if (choice5 == 4) goto label24;
                else if (choice5 == 5) goto label25;
                else std::cout << "Invalid choice." << std::endl;

        label24:
                viewProfile(users[0].username);
                int choice6;
                std::cout << "\n";
                std::cout << "Menu:\n";
                std::cout << "1. Post Message\n";
                std::cout << "2. Follow User\n";
                std::cout << "3. View Feed\n";
                std::cout << "4. View Profile\n";
                std::cout << "5. Logout\n\n";
                std::cout << "Enter your choice: ";
                std::cin >> choice6;

                if (choice6 == 1) goto label21;
                else if (choice6 == 2) goto label22;
                else if (choice6 == 3) goto label23;
                else if (choice6 == 4) goto label24;
                else if (choice6 == 5) goto label25;
                else std::cout << "Invalid choice." << std::endl;


        label25:
                std::cout << "Logged out successfully." << std::endl;
                return 0;

}
