#pragma once
#include <iostream>

struct User {
    std::string username;
    std::string email;
    std::string password;

    User(std::string username, std::string email, std::string password) : 
        username(username), email(email), password(password) {}
};

bool isAccountExists(const std::vector<User>& users, const std::string& username);
void createAccount (std::vector<User>& users);
void login (std::vector<User>& users);
void postMessage (std::vector<User>& users, const std::string& username);
void followUser (const std::string& username);
void displayUserMessages(const std::string& username);
void viewFeed (const std::string& username);
void viewProfile (const std::string& username);