#include "23127165_HeaderFile_Ex05.hpp"
#include <iostream>
#include <fstream>
#include <string>

bool fileExists(const std::string& filePath) {
    std::ifstream file(filePath);
    return file.good();
}

void mergeFiles(const std::string& sourcePath, const std::string& destinationPath) {
    std::ofstream destinationFile(destinationPath, std::ios::binary);

    if (!destinationFile) {
        std::cout << "Error opening destination file: " << destinationPath << std::endl;
        return;
    }

    std::string partFile = sourcePath + ".part01";
    int partNumber = 1;

    while (fileExists(partFile)) {
        std::ifstream sourceFile(partFile, std::ios::binary);

        if (!sourceFile) {
            std::cout << "Error opening part file: " << partFile << std::endl;
            return;
        }

        destinationFile << sourceFile.rdbuf();

        if (sourceFile.bad()) {
            std::cout << "Error reading part file: " << partFile << std::endl;
            return;
        }

        sourceFile.close();
        partFile = sourcePath + ".part" + std::to_string(++partNumber);
    }

    destinationFile.close();
    std::cout << "Files merged successfully!" << std::endl;
}