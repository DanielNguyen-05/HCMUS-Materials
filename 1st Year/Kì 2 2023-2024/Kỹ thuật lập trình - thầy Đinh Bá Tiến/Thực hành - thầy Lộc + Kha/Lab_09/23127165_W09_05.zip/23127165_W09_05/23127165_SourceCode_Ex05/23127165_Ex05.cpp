#include "23127165_HeaderFile_Ex05.hpp"
#include <iostream>
#include <string>

/*
    Testcase: 
        Input: /MYMERGEFILE -s test_files/test.txt -d test_files/merged.txt
        Output: Files merged successfully!
*/

int main() {
    std::cout << "Input your command: ";
    std::string command;
    std::getline(std::cin, command);

    int mark = 0;
    for (int i = 13; i < command.size(); i++) {
        if (command[i] == ' ') {
            mark = i;
            break;
        }
    }

    std::string sourcePath = command.substr(14, mark - 15);
    std::string destinationPath = command.substr(mark + 3, command.size() - mark - 2);

    mergeFiles(sourcePath, destinationPath);

    return 0;
}