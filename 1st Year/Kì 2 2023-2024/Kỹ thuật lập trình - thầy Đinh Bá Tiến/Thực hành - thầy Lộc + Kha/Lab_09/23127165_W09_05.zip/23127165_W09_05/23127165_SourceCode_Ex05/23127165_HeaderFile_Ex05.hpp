#pragma once

bool fileExists(const std::string& filePath);

void mergeFiles(const std::string& sourcePath, const std::string& destinationPath);