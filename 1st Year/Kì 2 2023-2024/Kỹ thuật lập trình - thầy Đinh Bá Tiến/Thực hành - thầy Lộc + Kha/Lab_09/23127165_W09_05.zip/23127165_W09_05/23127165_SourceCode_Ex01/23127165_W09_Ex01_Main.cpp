#include <iostream>
#include <fstream>
#include "23127165_W09_Ex01.hpp"

using namespace std;

/*
Test case 1: n = 5 and arr[] = {1, 2, 3, 4, 5} --> Output: 3
Test case 2: n = 4 and arr[] = {2, 8, 9, 11} --> Output: 8.5
*/

int main(){
    int n;
    int* arr;
    Write_Bin_File(n, arr);
    Find_Median();
    delete[] arr;
    return 0;
}