#pragma once

void Write_Bin_File(int &n, int* arr);

void Find_Median();