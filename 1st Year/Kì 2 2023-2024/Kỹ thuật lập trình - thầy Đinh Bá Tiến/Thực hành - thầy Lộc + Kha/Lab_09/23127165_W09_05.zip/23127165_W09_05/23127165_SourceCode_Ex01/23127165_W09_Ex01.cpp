#include<iostream>
#include <fstream>
#include "23127165_W09_Ex01.hpp"

using namespace std;

void Write_Bin_File(int &n, int* arr){
    //Input size of the array
    cout << "Enter the size of the array: ";
    cin >> n;
    //Allocate dynamic array
    arr = new int[n];
    //Input values
    for(int i = 0; i < n; i ++){
        cin >> arr[i];
    }
    //Write the array to binary file
    ofstream fout;
    fout.open("input.bin", ios::binary);
    if(fout.is_open()){
        fout.write((char*)&n, 4);
        fout.write((char*)arr, 4*n);
    }
    fout.close();
}

void Find_Median(){
    int size;
    int* read_arr;
    //Read binary file
    ifstream fin;
    fin.open("input.bin", ios::binary);
    if(fin.is_open()){
        fin.read((char*) &size, 4);
        read_arr = new int[size];
        fin.read((char*) read_arr, size * 4);
    }
    fin.close();

    //Find median
    if(size % 2 == 1){
        cout << "Median: " << read_arr[(size-1)/2];
        delete[] read_arr;
        return;
    }else{
        double median = ((double)read_arr[size/2] + (double)read_arr[size/2 - 1])/2.0;
        cout << "Median: " << median;
        delete[] read_arr;
        return;
    }
}