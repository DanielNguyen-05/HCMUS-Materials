#pragma once

void writeBinaryFile(int& n, int* arr);
int findNewestDate(int n, int* arr);