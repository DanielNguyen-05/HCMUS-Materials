#include "23127165_HeaderFile_Ex02.hpp"
#include <iostream>

/*
Test case 1: n = 5 and arr[] = {1, 2, 3, 4, 5} --> Output: 5
Test case 2: n = 4 and arr[] = {-1, -2, -3, -4} --> Output: -1
*/

int main() {
    int n, *arr;
    writeBinaryFile(n, arr);
    int result = findNewestDate(n, arr);
    std::cout << "The newest date is: " << result << "\n";
    
    delete[] arr;
    return 0;
}