#include "23127165_HeaderFile_Ex02.hpp"
#include <iostream>
#include <fstream>

void writeBinaryFile(int& n, int* arr) {
    std::cout << "Input the size of the array: ";
    std::cin >> n;
    arr = new int[n];
    std::cout << "Input the array: ";
    for (int i = 0; i < n; i++) std::cin >> arr[i];
    std::ofstream fout;
    fout.open("array.bin", std::ios::binary);
    if (!fout.is_open()) {
        std::cout << "Cannot create the binary file!";
        return;
    }
    fout.write((char*) &n, 4);
    fout.write((char*) arr, n * 4);
    fout.close();
}

int findNewestDate(int n, int* arr) {
    int newest_date = 0;
    int* a;
    int size;
    std::ifstream fin;
    fin.open("array.bin", std::ios::binary);
    if (!fin.is_open()) {
        std::cout << "Cannot open the binary file!";
        return -1;
    }
    fin.read((char*)& size, 4);
    a = new int[size];
    fin.read((char*) a, size * 4);
    fin.close();
    for (int i = 0; i < size; i++) {
        if (a[i] >= newest_date) newest_date = a[i];
    }
    if (newest_date == 0) return -1;
    else return newest_date;
}