#include "23127165_HeaderFile_Ex03.hpp"
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>

void copyFile(const std::string& sourcePath, const std::string& destinationPath) {
    std::ifstream sourceFile(sourcePath, std::ios::binary);
    if (!sourceFile) {
        std::cout << "Error: Unable to open source file." << "\n";
        return;
    }

    std::string filename = sourcePath.substr(sourcePath.find_last_of("/\\") + 1);
    std::string destinationFile = destinationPath + "/" + filename;

    std::ofstream destFile(destinationFile, std::ios::binary);
    if (!destFile) {
        std::cout << "Error: Unable to create destination file." << "\n";
        return;
    }

    destFile << sourceFile.rdbuf();

    std::cout << "File copied successfully to " << destinationFile << "\n";

    sourceFile.close();
    destFile.close();
}
