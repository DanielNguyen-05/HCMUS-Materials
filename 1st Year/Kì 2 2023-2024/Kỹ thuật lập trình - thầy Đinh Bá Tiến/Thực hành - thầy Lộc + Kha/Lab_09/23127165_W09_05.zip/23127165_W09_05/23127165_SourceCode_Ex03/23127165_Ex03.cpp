#include "23127165_HeaderFile_Ex03.hpp"
#include <iostream> 
#include <string>

/*
    Testcase: 
        Input: ./MYCOPYFILE -s test_files/test.txt -d test_files
        Output: File copied successfully to test_files/test.txt
*/

int main() {
    std::cout << "Input your command: ";
    std::string command;
    std::getline(std::cin, command);

    int mark = 0;
    for (int i = 13; i < command.size(); i++) {
        if (command[i] == ' ') {
            mark = i;
            break;
        }
    }

    std::string sourcePath = command.substr(14, mark - 15);
    std::string destinationPath = command.substr(mark + 3, command.size() - mark - 2);

    if (sourcePath.empty() || destinationPath.empty()) {
        std::cout << "Error: Source path or destination path not provided." << "\n";
        return 1;
    }

    copyFile(sourcePath, destinationPath);

    return 0;
}
