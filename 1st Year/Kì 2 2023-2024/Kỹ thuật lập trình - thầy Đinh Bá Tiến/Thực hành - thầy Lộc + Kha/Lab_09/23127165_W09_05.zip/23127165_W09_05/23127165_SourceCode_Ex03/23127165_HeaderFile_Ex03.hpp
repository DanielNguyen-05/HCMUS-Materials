#pragma once

void copyFile(const std::string& sourcePath, const std::string& destinationPath);