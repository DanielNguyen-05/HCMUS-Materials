#include "23127165_HeaderFile_Ex04.hpp"
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>

void splitFileByNumParts(const std::string& sourcePath, const std::string& destinationPath, int numParts) {
    std::ifstream sourceFile(sourcePath, std::ios::binary | std::ios::ate);
    if (!sourceFile) {
        std::cout << "Failed to open source file." << std::endl;
        return;
    }

    // Create the destination directory if it doesn't exist
    std::string command = "mkdir -p " + destinationPath;
    system(command.c_str());

    // Calculate the size of each part
    std::streamsize totalSize = sourceFile.tellg();
    sourceFile.seekg(0, std::ios::beg);
    std::streamsize sizePerPart = totalSize / numParts;
    if (totalSize % numParts != 0) sizePerPart++;

    // Split the file into parts
    int partIndex = 1;
    while (!sourceFile.eof()) {
        std::ostringstream partFileName;
        partFileName << destinationPath << "/part" << std::setw(2) << std::setfill('0') << partIndex;
        std::ofstream partFile(partFileName.str(), std::ios::binary);
        if (!partFile) {
            std::cout << "Failed to create part file: " << partFileName.str() << std::endl;
            return;
        }

        char* buffer = new char[sizePerPart];
        sourceFile.read(buffer, sizePerPart);
        std::streamsize bytesRead = sourceFile.gcount();
        partFile.write(buffer, bytesRead);

        delete[] buffer;
        partFile.close();

        partIndex++;
    }
    sourceFile.close();
}

void splitFileBySize(const std::string& sourcePath, const std::string& destinationPath, int sizePerPart) {
    std::ifstream sourceFile(sourcePath, std::ios::binary);
    if (!sourceFile) {
        std::cout << "Failed to open source file." << std::endl;
        return;
    }

    // Create the destination directory if it doesn't exist
    std::string command = "mkdir -p " + destinationPath;
    system(command.c_str());

    // Split the file into parts
    int partIndex = 1;
    while (!sourceFile.eof()) {
        std::ostringstream partFileName;
        partFileName << destinationPath << "/part" << std::setw(2) << std::setfill('0') << partIndex;
        std::ofstream partFile(partFileName.str(), std::ios::binary);
        if (!partFile) {
            std::cout << "Failed to create part file: " << partFileName.str() << std::endl;
            return;
        }

        char* buffer = new char[sizePerPart];
        sourceFile.read(buffer, sizePerPart);
        std::streamsize bytesRead = sourceFile.gcount();
        partFile.write(buffer, bytesRead);

        delete[] buffer;
        partFile.close();

        partIndex++;
    }

    sourceFile.close();
}