#pragma once

void splitFileByNumParts(const std::string& sourcePath, const std::string& destinationPath, int numParts);

void splitFileBySize(const std::string& sourcePath, const std::string& destinationPath, int sizePerPart);