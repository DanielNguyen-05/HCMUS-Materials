#include "23127165_HeaderFile_Ex04.hpp"
#include <iostream>

/*
    Testcase: 
        Input: ./MYSPLITFILE -s test_files/test.txt -d test_files -numpart 3
        Output: File split successfully.
*/

int main() {
    std::string command;
    std::cout << "Enter command: ";
    std::getline(std::cin, command);

    std::string arg, sourcePath, destinationPath;
    int numParts = 0, sizePerPart = 0;

    size_t pos = 0;
    while ((pos = command.find(' ')) != std::string::npos) {
        arg = command.substr(0, pos);
        command.erase(0, pos + 1);

        if (arg == "-s" && !command.empty()) {
            sourcePath = command.substr(0, command.find(' '));
            command.erase(0, command.find(' ') + 1);
        } else if (arg == "-d" && !command.empty()) {
            destinationPath = command.substr(0, command.find(' '));
            command.erase(0, command.find(' ') + 1);
        } else if (arg == "-numpart" && !command.empty()) {
            numParts = std::stoi(command.substr(0, command.find(' ')));
            command.erase(0, command.find(' ') + 1);
        } else if (arg == "-sizeapart" && !command.empty()) {
            sizePerPart = std::stoi(command.substr(0, command.find(' ')));
            command.erase(0, command.find(' ') + 1);
        }
    }

    if (sourcePath.empty() || destinationPath.empty() || (numParts <= 0 && sizePerPart <= 0)) {
        std::cout << "Invalid command.\n";
        return 1;
    }

    if (numParts > 0) splitFileByNumParts(sourcePath, destinationPath, numParts);
    else if (sizePerPart > 0) splitFileBySize(sourcePath, destinationPath, sizePerPart);

    return 0;
}