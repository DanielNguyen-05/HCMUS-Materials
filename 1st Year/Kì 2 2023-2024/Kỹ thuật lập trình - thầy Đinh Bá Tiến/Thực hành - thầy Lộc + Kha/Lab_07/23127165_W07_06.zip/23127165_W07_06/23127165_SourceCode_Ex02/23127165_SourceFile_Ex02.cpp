#include "23127165_HeaderFile_Ex02.hpp"
#include <iostream>
#include <string>

void inputDecimal(int &x)
{
    std::cout << "Input the decimal number: ";
    std::cin >> x;
}

std::string decimal2Hex(int x)
{
    if (x == 0) return "0";
    std::string hex = decimal2Hex(x / 16);
    if (x % 16 >= 0 && x % 16 <= 9) return hex + std::to_string(x % 16);
    else return hex + (char)(x % 16 + 55);
}

void printHex(std::string s)
{
    std::cout << "Hex: " << s << "\n";
}

void inputHex(std::string &s)
{
    std::cout << "Input the hexadecimal number: ";
    std::cin >> s;
}

int hex2Decimal(std::string s) 
{
    if (s.empty()) return 0;

    int last_digit = 0;
    if (s.back() >= '0' && s.back() <= '9') {
        last_digit = s.back() - '0';
    }
    else if (s.back() >= 'A' && s.back() <= 'F') {
        last_digit = s.back() - 'A' + 10;
    }
    else if (s.back() >= 'a' && s.back() <= 'f') {
        last_digit = s.back() - 'a' + 10;
    }
    s.pop_back();
    
    return hex2Decimal(s) * 16 + last_digit;
}

void printDecimal(int x)
{
    std::cout << "Decimal: " << x << "\n";
}