#pragma once
#include <string>

// This function takes an integer input from the user
void inputDecimal(int &x);

// This function converts a decimal number to hexadecimal
std::string decimal2Hex(int x);

// This function prints the hexadecimal representation of a decimal number
void printHex(std::string s);

// This function takes a hexadecimal number as input from the user
void inputHex(std::string &s);

// This function converts a hexadecimal number to decimal
int hex2Decimal(std::string s);

// This function prints the decimal representation of a hexadecimal number
void printDecimal(int x);