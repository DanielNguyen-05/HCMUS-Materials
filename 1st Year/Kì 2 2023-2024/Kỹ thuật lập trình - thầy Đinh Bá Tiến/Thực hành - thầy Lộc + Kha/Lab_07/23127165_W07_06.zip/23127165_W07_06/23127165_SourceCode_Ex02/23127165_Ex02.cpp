#include "23127165_HeaderFile_Ex02.hpp"
#include <string>

/*
            Test case 1:
    Input: 
        Input the decimal number: 34
        Input the hexadecimal number: ABA
    Output: 
        Hex: 22
        Decimal: 2746

            Test case 2:
    Input: 
        Input the decimal number: 1
        Input the binary number: 1
    Output: 
        Binary: 1
        Decimal: 1

            Test case 1:
    Input: 
        Input the decimal number: 0
        Input the binary number: 0
    Output: 
        Binary: 0
        Decimal: 0
*/

int main()
{
    int x1, x2;
    std::string s1, s2;

    inputDecimal(x1);
    inputHex(s2);

    s1 = decimal2Hex(x1);
    x2 = hex2Decimal(s2);

    printHex(s1);
    printDecimal(x2);

    return 0;
}