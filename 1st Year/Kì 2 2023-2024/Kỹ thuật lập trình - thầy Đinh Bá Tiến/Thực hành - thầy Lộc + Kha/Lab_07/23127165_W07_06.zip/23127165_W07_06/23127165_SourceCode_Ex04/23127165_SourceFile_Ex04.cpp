#include "23127165_HeaderFile_Ex04.hpp"
#include <iostream>

void inputArrays (int* &arr, int &n) {
    std::cout << "Input the size of the array: ";
    std::cin >> n;

    arr = new int[n];
    std::cout << "Input the elements of array: ";
    for (int i = 0; i < n; i++) {
        std::cin >> *(arr + i);
    }
}

void printArray(int* arr, int n) {
    if (n == 0) return;
    else {
        printArray(arr, n - 1);
        std::cout << arr[n - 1] << " ";
    }
}

void printReverseArray(int* arr, int n, int k) {
    if (k == n) return;
    else {
        printReverseArray(arr, n, k + 1);
        std::cout << arr[k] << " ";
    }
}

int sumPositiveNum(int* arr, int n) {
    if (n == 0) return 0;
    else {
        return arr[n - 1] + sumPositiveNum(arr, n - 1);
    }
}

int countDistinctNum(int* arr, int n, bool* check) {
    if (n == 0) return 0;
    else {
        if (check[arr[n - 1]] == true) {
            check[arr[n - 1]] = false;
            return 1 + countDistinctNum(arr, n - 1, check);
        } else return 0 + countDistinctNum(arr, n - 1, check);
    }
}

void printResults(int* arr, bool* check, int n) {
    std::cout << "Array: ";
    printArray(arr, n);
    std::cout << "\n";
    
    std::cout << "Reversed Array: ";
    printReverseArray(arr, n, 0);
    std::cout << "\n";
    
    std::cout << "Sum of positive numbers in the array: ";
    int sum = sumPositiveNum(arr, n);
    std::cout << sum << "\n";

    std::cout << "The number of distinct values in the array: ";
    int cnt = countDistinctNum(arr, n, check);
    std::cout << cnt << "\n";
}

void deleteDynamicArray(int* &arr, bool* &check) {
    delete[] arr;
    delete[] check;
}