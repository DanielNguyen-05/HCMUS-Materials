#include "23127165_HeaderFile_Ex04.hpp"

/*
        Test case 1:
    Input: 5
           1 2 3 4 5
    Output: 
        Array: 1 2 3 4 5 
        Reversed Array: 5 4 3 2 1 
        Sum of positive numbers in the array: 15
        The number of distinct values in the array: 5

        Test case 2:
    Input: 8
           1 9 9 4 5 2 2 1
    Output:
        Array: 1 9 9 4 5 2 2 1 
        Reversed Array: 1 2 2 5 4 9 9 1 
        Sum of positive numbers in the array: 33
        The number of distinct values in the array: 5

        Test case 3:
    Input: 5
           1 1 1 1 1
    Output:
        Array: 1 1 1 1 1 
        Reversed Array: 1 1 1 1 1 
        Sum of positive numbers in the array: 5
        The number of distinct values in the array: 1

        Test case 4:
    Input: 1
           0
    Output:
        Array: 0 
        Reversed Array: 0 
        Sum of positive numbers in the array: 0
        The number of distinct values in the array: 1
*/

int main() {
    int n;
    int* arr;
    inputArrays(arr, n);

    bool* check = new bool[n];
    for (int i = 0; i < n; i++) {
        check[arr[i]] = true;
    }

    printResults(arr, check, n);
    deleteDynamicArray(arr, check);

    return 0;
}