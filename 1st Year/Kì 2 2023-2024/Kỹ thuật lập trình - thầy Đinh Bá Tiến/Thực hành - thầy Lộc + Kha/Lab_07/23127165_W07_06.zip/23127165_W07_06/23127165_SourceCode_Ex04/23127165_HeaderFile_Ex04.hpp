#pragma once

// This function is used to input the number of elements in the array and the array itself
void inputArrays (int* &arr, int &n);

// This function is used to print the array
void printArray(int* arr, int n);

// This function is used to print the array in reverse order
void printReverseArray(int* arr, int n, int k);

// This function is used to calculate the sum of positive numbers in the array
int sumPositiveNum(int* arr, int n);

// This function is used to count the number of distinct values in the array
int countDistinctNum(int* arr, int n, bool* check);

// This function is used to print the array, the reversed array, the sum of positive numbers in the array, and the number of distinct values in the array
void printResults(int* arr, bool* check, int n);

// This function is used to delete the dynamic arrays
void deleteDynamicArray(int* &arr, bool* &check);