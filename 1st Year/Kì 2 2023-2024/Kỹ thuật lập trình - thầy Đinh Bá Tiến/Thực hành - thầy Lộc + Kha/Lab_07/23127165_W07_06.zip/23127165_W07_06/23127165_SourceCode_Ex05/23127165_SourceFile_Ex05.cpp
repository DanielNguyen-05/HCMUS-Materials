#include "23127165_HeaderFile_Ex05.hpp"
#include <iostream>

void addNode(Node* &pHead, int data) {
    Node* newNode = new Node;
    newNode->data = data;
    newNode->pNext = pHead;
    if (pHead == nullptr) {
        pHead = newNode;
        pHead->pNext = nullptr;
    } else {
        Node* cur = pHead;
        while (cur->pNext != nullptr) cur = cur->pNext;
        cur->pNext = newNode;
        newNode->pNext = nullptr;
    }
}

void inputList(Node* &pHead, int &n) {
    std::cout << "Enter the number of elements: ";
    std::cin >> n;
    std::cout << "Enter the elements: ";
    for (int i = 0; i < n; i++) {
        int data;
        std::cin >> data;
        addNode(pHead, data);
    }
}

void printList(Node* pHead) {
    Node* cur = pHead;
    while (cur != nullptr) {
        std::cout << cur->data << " ";
        cur = cur->pNext;
    }
    std::cout << "\n";
}

void deleteList(Node* &pHead) {
    Node* cur = pHead;
    while (cur != nullptr) {
        Node* tmp = cur;
        cur = cur->pNext;
        delete tmp;
    }
    pHead = nullptr;
}

void chooseEx(int &choice) {
    std::cout << "Enter the assignment: ";
    std::cin >> choice;
}

    // 5.1
void inputElementToSearch(int &x1) {
    std::cout << "Enter the element to search: ";
    std::cin >> x1;
}

void searchAnElement(Node* pHead, int x, int index) {
    if (pHead == nullptr) return;
    if (pHead->data == x) {
        std::cout << "The element " << x << " is at the position: " << index;
        return;
    } else searchAnElement(pHead->pNext, x, index + 1);
}

    // 5.2
void reverseLinkedList(Node* &pHead) {
    if (pHead == nullptr || pHead->pNext == nullptr) return;

    Node* tmp = pHead->pNext;
    reverseLinkedList(tmp);

    pHead->pNext->pNext = pHead;
    pHead->pNext = nullptr;
    pHead = tmp;
}

    // 5.3
int getLength(Node* pHead) {
    if (pHead == nullptr) return 0;
    return 1 + getLength(pHead->pNext);
}

Node* getMiddleNodeHelper(Node* pHead, int &currentIndex, int middleIndex) {
    if (pHead == nullptr) return nullptr;
    if (currentIndex == middleIndex) return pHead;
    currentIndex++;
    return getMiddleNodeHelper(pHead->pNext, currentIndex, middleIndex);
}

Node* getMiddleNode(Node* pHead) {
    int length = getLength(pHead);
    int middleIndex = (length / 2) + 1;
    int currentIndex = 1;
    return getMiddleNodeHelper(pHead, currentIndex, middleIndex);
}

void printMiddleNode(Node* pHead) {
    Node* middleNode = getMiddleNode(pHead);
    std::cout << "The data of the middle node is: " << middleNode->data;
}

    // 5.4
void inputElementToDelete(int &x2) {
    std::cout << "Enter the element to delete: ";
    std::cin >> x2;
}

void deleteX(Node* &pHead, int x2) {
    if (pHead == nullptr) return;
    if (pHead->data == x2) {
        Node* tmp = pHead;
        pHead = pHead->pNext;
        delete tmp;
        deleteX(pHead, x2);
    } else deleteX(pHead->pNext, x2);
}

    // 5.5
void removeDuplicates(Node* &pHead, bool* check) {
    if (pHead == nullptr) return;
    if (check[pHead->data]) {
        Node* tmp = pHead;
        pHead = pHead->pNext;
        delete tmp;
        removeDuplicates(pHead, check);
    } else {
        check[pHead->data] = true;
        removeDuplicates(pHead->pNext, check);
    }
}