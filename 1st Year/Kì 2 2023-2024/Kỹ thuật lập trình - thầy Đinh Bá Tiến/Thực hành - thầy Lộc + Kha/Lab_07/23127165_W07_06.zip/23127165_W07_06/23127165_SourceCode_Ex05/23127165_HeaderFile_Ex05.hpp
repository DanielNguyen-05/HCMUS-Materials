#pragma once

struct Node {
    int data;
    Node* pNext;
};

// This function is used to add a new node to the end of the linked list
void addNode(Node* &pHead, int data);

// This function is used to input the linked list
void inputList(Node* &pHead, int &n);

// This function is used to print the linked list
void printList(Node* pHead);

// This function is used to delete the linked list
void deleteList(Node* &pHead);

// This function is used to choose the assignment
void chooseEx(int &choice);

    // 5.1
// This function is used to input an element for searching
void inputElementToSearch(int &x1);

// This function is used to search an element in the linked list
void searchAnElement(Node* pHead, int x1, int index);

    // 5.2
// This function is used to reverse the linked list
void reverseLinkedList(Node* &pHead);

    // 5.3
// This function is used to get the length of the linked list
int getLength(Node* pHead);

// This function is used support to get the middle node of the linked list
Node* getMiddleNodeHelper(Node* pHead, int &currentIndex, int middleIndex);

// This function is used to get the middle node of the linked list
Node* getMiddleNode(Node* pHead);

// This function is used to print the data of the middle node of the linked list
void printMiddleNode(Node* pHead);

    // 5.4
// This function is used to input an element for deleting
void inputElementToDelete(int &x2);
// This function is used to delete the first node of the linked list
void deleteX(Node* &pHead, int x2);

    // 5.5
// This function is used to remove the duplicates in the linked list
void removeDuplicates(Node* &pHead, bool* check);