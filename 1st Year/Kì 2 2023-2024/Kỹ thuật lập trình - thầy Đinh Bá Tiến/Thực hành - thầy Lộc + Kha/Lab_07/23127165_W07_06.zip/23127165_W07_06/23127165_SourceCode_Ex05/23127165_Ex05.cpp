#include "23127165_HeaderFile_Ex05.hpp"

/*
                    Test case 1:
    Input: 10
           1 2 2 18 23 3 1 4 4 5

    Input 5.1: 10
               1 2 2 18 23 3 1 4 4 5
               18
    Output 5.1: The element 18 is at the position: 4

    Input 5.2: 10
               1 2 2 18 23 3 1 4 4 5 
    Output 5.2: 5 4 4 1 3 23 18 2 2 1

    Input 5.3: 10
               1 2 2 18 23 3 1 4 4 5
    Output 5.3: The data of the middle node is: 3

    Input 5.4: 10
               1 2 2 18 23 3 1 4 4 5
               4
    Output 5.4: 1 2 2 18 23 3 1 5 

    Input 5.5: 10
               1 2 2 18 23 3 1 4 4 5
    Output 5.5: 1 2 18 23 3 4 5 

                    Test case 2:
    Input 5.1: 7
               1 2 2 4 5 9 9
               9
    Output 5.1: The element 9 is at the position: 6

    Input 5.2: 7
               1 2 2 4 5 9 9
    Output 5.2: 9 9 5 4 2 2 1

    Input 5.3: 7
               1 2 2 4 5 9 9
    Output 5.3: The data of the middle node is: 4

    Input 5.4: 7
               1 2 2 4 5 9 9
               9
    Output 5.4: 1 2  2 4 5

    Input 5.5: 7
               1 2 2 4 5 9 9
    Output 5.5: 1 2 4 5 9 

                    Test case 3:
    Input 5.1: 7
               1 1 1 1 1 1 1
               1
    Output 5.1: The element 9 is at the position: 1

    Input 5.2: 7
               1 1 1 1 1 1 1
    Output 5.2: 1 1 1 1 1 1 1

    Input 5.3: 7
               1 1 1 1 1 1 1
    Output 5.3: The data of the middle node is: 1

    Input 5.4: 7
               1 1 1 1 1 1 1
               1
    Output 5.4:

    Input 5.5: 7
               1 1 1 1 1 1 1
    Output 5.5: 1
*/

int main() {
    int n, x1, x2;
    Node* pHead = nullptr;
    int choice;
    chooseEx(choice);

                bool* check = new bool[n];
            Node* cur = pHead;
            while (cur != nullptr) {
                check[cur->data] = false;
                cur = cur->pNext;
        }
    switch (choice) {
        case 1: // 5.1
            inputList(pHead, n);
            inputElementToSearch(x1);
            searchAnElement(pHead, x1, 1);
            deleteList(pHead);
            break;
        case 2: // 5.2
            inputList(pHead, n);
            reverseLinkedList(pHead);
            printList(pHead);
            deleteList(pHead);
            break;
        case 3: // 5.3
            inputList(pHead, n);
            printMiddleNode(pHead);
            deleteList(pHead);
            break;
        case 4: // 5.4
            inputList(pHead, n);
            inputElementToDelete(x2);
            deleteX(pHead, x2);
            printList(pHead);
            deleteList(pHead);
            break;
        case 5: // 5.5
            inputList(pHead, n);
            removeDuplicates(pHead, check);
            printList(pHead);
            delete[] check;
            deleteList(pHead);
            break;
        default:
            break;
    }

    return 0;
}