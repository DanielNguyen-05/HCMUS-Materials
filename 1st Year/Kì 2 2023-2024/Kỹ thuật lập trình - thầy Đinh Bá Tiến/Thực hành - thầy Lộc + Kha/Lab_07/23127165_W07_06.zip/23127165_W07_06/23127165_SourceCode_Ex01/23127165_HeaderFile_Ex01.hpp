#pragma once
#include <string>

// This function takes an integer input from the user
void inputDecimal(int &x);

// This function converts a decimal number to binary
std::string decimal2Binary(int x);

// This function prints the binary representation of a decimal number
void printBinary(std::string s);

// This function takes a binary number as input from the user
void inputBinary(std::string &s);

// This function converts a binary number to decimal
int binary2Decimal(std::string s);

// This function prints the decimal representation of a binary number
void printDecimal(int x);