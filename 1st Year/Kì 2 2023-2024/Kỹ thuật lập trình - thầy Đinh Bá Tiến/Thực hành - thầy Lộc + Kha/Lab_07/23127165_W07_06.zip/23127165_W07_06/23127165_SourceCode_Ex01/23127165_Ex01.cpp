#include "23127165_HeaderFile_Ex01.hpp"
#include <string>

/*
            Test case 1:
    Input: 
        Input the decimal number: 16
        Input the binary number: 1101
    Output: 
        Binary: 10000
        Decimal: 13

            Test case 2:
    Input: 
        Input the decimal number: 1
        Input the binary number: 1
    Output: 
        Binary: 1
        Decimal: 1

            Test case 1:
    Input: 
        Input the decimal number: 0
        Input the binary number: 0
    Output: 
        Binary: 0
        Decimal: 0
*/

int main()
{
    int x1, x2;
    std::string s1, s2;

    inputDecimal(x1);
    inputBinary(s2);

    s1 = decimal2Binary(x1);
    x2 = binary2Decimal(s2);

    printBinary(s1);
    printDecimal(x2);

    return 0;
}