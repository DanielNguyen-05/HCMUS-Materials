#include "23127165_HeaderFile_Ex01.hpp"
#include <iostream>
#include <string>

void inputDecimal(int &x)
{
    std::cout << "Input the decimal number: ";
    std::cin >> x;
}

std::string decimal2Binary(int x)
{
    if (x == 0) return "0";
    if (x == 1) return "1";
    else return std::to_string(x % 2) + decimal2Binary(x / 2);
}

void printBinary(std::string s)
{
    std::cout << "\n";
    std::cout << "Binary: ";
    for (int i = s.length() - 1; i >= 0; i--) 
        std::cout << s[i];
    std::cout << "\n";
}

void inputBinary(std::string &s)
{
    std::cout << "Input the binary number: ";
    std::cin >> s;
}

int binary2Decimal(std::string s) 
{
    if (s.empty()) return 0;

    int last_digit = s.back() - '0';
    
    s.pop_back();
    
    return binary2Decimal(s) * 2 + last_digit;
}

void printDecimal(int x)
{
    std::cout << "Decimal: " << x << "\n";
}