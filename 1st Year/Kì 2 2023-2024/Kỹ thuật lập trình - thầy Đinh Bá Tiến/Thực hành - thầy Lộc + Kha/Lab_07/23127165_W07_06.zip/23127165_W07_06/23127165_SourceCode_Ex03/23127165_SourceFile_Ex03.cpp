#include "23127165_HeaderFile_Ex03.hpp"
#include <iostream>

void inputN(int &n)
{
	std::cout << "Enter a positive integer: ";
    std::cin >> n;
}

int printRecaman(int n, bool *mark)
{
	if (n == 0) {
		std::cout << 0 << " ";
		return 0;
	}
	int x = printRecaman(n - 1, mark);
	if (x - n > 0 && !mark[x - n]) {
		std::cout << x - n << " ";
		mark[x - n] = true;
		return x - n;
	}
	else {
		std::cout << x + n << " ";
		mark[x + n] = true;
		return x + n;
	}
}
