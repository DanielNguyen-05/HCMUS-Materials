#include "23127165_HeaderFile_Ex03.hpp"

/*
		Test case 1:
	Input: 5
	Output: 0 1 3 6 2 7

		Test case 2:
	Input: 10
	Output: 0 1 3 6 2 7 13 20 12 21

		Test case 3:
	Input: 1
	Output: 0
*/

int main(){
	int n;

	bool *mark = new bool[n + 1];
	for (int i = 0; i <= n; i++) {
		mark[i] = false;
	}

	inputN(n);
	n = n - 1;
	printRecaman(n, mark);

	delete[] mark;

	return 0;
}