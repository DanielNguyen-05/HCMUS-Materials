#pragma once

// This function will take in an integer n
void inputN(int &n);

// This function will print the Recaman sequence up to the nth term
int printRecaman(int n, bool *mark);