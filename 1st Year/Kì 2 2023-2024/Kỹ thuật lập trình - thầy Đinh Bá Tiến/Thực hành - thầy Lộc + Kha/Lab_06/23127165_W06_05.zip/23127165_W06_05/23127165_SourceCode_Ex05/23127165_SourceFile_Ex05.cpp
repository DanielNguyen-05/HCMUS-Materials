#include "23127165_HeaderFile_Ex05.hpp"
#include <iostream>
#include <stack>
#include <string>

std::string decimalToBinary(unsigned int decimalInput) {
    if (decimalInput == 0) return "0";

    std::string binaryOutput;
    while (decimalInput > 0) {
        binaryOutput = std::to_string(decimalInput % 2) + binaryOutput;
        decimalInput /= 2;
    }

    return binaryOutput;
}

unsigned int binaryToDecimal(std::string binaryInput) {
    unsigned int decimalOutput = 0;
    int length = binaryInput.length();

    for (int i = 0; i < length; i++) {
        if (binaryInput[i] == '1') {
            decimalOutput += 1 << (length - 1 - i);
        }
    }

    return decimalOutput;
}

std::string decimalToHex(unsigned int decimalInput) {
    if (decimalInput == 0) return "0";

    std::stack<char> hexStack;
    std::string hexDigits = "0123456789ABCDEF";
    std::string hexOutput;

    while (decimalInput > 0) {
        hexStack.push(hexDigits[decimalInput % 16]);
        decimalInput /= 16;
    }

    while (!hexStack.empty()) {
        hexOutput += hexStack.top();
        hexStack.pop();
    }

    return hexOutput;
}

unsigned int hexToDecimal(std::string hexInput) {
    unsigned int decimalOutput = 0;
    int length = hexInput.length();

    for (int i = 0; i < length; i++) {
        char hexDigit = toupper(hexInput[i]);
        int decimalDigit;

        if (hexDigit >= '0' && hexDigit <= '9') decimalDigit = hexDigit - '0';
        else if (hexDigit >= 'A' && hexDigit <= 'F') decimalDigit = 10 + (hexDigit - 'A');
        else std::cout << "Invalid hexadecimal digit" << "\n";

        decimalOutput = decimalOutput * 16 + decimalDigit;
    }

    return decimalOutput;
}

void inputDecimal(unsigned int &decimalInput) {
    std::cout << "Enter a decimal number: ";
    std::cin >> decimalInput;
}

void inputBinary(std::string &binaryInput) {
    std::cout << "Enter a binary number: ";
    std::cin >> binaryInput;
}

void inputHex(std::string &hexInput) {
    std::cout << "Enter a hexadecimal number: ";
    std::cin >> hexInput;
}

void printBinary(std::string binaryOutput) {
    std::cout << "The binary number is: " << binaryOutput << "\n \n";
}

void printDecimal(unsigned int decimalOutput) {
    std::cout << "The decimal number is: " << decimalOutput << "\n \n";
}

void printHex(std::string hexOutput) {
    std::cout << "The hexadecimal number is: " << hexOutput << "\n \n";
}