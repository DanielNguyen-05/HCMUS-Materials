#pragma once
#include <string>

/*
        Test case 1:
    Input: 3 111 1234 B
    Output: 11 7 4D2 11

        Test case 2:
    Input: 0 0 0 A
    Output: 0 0 0 10
*/


// This function is used to convert decimal to binary using stack
std::string decimalToBinary(unsigned int decimalInput);

// This function is used to convert binary to decimal
unsigned int binaryToDecimal(std::string binaryInput);

// This function is used to convert decimal to hexadecimal using stack
std::string decimalToHex(unsigned int decimalInput);

// This function is used to convert hexadecimal to decimal
unsigned int hexToDecimal(std::string hexInput);

// This function is used to input decimal number
void inputDecimal(unsigned int &decimalInput);

// This function is used to input binary number
void inputBinary(std::string &binaryInput);

// This function is used to input hexadecimal number
void inputHex(std::string &hexInput);

// This function is used to print binary number
void printBinary(std::string binaryOutput);

// This function is used to print decimal number
void printDecimal(unsigned int decimalOutput);

// This function is used to print hexadecimal number
void printHex(std::string hexOutput);
