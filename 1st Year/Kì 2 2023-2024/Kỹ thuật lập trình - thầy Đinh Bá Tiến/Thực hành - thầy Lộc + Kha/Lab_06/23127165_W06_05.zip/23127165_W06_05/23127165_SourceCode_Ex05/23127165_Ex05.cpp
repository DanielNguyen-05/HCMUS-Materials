#include "23127165_HeaderFile_Ex05.hpp"

int main() {
    unsigned int decimalInput1;
    unsigned int decimalInput2;
    std::string binaryInput;
    std::string hexInput;

    inputDecimal(decimalInput1);
    std::string binaryOutput = decimalToBinary(decimalInput1);
    printBinary(binaryOutput);

    inputBinary(binaryInput);
    unsigned int decimalOutput1 = binaryToDecimal(binaryInput);
    printDecimal(decimalOutput1);

    inputDecimal(decimalInput2);
    std::string hexOutput = decimalToHex(decimalInput2);
    printHex(hexOutput);

    inputHex(hexInput);
    unsigned int decimalOutput2 = hexToDecimal(hexInput);
    printDecimal(decimalOutput2);

    return 0;
}