#include "23127165_HeaderFile_Ex01.hpp"
#include <iostream>

void init(Stack& s, int capacity) 
{
    s.data = new int[capacity];
    s.top = -1;
    s.capacity = capacity;
}

void push(Stack& s, int x) 
{
    if (s.top == s.capacity - 1) {
        std::cout << "Stack overflow!" << "\n";
        return;
    }
    s.data[++s.top] = x;
}

int pop(Stack& s) 
{
    if (s.top == -1) {
        std::cout << "Stack underflow!" << "\n";
        return -1;
    }
    return s.data[s.top--];
}

bool isEmpty(Stack s) 
{
    return s.top == -1;
}

void empty(Stack& s) 
{
    s.top = -1;
}

int size(Stack s) 
{
    return s.top + 1;
}