#include "23127165_HeaderFile_Ex01.hpp"
#include <iostream>

int main() {
    Stack s;

    init(s, 5);

    push(s, 1);
    push(s, 2);
    push(s, 3);

    std::cout << "Size of stack: " << size(s) << "\n";

    while (!isEmpty(s)) {
        std::cout << "Popped element: " << pop(s) << "\n";
    }

    empty(s);

    std::cout << "Size of stack after emptying: " << size(s) << "\n";

    delete[] s.data;

    return 0;
}