#include "23127165_HeaderFile_Ex02.hpp"
#include <iostream>

void init(Stack& s, int capacity)
{
    s.head = nullptr;
    s.capacity = capacity;
};

void push(Stack& s, int x)
{
    if (size(s) == s.capacity) {
        std::cout << "Stack is full!" << "\n";
        return;
    }
    Node* newNode = new Node;
    newNode->data = x;
    newNode->next = s.head;
    s.head = newNode;
}

int pop(Stack& s)
{
    if (isEmpty(s)) {
        std::cout << "Stack is empty!" << "\n";
        return -1;
    }
    Node* tmp = s.head;
    int value = tmp->data;
    s.head = s.head->next;
    delete tmp;
    return value;
}

bool isEmpty(Stack s)
{
    return s.head == nullptr;
}

void empty(Stack& s)
{
    while (s.head != nullptr) {
        Node* tmp = s.head;
        s.head = s.head->next;
        delete tmp;
    }
}

int size(Stack s)
{
    int cnt = 0;
    while (s.head != nullptr) {
        cnt++;
        s.head = s.head->next;
    }
    return cnt;
}
