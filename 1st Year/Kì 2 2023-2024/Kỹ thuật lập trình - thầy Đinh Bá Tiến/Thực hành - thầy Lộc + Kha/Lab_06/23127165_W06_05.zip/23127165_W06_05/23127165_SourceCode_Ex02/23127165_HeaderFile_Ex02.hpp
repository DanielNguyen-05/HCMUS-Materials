#pragma once

struct Node {
    int data;
    Node* next;
};

struct Stack 
{
    Node* head;
    int capacity;
};

// This funtion initializes the stack with a given capacity.
void init(Stack& s, int capacity);

// This function pushes an element to the top of the stack.
void push(Stack& s, int x);

// This function pops the top element from the stack, return the value of the removed one.
int pop(Stack& s);

// This function checks if the stack is empty.
bool isEmpty(Stack s);

// This function empties the stack.
void empty(Stack& s);

// This function returns the size of the stack.
int size(Stack s);