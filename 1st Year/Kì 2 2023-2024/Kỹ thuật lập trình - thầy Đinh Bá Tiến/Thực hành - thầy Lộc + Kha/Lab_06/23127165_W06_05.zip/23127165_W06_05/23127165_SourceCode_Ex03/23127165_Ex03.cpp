#include "23127165_HeaderFile_Ex03.hpp"
#include <iostream>

int main() {
    Queue q;

    init(q, 5);

    enqueue(q, 1);
    enqueue(q, 2);
    enqueue(q, 3);

    std::cout << "Queue size: " << size(q) << "\n";

    while (!isEmpty(q)) std::cout << "Dequeued: " << dequeue(q) << "\n";

    std::cout << "Queue size after dequeuing all elements: " << size(q) << "\n";

    return 0;
}