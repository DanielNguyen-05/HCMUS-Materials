#include "23127165_HeaderFile_Ex03.hpp"
#include <iostream>

void init(Queue& q, int capacity) {
    q.data = new int[capacity];
    q.capacity = capacity;
    q.in = 0;
    q.out = 0;
}

void enqueue(Queue& q, int x) {
    if ((q.in + 1) % q.capacity == q.out) {
        std::cout << "Error: Queue is full!" << "\n";
        return;
    }
    q.data[q.in] = x;
    q.in = (q.in + 1) % q.capacity;
}

int dequeue(Queue& q) {
    if (q.in == q.out) {
        std::cout << "Error: Queue is empty!" << "\n";
        return -1;
    }
    int value = q.data[q.out];
    q.out = (q.out + 1) % q.capacity;
    return value;
}

bool isEmpty(Queue q) {
    return q.in == q.out;
}

void empty(Queue& q) {
    q.in = 0;
    q.out = 0;
}

int size(Queue q) {
    if (q.in >= q.out) return q.in - q.out;
    else return q.capacity - q.out + q.in;
}