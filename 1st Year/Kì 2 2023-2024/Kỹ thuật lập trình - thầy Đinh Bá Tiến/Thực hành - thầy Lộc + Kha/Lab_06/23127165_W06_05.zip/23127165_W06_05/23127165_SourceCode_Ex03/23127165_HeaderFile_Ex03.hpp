#pragma once

struct Queue {
    int* data;
    int in;
    int out;
    int capacity;
};

// This function initializes the queue with a given capacity.
void init(Queue& s, int capacity);

// This function adds an integer to the queue.
void enqueue(Queue& s, int x);

// This function to remove the oldest element from the queue and return its value
int dequeue(Queue& s);

// This function checks if the queue is empty.
bool isEmpty(Queue s);

// This function empties the queue.
void empty(Queue& s);

// This function returns the number of elements in the queue.
int size(Queue s);