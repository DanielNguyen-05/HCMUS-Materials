#include "23127165_HeaderFile_Ex10.hpp"
#include <string>

/*
        Testcase 1:
    Input: 12ba
    Output: 
            1 2 b a 
            1 2 a b 
            1 b 2 a 
            1 b a 2 
            1 a 2 b 
            1 a b 2 
            2 1 b a 
            2 1 a b 
            2 b 1 a 
            2 b a 1 
            2 a 1 b 
            2 a b 1 
            b 1 2 a 
            b 1 a 2 
            b 2 1 a 
            b 2 a 1 
            b a 1 2 
            b a 2 1 
            a 1 2 b 
            a 1 b 2 
            a 2 1 b 
            a 2 b 1 
            a b 1 2 
            a b 2 1 
        
        Testcase 2:
    Input: a
    Output: a
*/

int main() {
    std::string str;
    inputString(str);

    bool* check = new bool[str.length()];
    for (int i = 0; i < str.length(); i++) {
        check[i] = true;
    }

    tryK(0, str, check, str);
    delete[] check;
    return 0;
}