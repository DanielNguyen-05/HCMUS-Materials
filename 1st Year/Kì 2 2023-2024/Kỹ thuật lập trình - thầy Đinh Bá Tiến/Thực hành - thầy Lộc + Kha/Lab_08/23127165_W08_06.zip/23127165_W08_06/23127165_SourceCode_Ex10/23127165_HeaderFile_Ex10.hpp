#pragma once
#include <string>

// This function is used to input a string from the user
void inputString(std::string &str);

// This function is used to display a string
void display(std::string str);

// This function is used to try all possible permutations of a string
void tryK(int k, std::string str, bool* check, std::string slots);