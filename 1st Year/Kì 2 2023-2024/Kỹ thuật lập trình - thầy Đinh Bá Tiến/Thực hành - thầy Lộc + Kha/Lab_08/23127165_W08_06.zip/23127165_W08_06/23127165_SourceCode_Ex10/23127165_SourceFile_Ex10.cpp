#include "23127165_HeaderFile_Ex10.hpp"
#include <iostream>
#include <string>

void inputString(std::string &str) {
    std::cout << "Input the string: ";
    std::getline(std::cin, str);
}

void display(std::string str) {
    for (int i = 0; i < str.length(); i++) {
        std::cout << str[i] << " ";
    }
    std::cout << "\n";
}

void tryK(int k, std::string str, bool* check, std::string slots) {
    if (k == str.length()) {
        display(slots);
    } else {
        for (int i = 0; i < str.length(); i++) {
            if (check[i]) {
                slots[k] = str[i];
                check[i] = false;
                tryK(k + 1, str, check, slots);
                check[i] = true;
            }
        }
    }
}