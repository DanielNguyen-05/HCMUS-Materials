#pragma once

int dem = 0;

// This function is used to input the size of the chessboard
void inputSize(int& n);

// This function is used to display the chessboard
void display(int* slots, int n);

// This function is used to try the k-th row
void tryK (int k, int* slots, int n, bool* notUsedCol, bool* notUsedD1, bool* notUsedD2);