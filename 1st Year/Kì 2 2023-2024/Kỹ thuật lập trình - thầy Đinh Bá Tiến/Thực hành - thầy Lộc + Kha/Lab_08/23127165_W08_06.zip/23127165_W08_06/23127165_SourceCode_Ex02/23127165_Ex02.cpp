#include "23127165_HeaderFile_Ex02.hpp"

/*
        Testcase:
    Input: 4
    Output: 
           0  1  0  0 
           0  0  0  1 
           1  0  0  0 
           0  0  1  0 

           0  0  1  0 
           1  0  0  0 
           0  0  0  1 
           0  1  0  0
*/

int main() {
    int n;
    inputSize(n);
    int* slots = new int[n];

    bool* notUsedCol = new bool[n];
    bool* notUsedD1 = new bool[2 * n - 1];
    bool* notUsedD2 = new bool[2 * n - 1];

    for (int i = 0; i < n; i++) {
        notUsedCol[i] = true;
    }

    for (int i = 0; i < 2 * n - 1; i++) {
        notUsedD1[i] = notUsedD2[i] = true;
    }
    
    tryK(0, slots, n, notUsedCol, notUsedD1, notUsedD2);

    delete[] slots;
    delete[] notUsedCol;
    delete[] notUsedD1;
    delete[] notUsedD2;

    return 0;
}