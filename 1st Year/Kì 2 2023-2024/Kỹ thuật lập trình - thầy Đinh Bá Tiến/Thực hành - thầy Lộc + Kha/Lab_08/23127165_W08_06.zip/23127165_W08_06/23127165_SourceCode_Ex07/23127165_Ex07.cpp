#include <iostream>
#include<vector>
using namespace std;

class Solution {
public:
    vector<vector<int> > permute(vector<int>& nums) {
        vector<vector<int> > result;
        vector<int> slots(nums.size());
        vector<bool> check(nums.size(), true);
        tryK(0, nums, nums.size(), check, slots, result);
        return result;
    }

private:
    void tryK(int k, vector<int>& a, int n, vector<bool>& check, vector<int>& slots, vector<vector<int> >& result) {
        if (k == n) {
            result.push_back(slots);
        } else {
            for (int i = 0; i < n; i++) {
                if (check[i]) {
                    slots[k] = a[i];
                    check[i] = false;
                    tryK(k + 1, a, n, check, slots, result);
                    check[i] = true;
                }
            }
        }
    }
};

int main() {
    int size;
    cout << "Enter the size of the array: ";
    cin >> size;
    
    vector<int> nums(size);
    cout << "Enter the elements of the array: ";
    for (int i = 0; i < size; i++) {
        cin >> nums[i];
    }
    
    Solution solution;
    vector<vector<int> > result = solution.permute(nums);
    for (int i = 0; i < result.size(); i++) {
        for (int j = 0; j < result[i].size(); j++) {
            cout << result[i][j] << " ";
        }
        cout << endl;
    }
    return 0;
}