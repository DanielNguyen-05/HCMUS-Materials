#include "23127165_HeaderFile_Ex06.hpp"
#include <iostream>

void inputN(int& N) {
    std::cout << "Input the number N: ";
    std::cin >> N;
}

void display(int* slots, int N) {
    for (int i = 0; i < N; i++) {
        std::cout << slots[i] + 1 << " ";
    }
    std::cout << "\n";
}

void tryK (int k, int* slots, int N, bool* notUsed) {
    if (k == N) display(slots, N);
    else for (int i = 0; i < N; i++) {
        if (notUsed[i] == true) {
            slots[k] = i;
            notUsed[i] = false;
            tryK(k + 1, slots, N, notUsed);
            notUsed[i] = true;
        }
    }
}