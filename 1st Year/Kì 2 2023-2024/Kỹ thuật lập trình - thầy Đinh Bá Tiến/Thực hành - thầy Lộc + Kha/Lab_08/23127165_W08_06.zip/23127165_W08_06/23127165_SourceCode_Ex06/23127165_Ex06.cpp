#include "23127165_HeaderFile_Ex06.hpp"

/*
        Testcase 1:
    Input: 3
    Output: 
            1 2 3 
            1 3 2 
            2 1 3 
            2 3 1 
            3 1 2 
            3 2 1
        
        Testcase 2:
    Input: 1
    Output: 1
*/

int main() {
    int N;
    inputN(N);    
    int* slots = new int[N];   
    bool* notUsed = new bool[N];
    for (int i = 0; i < N; i++) {
        notUsed[i] = true;
    }
    tryK(0, slots, N , notUsed);

    delete[] slots;
    delete[] notUsed;

    return 0;
}