#pragma once

// This function is used to input the number of elements in the array
void inputN(int& N);

// This function is used to display the array
void display(int* slots, int N);

// This function is used to try the k-th element of the array
void tryK (int k, int* slots, int N, bool* notUsed);

