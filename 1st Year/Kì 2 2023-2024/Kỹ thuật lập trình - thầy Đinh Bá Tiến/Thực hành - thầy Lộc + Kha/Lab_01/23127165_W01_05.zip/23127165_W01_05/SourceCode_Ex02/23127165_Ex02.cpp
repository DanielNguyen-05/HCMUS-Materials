#include "23127165_HeaderFile_Ex02.hpp"
#include "23127165_SourceFile_Ex02.cpp"

int main() 
{
    int n;
    Student sv[100];

    std::ifstream fin("input.txt");
    if (!fin.is_open()) 
    {
        std::cout << "File does not exist" << "\n";
        return 1;
    }
    getList(fin, sv, n);
    fin.close();

    double max_gpa = findMaxGpa(sv, n);

    std::ofstream fout("honors.txt");
    if (!fout.is_open()) 
    {
        std::cout << "File does not exist" << "\n";
        return 1;
    }
    printList(fout, sv, n, max_gpa);
    fout.close();

    return 0;
}