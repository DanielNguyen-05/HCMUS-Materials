#include "23127165_HeaderFile_Ex02.hpp"

void getList(std::ifstream& fin, Student sv[], int& n) 
{
    int i = 0;
    while (!fin.eof()) 
    {
        fin >> sv[i].id;
        fin.ignore();
        fin.getline(sv[i].full_name, 100, '|');
        fin >> sv[i].gpa;
        fin.ignore();
        i++;
    }
    n = i;
}

double findMaxGpa(Student sv[], int n) 
{
    double max_gpa = -1;
    for (int i = 0; i < n; i++) 
    {
        max_gpa = std::max(max_gpa, sv[i].gpa);
    }
    return max_gpa;
}

void printList(std::ofstream& fout, Student sv[], int n, double max_gpa)
{
    for (int i = 0; i < n; i++) 
    {
        if (sv[i].gpa == max_gpa) 
        {
            fout << sv[i].id << " " << sv[i].full_name << " " << sv[i].gpa << "\n";
        }
    }
}