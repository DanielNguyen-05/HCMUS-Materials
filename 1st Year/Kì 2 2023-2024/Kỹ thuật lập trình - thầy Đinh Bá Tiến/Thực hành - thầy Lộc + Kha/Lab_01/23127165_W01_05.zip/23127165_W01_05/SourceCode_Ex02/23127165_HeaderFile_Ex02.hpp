#pragma once
// Nội dung file của em ạ (các thành phần cách nhau bởi dấu "|"):
// 23127165|Nguyen Hai Dang|9.9
// 23127004|Le Nhat Khoi|10.0
// 23127002|Vuong Gia Bao|9.8
// 23127504|Le Gia Huy|9.4
// 23127111|Nguyen Van Hai|10.0
// 23127188|Pham Tuan Kiet|9.6

#include <iostream>
#include <fstream>

struct Student 
{
    int id;
    char full_name[100];
    double gpa;
};

// Đây là hàm để lấy thông tin sinh viên từ file input.txt ạ:
void getList(std::ifstream& fin, Student sv[], int& n);

// Đây là hàm để tìm ra điểm gpa cao nhất
double findMaxGpa(Student sv[], int n);

// Đây là hàm xuất ra file honors.txt chứa thông tin của (các) sinh viên có điểm gpa cao nhất ạ:
void printList(std::ofstream& fout, Student sv[], int n, double max_gpa);