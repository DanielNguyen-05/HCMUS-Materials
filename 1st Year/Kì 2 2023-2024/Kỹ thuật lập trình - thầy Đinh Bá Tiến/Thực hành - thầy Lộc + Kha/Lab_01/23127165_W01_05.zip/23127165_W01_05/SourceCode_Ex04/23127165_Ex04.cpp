#include <iostream>

int main()
{
    int n, k;
    std::cin >> n >> k;
    int a[2000];
    for (int i = 0; i < n; i++)
    {
        std::cin >> a[i];
    }
    int cnt = 0;
    int tmp = 0;
    for (int i = 0; i < n - 1; i++)
    {
        if (a[i] >= a[i + 1])
        {
            tmp = ((a[i] - a[i + 1]) / k) + 1;
            a[i + 1] = a[i + 1] + (tmp * k);
            cnt += tmp;
        }
    }
    std::cout << cnt;
    return 0;
}