#pragma once
#include <iostream>
#include <fstream>

struct Dates
{
    int year;
    int month;
    int day;
};

// Đây là hàm để lấy thông tin ngày tháng năm từ file input.txt ạ:
void getList (std::ifstream& fin, Dates dt[], int& n);

// Đây là hàm sắp xếp thời gian tăng dần ạ
void sortList (Dates dt[], int& n);

// Đây là hàm xuất ra file output.txt ạ:
void printList (std::ofstream& fout, Dates dt[], int& n);