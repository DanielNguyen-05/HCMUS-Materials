#include "23127165_HeaderFile_Ex01.hpp"
#include "23127165_SourceFile_Ex01.cpp"

int main()
{
    int n;
    Dates dt[100];

    std::ifstream fin;
    fin.open("input.txt");
    int i = 0;
    if (fin.is_open() == false)
    {
        std::cout << "File is not exist" << "\n";
        return 1;
    }
    getList (fin, dt, n);
    sortList (dt, n);
    fin.close();

    std::ofstream fout;
    fout.open("output.txt");
    if (fout.is_open() == false)
    {
        std::cout << "File does not exist" << "\n";
        return 1;
    }
    printList (fout, dt, n);
    fout.close();
    
    return 0;
}
