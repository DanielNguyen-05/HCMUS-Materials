#include "23127165_HeaderFile_Ex01.hpp"

void getList (std::ifstream& fin, Dates dt[], int& n)
{
    int i = 0;
    while (!fin.eof())
    {
        fin >> dt[i].year;
        fin >> dt[i].month;
        fin >> dt[i].day;
        ++i;
    }
    n = i - 1;
}

void sortList (Dates dt[], int& n)
{
    for (int i = 0; i < n - 1; i++)
    {
        for (int j = i + 1; j < n; j++)
        {
        	if (dt[i].year > dt[j].year) std::swap(dt[i], dt[j]);
    	}
    }
    for (int i = 0; i < n - 1; i++)
    {
        for (int j = i + 1; j < n; j++)
        {
        	if (dt[i].year == dt[j].year && dt[i].month > dt[j].month) std::swap(dt[i], dt[j]);
    	}
    }
    for (int i = 0; i < n - 1; i++)
    {
        for (int j = i + 1; j < n; j++)
        {
        	if (dt[i].year == dt[j].year && dt[i].month == dt[j].month && dt[i].day > dt[j].day) std::swap(dt[i], dt[j]);
    	}
    }

}

void printList (std::ofstream& fout, Dates dt[], int& n)
{
    for (int i = 0; i < n; i++)
    {
        fout << dt[i].year << " " << dt[i].month << " " << dt[i].day << "\n";
    }
}