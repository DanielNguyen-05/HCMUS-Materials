#include <iostream>

int main()
{
    int n, P1, P2, P3, T1, T2;
    std::cin >> n >> P1 >> P2 >> P3 >> T1 >> T2;
    n = n * 2;
    int a[205];
    int sum = 0;
    for (int i = 1; i <= n; i++)
    {
        std::cin >> a[i];
    }
    for (int i = 1; i < n; i++)
    {
        if (i % 2 != 0)
        {
            sum += (a[i + 1] - a[i]) * P1;
        }
        else
        {
            if (a[i + 1] - a[i] <= T1)
            {
                sum += (a[i + 1] - a[i]) * P1;
            }
            if (a[i + 1] - a[i] > T1 && a[i + 1] - a[i] <= T1 + T2)
            {
                sum += P1 * T1 + (a[i + 1] - a[i] - T1) * P2;
            }
            if (a[i + 1] - a[i] > T1 + T2)
            {
                sum += P1 * T1 + P2 * T2 + (a[i + 1] - a[i] - T1 - T2) * P3;
            }
        }
    }
    std::cout << sum;
    return 0;
}