#pragma once
#include <iostream>

using namespace std;

void Flash_Sort(int* arr, int n);
void Flash_Sort_Count(int* arr, int n, long long& count);