#pragma once
#include <iostream>

using namespace std;

void Selection_Sort(int* arr, int n);
void Selection_Sort_Count(int* arr, int n, long long& count);