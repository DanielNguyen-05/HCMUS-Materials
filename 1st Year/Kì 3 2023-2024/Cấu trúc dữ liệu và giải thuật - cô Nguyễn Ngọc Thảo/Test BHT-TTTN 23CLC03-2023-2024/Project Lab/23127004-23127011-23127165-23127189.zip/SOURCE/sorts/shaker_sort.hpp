#pragma once
#include <iostream>

using namespace std;

void Shaker_Sort(int* arr, int n);
void Shaker_Sort_Count(int* arr, int n, long long& count);