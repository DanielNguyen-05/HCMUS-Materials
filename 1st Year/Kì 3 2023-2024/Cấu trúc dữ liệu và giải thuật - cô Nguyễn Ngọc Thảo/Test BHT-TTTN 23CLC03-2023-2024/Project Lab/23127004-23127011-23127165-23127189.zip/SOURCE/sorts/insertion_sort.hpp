#pragma once
#include <iostream>

using namespace std;

void Insertion_Sort(int* arr, int n);
void Insertion_Sort_Count(int* arr, int n, long long& count);