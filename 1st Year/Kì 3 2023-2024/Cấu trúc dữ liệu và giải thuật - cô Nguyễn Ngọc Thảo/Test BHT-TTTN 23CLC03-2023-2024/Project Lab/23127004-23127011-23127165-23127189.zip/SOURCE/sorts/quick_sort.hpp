#pragma once
#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>  

using namespace std;

void Quick_Sort(int* arr, int n);
void Quick_Sort_Count(int* arr, int n, long long& count);