#pragma once
#include <iostream>

using namespace std;

void Counting_Sort(int* arr, int n);
void Counting_Sort_Count(int* arr, int n, long long& count);