#pragma once
#include <iostream>

using namespace std;

void Merge_Sort(int* arr, int n);
void Merge_Sort_Count(int* arr, int n, long long& count);