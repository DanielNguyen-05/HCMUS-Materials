#pragma once
#include <iostream>

using namespace std;

void Radix_Sort(int* arr, int n);
void Radix_Sort_Count(int* arr, int n, long long& count);