#pragma once
#include <iostream>
#include <fstream>
#include <cstring>
#include <cstdlib>
#include <ctime>
#include <string>
using namespace std;

int Gen_Data_File(int inputSize, string inputOrder, string fileName);