#pragma once
#include <string>
#include <iostream>
#include <fstream>
#include <iomanip>
#include "function_call.hpp"

using namespace std;

void Handle_Command_4(string algo1, string algo2, string givenInput);
void Handle_Command_5(string algo1, string algo2, int inputSize, string inputOrder);
