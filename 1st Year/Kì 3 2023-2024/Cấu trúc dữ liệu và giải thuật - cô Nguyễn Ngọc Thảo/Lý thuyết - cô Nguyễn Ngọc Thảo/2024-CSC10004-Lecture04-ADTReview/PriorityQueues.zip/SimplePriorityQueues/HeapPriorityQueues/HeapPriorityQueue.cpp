//  Created by Frank M. Carrano and Tim Henry.
//  Copyright (c) 2013 __Pearson Education__. All rights reserved.

/** This source code is a modified version of which provided in the Data Structures and Problem Solving 6th edition book **/
#include "HeapPriorityQueue.h"

HeapPriorityQueue::HeapPriorityQueue()
{
   heapPtr = new ArrayMaxHeap();
}  // end constructor

HeapPriorityQueue::~HeapPriorityQueue()
{
}  // end destructor

bool HeapPriorityQueue::isEmpty() const
{
   return heapPtr->isEmpty();
}  // end isEmpty

bool HeapPriorityQueue::enqueue(const int& newEntry)
{
   return heapPtr->add(newEntry);
}  // end add

bool HeapPriorityQueue::dequeue()
{
   return heapPtr->remove();
}  // end remove

int HeapPriorityQueue::peek() const throw(PrecondViolatedExcep)
{
   try
   {
      return heapPtr->peekTop();
   }
   catch (PrecondViolatedExcep e)
   {
      throw PrecondViolatedExcep("Attempted peek into an empty priority queue.");
   }  // end try/catch
}  // end peek