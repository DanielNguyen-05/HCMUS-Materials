//  Created by Frank M. Carrano and Tim Henry.
//  Copyright (c) 2013 __Pearson Education__. All rights reserved.

/** This source code is a modified version of which provided in the Data Structures and Problem Solving 6th edition book **/
#pragma once
#ifndef _HEAP_PRIORITY_QUEUE
#define _HEAP_PRIORITY_QUEUE
#include "ArrayMaxHeap.h"

class HeapPriorityQueue
{
private:
	ArrayMaxHeap* heapPtr;   // Pointer to heap of items in the PQ
public:
	HeapPriorityQueue();
	~HeapPriorityQueue();

	bool isEmpty() const;
	bool enqueue(const int& newEntry);
	bool dequeue();

	/** @pre The priority queue is not empty. */
	int peek() const throw(PrecondViolatedExcep);
}; // end HeapPriorityQueue
#endif 