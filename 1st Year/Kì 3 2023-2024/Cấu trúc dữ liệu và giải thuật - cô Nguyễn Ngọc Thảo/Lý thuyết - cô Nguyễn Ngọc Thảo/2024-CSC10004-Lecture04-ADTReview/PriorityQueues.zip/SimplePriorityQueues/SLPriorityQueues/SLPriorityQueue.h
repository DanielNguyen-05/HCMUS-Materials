//  Created by Frank M. Carrano and Tim Henry.
//  Copyright (c) 2013 __Pearson Education__. All rights reserved.

/** This source code is a modified version of which provided in the Data Structures and Problem Solving 6th edition book **/
#pragma once
#ifndef _SL_PRIORITY_QUEUE
#define _SL_PRIORITY_QUEUE
#include "LinkedSortedList.h"
class SLPriorityQueue
{
private:
	LinkedSortedList* slistPtr;	// Pointer to sorted list of items in the PQ

public:
	SLPriorityQueue();
	~SLPriorityQueue();

	bool isEmpty() const;
	bool enqueue(const int& newEntry);
	bool dequeue();

	/** @throw PrecondViolatedExcep if priority queue is empty. */
	int peek() const throw(PrecondViolatedExcep);
}; // end SLPriorityQueue
#endif 