//  Created by Frank M. Carrano and Tim Henry.
//  Copyright (c) 2013 __Pearson Education__. All rights reserved.

/** This source code is a modified version of which provided in the Data Structures and Problem Solving 6th edition book **/

#include <iostream>
#include <vector>
#include "SLPriorityQueue.h" // ADT Priority Queue operations
using namespace std;
int main()
{
	SLPriorityQueue* pqPtr = new SLPriorityQueue();
	cout << "Empty: " << pqPtr->isEmpty() << endl;

	bool success;
	// Insert 80 and peek the max element
	success = pqPtr->enqueue(80);
	if (!success)
		cout << "Failed to add to the priority queue." << endl;
	cout << "Peek: " << pqPtr->peek() << endl;

	// Insert 81 and peek the max element
	success = pqPtr->enqueue(81);
	if (!success)
		cout << "Failed to add to the priority queue." << endl;
	cout << "Peek: " << pqPtr->peek() << endl;

	// Insert 69 and peek the max element
	success = pqPtr->enqueue(69);
	if (!success)
		cout << "Failed to add to the priority queue." << endl;
	cout << "Peek: " << pqPtr->peek() << endl;

	// Remove max and peek the max element
	cout << "Remove: " << pqPtr->dequeue() << endl;
	cout << "Peek: " << pqPtr->peek() << endl;

	// Insert 88 and peek the max element
	success = pqPtr->enqueue(88);
	if (!success)
		cout << "Failed to add to the priority queue." << endl;
	cout << "Peek: " << pqPtr->peek() << endl;

	// Insert 65 and peek the max element
	success = pqPtr->enqueue(65);
	if (!success)
		cout << "Failed to add to the priority queue." << endl;
	cout << "Peek: " << pqPtr->peek() << endl;

	// Insert 77 and peek the max element
	success = pqPtr->enqueue(77);
	if (!success)
		cout << "Failed to add to the priority queue." << endl;
	cout << "Peek: " << pqPtr->peek() << endl;

	// Remove max and peek the max element
	cout << "Remove: " << pqPtr->dequeue() << endl;
	cout << "Peek: " << pqPtr->peek() << endl << endl;

	// Remove all items
	while (!pqPtr->isEmpty())
	{
		try
		{
			cout << "Peek: " << pqPtr->peek() << endl;
		}
		catch (PrecondViolatedExcep e)
		{
			cout << e.what() << endl;
		}  // end try/catch
		cout << "Remove: " << pqPtr->dequeue() << endl;
	}  // end for

	   // Check possible exceptions
	cout << "remove with an empty priority queue: " << endl;
	cout << "Empty: " << pqPtr->isEmpty() << endl;
	cout << "remove: " << pqPtr->dequeue() << endl; // nothing to remove!
	try
	{
		cout << "peek with an empty priority queue: " << endl;
		cout << "peek: " << pqPtr->peek() << endl; // nothing to see!
	}
	catch (PrecondViolatedExcep e)
	{
		cout << e.what();
	}  // end try/catch

	getchar();
	return 0;
}  // end main