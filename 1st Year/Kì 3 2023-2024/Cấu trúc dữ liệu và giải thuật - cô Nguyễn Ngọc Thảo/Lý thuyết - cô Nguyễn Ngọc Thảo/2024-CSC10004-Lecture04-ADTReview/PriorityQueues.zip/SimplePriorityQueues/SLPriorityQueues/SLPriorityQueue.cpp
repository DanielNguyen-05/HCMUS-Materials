//  Created by Frank M. Carrano and Tim Henry.
//  Copyright (c) 2013 __Pearson Education__. All rights reserved.

/** This source code is a modified version of which provided in the Data Structures and Problem Solving 6th edition book **/
#include "SLPriorityQueue.h" // Header file
SLPriorityQueue::SLPriorityQueue()
{
	slistPtr = new LinkedSortedList();
}  // end default constructor

SLPriorityQueue::~SLPriorityQueue()
{
}  // end destructor

bool SLPriorityQueue::isEmpty() const
{
	return slistPtr->isEmpty();
}  // end isEmpty


bool SLPriorityQueue::enqueue(const int& newEntry)
{
	slistPtr->insertSorted(newEntry);
	return true;
}  // end add

bool SLPriorityQueue::dequeue()
{
	// The highest priority item is at the beginning of the sorted list
	return slistPtr->remove(1);
}  // end remove

int SLPriorityQueue::peek() const throw(PrecondViolatedExcep)
{
	if (isEmpty())
		throw PrecondViolatedExcep("peekFront() called with empty queue.");

	// Priority queue is not empty; return highest priority item;
	// it is at the beginning of the sorted list
	return slistPtr->getEntry(1);
}  // end peek

