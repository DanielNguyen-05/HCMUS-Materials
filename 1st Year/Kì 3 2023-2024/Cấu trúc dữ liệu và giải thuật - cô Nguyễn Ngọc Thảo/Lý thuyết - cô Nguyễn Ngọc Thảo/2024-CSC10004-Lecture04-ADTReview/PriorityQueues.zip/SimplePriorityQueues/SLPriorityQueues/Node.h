//  Created by Frank M. Carrano and Tim Henry.
//  Copyright (c) 2013 __Pearson Education__. All rights reserved.

/** This source code is a modified version of which provided in the Data Structures and Problem Solving 6th edition book **/
#pragma once
#ifndef _NODE
#define _NODE
class Node
{
private:
	int   item; // A data item
	Node* next; // Pointer to next node
public:
	Node();
	Node(const int& anItem);
	Node(const int& anItem, Node* nextNodePtr);
	void setItem(const int& anItem);
	void setNext(Node* nextNodePtr);
	int getItem() const;
	Node* getNext() const;
}; // end Node
#endif