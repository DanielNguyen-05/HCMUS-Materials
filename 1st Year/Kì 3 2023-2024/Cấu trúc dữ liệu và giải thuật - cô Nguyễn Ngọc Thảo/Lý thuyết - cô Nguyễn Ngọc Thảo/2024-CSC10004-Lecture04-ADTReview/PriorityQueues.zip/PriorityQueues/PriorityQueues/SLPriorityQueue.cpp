//  Created by Frank M. Carrano and Tim Henry.
//  Copyright (c) 2013 __Pearson Education__. All rights reserved.
/** ADT priority queue: ADT sorted list implementation.
@file SLPriorityQueue.cpp */

/** This source code is a modified version of which provided in the Data Structures and Problem Solving 6th edition book **/

#include "SLPriorityQueue.h"  // Header file

template<class ItemType>
SLPriorityQueue<ItemType>::SLPriorityQueue()
{
	slistPtr = new LinkedSortedList<ItemType>();
}  // end default constructor

template<class ItemType>
SLPriorityQueue<ItemType>::~SLPriorityQueue()
{
}  // end destructor

template<class ItemType>
bool SLPriorityQueue<ItemType>::isEmpty() const
{
	return slistPtr->isEmpty();
}  // end isEmpty

template<class ItemType>
bool SLPriorityQueue<ItemType>::enqueue(const ItemType& newEntry)
{
	slistPtr->insertSorted(newEntry);
	return true;
}  // end add

template<class ItemType>
bool SLPriorityQueue<ItemType>::dequeue()
{
	// The highest priority item is at the beginning of the sorted list
	return slistPtr->remove(1);
}  // end remove

template<class ItemType>
ItemType SLPriorityQueue<ItemType>::peek() const throw(PrecondViolatedExcep)
{
	if (isEmpty())
		throw PrecondViolatedExcep("peekFront() called with empty queue.");

	// Priority queue is not empty; return highest priority item;
	// it is at the beginning of the sorted list
	return slistPtr->getEntry(1);
}  // end peek

