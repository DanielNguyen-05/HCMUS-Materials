#pragma once
#ifndef _FRUIT
#define _FRUIT

#include <string>
using namespace std;
class Fruit
{
private:
	string fruit_name;
	int degree_of_sourness;		
public:
	Fruit() { };
	Fruit(string name, int sour_degree)
	{
		fruit_name = name;
		degree_of_sourness = sour_degree;
	}
	string getFruitName()
	{
		return fruit_name;
	}
	int getSourDegree()
	{
		return degree_of_sourness;
	}
	friend bool operator >(Fruit const& lhs, Fruit const& rhs)
	{
		if (lhs.degree_of_sourness > rhs.degree_of_sourness)
			return true;
		else
		{
			if (lhs.degree_of_sourness == rhs.degree_of_sourness)
				return (lhs.fruit_name < rhs.fruit_name);
			return false;
		}
	}
	friend bool operator <(Fruit const& lhs, Fruit const& rhs)
	{
		if (lhs.degree_of_sourness < rhs.degree_of_sourness)
			return true;
		else
		{
			if (lhs.degree_of_sourness == rhs.degree_of_sourness)
				return (lhs.fruit_name > rhs.fruit_name);
			return false;
		}
	}
};
#endif