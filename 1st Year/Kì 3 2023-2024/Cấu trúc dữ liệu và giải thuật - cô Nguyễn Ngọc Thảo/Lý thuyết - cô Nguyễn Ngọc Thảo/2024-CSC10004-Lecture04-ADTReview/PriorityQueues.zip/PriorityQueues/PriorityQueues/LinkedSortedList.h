//  Created by Frank M. Carrano and Tim Henry.
//  Copyright (c) 2013 __Pearson Education__. All rights reserved.

/** This source code is a modified version of which provided in the Data Structures and Problem Solving 6th edition book **/


// Listing 12-2

/** ADT sorted list: Link-based implementation.
@file LinkedSortedList.h */

#ifndef _LINKED_SORTED_LIST
#define _LINKED_SORTED_LIST

#include "Node.cpp"
#include "PrecondViolatedExcep.h"
template<class ItemType>
class LinkedSortedList
{
private:
	Node<ItemType>* headPtr; // Pointer to first node in the chain
	int itemCount;           // Current count of list items

							 // Locates the node that is before the node that should or does
							 // contain the given entry.
							 // @param anEntry  The entry to find.
							 // @return  Either a pointer to the node before the node that contains
							 //    or should contain the given entry, or nullptr if no prior node exists.
	Node<ItemType>* getNodeBefore(const ItemType& anEntry) const;

	// Locates the node at a given position within the chain.
	Node<ItemType>* getNodeAt(int position) const;

	// Returns a pointer to a copy of the chain to which origChainPtr points.
	Node<ItemType>* copyChain(const Node<ItemType>* origChainPtr);

public:
	LinkedSortedList();
	LinkedSortedList(const LinkedSortedList<ItemType>& aList);
	virtual ~LinkedSortedList();

	void insertSorted(const ItemType& newEntry);
	bool removeSorted(const ItemType& anEntry);
	int getPosition(const ItemType& newEntry) const;

	// The following methods are the same as given in ListInterface:
	bool isEmpty() const;
	int getLength() const;
	bool remove(int position);
	void clear();
	ItemType getEntry(int position) const throw(PrecondViolatedExcep);
}; // end LinkedSortedList

//#include "LinkedSortedList.cpp"
#endif