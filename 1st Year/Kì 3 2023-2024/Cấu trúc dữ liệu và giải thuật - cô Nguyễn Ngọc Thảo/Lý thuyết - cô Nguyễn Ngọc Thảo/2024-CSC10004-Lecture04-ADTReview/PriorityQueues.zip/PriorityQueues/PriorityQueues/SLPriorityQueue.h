//  Created by Frank M. Carrano and Tim Henry.
//  Copyright (c) 2013 __Pearson Education__. All rights reserved.

/** This source code is a modified version of which provided in the Data Structures and Problem Solving 6th edition book **/

#pragma once
#ifndef _SL_PRIORITY_QUEUE
#define _SL_PRIORITY_QUEUE
#include "LinkedSortedList.cpp"

template<class ItemType>
class SLPriorityQueue
{
private:
	LinkedSortedList<ItemType>* slistPtr;   // Pointer to sorted list of
											// items in the priority queue

public:
	SLPriorityQueue();
	~SLPriorityQueue();

	bool isEmpty() const;
	bool enqueue(const ItemType& newEntry);
	bool dequeue();

	/** @throw PrecondViolatedExcep if priority queue is empty. */
	ItemType peek() const throw(PrecondViolatedExcep);
}; // end SLPriorityQueue

//#include "SLPriorityQueue.cpp"
#endif 