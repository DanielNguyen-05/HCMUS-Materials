//  Created by Frank M. Carrano and Tim Henry.
//  Copyright (c) 2013 __Pearson Education__. All rights reserved.

/** This source code is a modified version of which provided in the Data Structures and Problem Solving 6th edition book **/


/** Heap-based implementation of the ADT priority queue.
    Listing 17-4.
 @file HeapPriorityQueue.cpp */

#include "HeapPriorityQueue.h"

template<class ItemType>
HeapPriorityQueue<ItemType>::HeapPriorityQueue()
{
   heapPtr = new ArrayMaxHeap<ItemType>();
}  // end constructor

template<class ItemType>
HeapPriorityQueue<ItemType>::~HeapPriorityQueue()
{
}  // end destructor
template<class ItemType>

bool HeapPriorityQueue<ItemType>::isEmpty() const
{
   return heapPtr->isEmpty();
}  // end isEmpty

template<class ItemType>
bool HeapPriorityQueue<ItemType>::enqueue(const ItemType& newEntry)
{
   return heapPtr->add(newEntry);
}  // end add

template<class ItemType>
bool HeapPriorityQueue<ItemType>::dequeue()
{
   return heapPtr->remove();
}  // end remove

template<class ItemType>
ItemType HeapPriorityQueue<ItemType>::peek() const throw(PrecondViolatedExcep)
{
   try
   {
      return heapPtr->peekTop();
   }
   catch (PrecondViolatedExcep e)
   {
      throw PrecondViolatedExcep("Attempted peek into an empty priority queue.");
   }  // end try/catch
}  // end peek