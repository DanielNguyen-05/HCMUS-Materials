//  Created by Frank M. Carrano and Tim Henry.
//  Copyright (c) 2013 __Pearson Education__. All rights reserved.

/** This source code is a modified version of which provided in the Data Structures and Problem Solving 6th edition book **/

#include <iostream>
#include <string>
#include <vector>
#include "Fruit.h"
#include "HeapPriorityQueue.cpp" // ADT Priority Queue operations
using namespace std;
int main()
{
	//// This is the data to be inserted
	//vector<string> items = { "kiwi", "apple", "banana", "mango", "watermelon", "coconut" };

	//// Insert every element to the PQ
	//HeapPriorityQueue<string>* pqPtr = new HeapPriorityQueue<string>();
	//cout << "Empty: " << pqPtr->isEmpty() << endl;
	//for (int i = 0; i < items.size(); i++)
	//{
	//	cout << "Adding " << items[i] << endl;
	//	bool success = pqPtr->enqueue(items[i]);
	//	if (!success)
	//		cout << "Failed to add " << items[i] << " to the priority queue." << endl;
	//}  // end for

	//   // Iteratively get the most prioritized element from PQ
	//cout << "Empty?: " << pqPtr->isEmpty() << endl;
	//while (!pqPtr->isEmpty())
	//{
	//	try
	//	{
	//		cout << "Peek  heap PQ: " << pqPtr->peek() << endl;
	//	}
	//	catch (PrecondViolatedExcep e)
	//	{
	//		cout << e.what() << endl;
	//	}  // end try/catch
	//	cout << "Remove: " << pqPtr->dequeue() << endl;
	//}  // end for

	//   // Check possible exceptions
	//cout << "remove with an empty priority queue: " << endl;
	//cout << "Empty: " << pqPtr->isEmpty() << endl;
	//cout << "remove: " << pqPtr->dequeue() << endl; // nothing to remove!
	//try
	//{
	//	cout << "peek with an empty priority queue: " << endl;
	//	cout << "peek: " << pqPtr->peek() << endl; // nothing to see!
	//}
	//catch (PrecondViolatedExcep e)
	//{
	//	cout << e.what();
	//}  // end try/catch

	   // This is the data to be inserted
	vector<Fruit> items = { {"kiwi",4}, {"apple",3}, {"banana",3}, {"mango",5}, {"watermelon",1}, {"coconut",1} };

	// Insert every element to the PQ
	HeapPriorityQueue<Fruit>* pqPtr = new HeapPriorityQueue<Fruit>();
	for (int i = 0; i < items.size(); i++)
	{
		bool success = pqPtr->enqueue(items[i]);
		if (!success)
			cout << "Failed to add item " << i << " to the priority queue." << endl;
	}  // end for

	// Iteratively get the most prioritized element from PQ
	while (!pqPtr->isEmpty())
	{
		try
		{
			Fruit f = pqPtr->peek();
			cout << "peek heap PQ: " << f.getFruitName() << " " << f.getSourDegree() << endl;
		}
		catch (PrecondViolatedExcep e)
		{
			cout << e.what() << endl;
		}  // end try/catch

		cout << "Empty: " << pqPtr->isEmpty() << endl;
		cout << "Remove: " << pqPtr->dequeue() << endl;
	}  // end for

	cout << "remove with an empty priority queue: " << endl;
	cout << "Empty: " << pqPtr->isEmpty() << endl;
	cout << "remove: " << pqPtr->dequeue() << endl; // nothing to remove!

	getchar();
	return 0;
}  // end main