#!/bin/bash

# 1. Create output directories before running the program
# The -p option ensures no error if the folder already exists
echo "Creating output directories..."
mkdir -p data/output_images/output_1
mkdir -p data/output_images/output_2

# 2. Run the program 
echo "Running RGB to Gray..."
./bin/23127165 -rgb2gray data/input_images/input_1.jpg data/output_images/output_1/out_gray.jpg
./bin/23127165 -rgb2gray data/input_images/input_2.jpg data/output_images/output_2/out_gray.jpg

echo "Running Brightness +50..."
./bin/23127165 -brightness data/input_images/input_1.jpg data/output_images/output_1/out_bright_plus.jpg 50
./bin/23127165 -brightness data/input_images/input_2.jpg data/output_images/output_2/out_bright_plus.jpg 50

echo "Running Brightness -50..."
./bin/23127165 -brightness data/input_images/input_1.jpg data/output_images/output_1/out_bright_minus.jpg -50
./bin/23127165 -brightness data/input_images/input_2.jpg data/output_images/output_2/out_bright_minus.jpg -50

echo "Running Contrast 1.5..."
./bin/23127165 -contrast data/input_images/input_1.jpg data/output_images/output_1/out_contrast_high.jpg 1.5
./bin/23127165 -contrast data/input_images/input_2.jpg data/output_images/output_2/out_contrast_high.jpg 1.5

echo "Running Contrast 0.5..."
./bin/23127165 -contrast data/input_images/input_1.jpg data/output_images/output_1/out_contrast_low.jpg 0.5
./bin/23127165 -contrast data/input_images/input_2.jpg data/output_images/output_2/out_contrast_low.jpg 0.5

echo "Running Average Filter..."
./bin/23127165 -avg data/input_images/input_1.jpg data/output_images/output_1/out_avg.jpg 3
./bin/23127165 -avg data/input_images/input_2.jpg data/output_images/output_2/out_avg.jpg 3

echo "Running Median Filter..."
./bin/23127165 -med data/input_images/input_1.jpg data/output_images/output_1/out_med.jpg 3
./bin/23127165 -med data/input_images/input_2.jpg data/output_images/output_2/out_med.jpg 3

echo "Running Gaussian Filter..."
./bin/23127165 -gau data/input_images/input_1.jpg data/output_images/output_1/out_gauss.jpg 5
./bin/23127165 -gau data/input_images/input_2.jpg data/output_images/output_2/out_gauss.jpg 5

echo "Running Sobel..."
./bin/23127165 -sobel data/input_images/input_1.jpg data/output_images/output_1/out_sobel.jpg
./bin/23127165 -sobel data/input_images/input_2.jpg data/output_images/output_2/out_sobel.jpg

echo "Running Laplace..."
./bin/23127165 -laplace data/input_images/input_1.jpg data/output_images/output_1/out_laplace.jpg
./bin/23127165 -laplace data/input_images/input_2.jpg data/output_images/output_2/out_laplace.jpg

echo "All tasks completed!"