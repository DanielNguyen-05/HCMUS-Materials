#pragma once
#include <opencv2/opencv.hpp>
#include <vector>
#include <algorithm>
#include <iostream>
#include <cmath>
#include <string>

class ColorTransformer {
public:
    // 1. Load image from file
    int LoadImage(const std::string& filePath, cv::Mat& sourceImage);

    // 2. Show the result image and save it 
    int ShowAndSaveImage(const std::string& filePath, const cv::Mat& destinationImage, const std::string& windowTitle);

    // 3. Convert a color image to the gray image.
    int RGB2Grayscale(const cv::Mat& sourceImage, cv::Mat& destinationImage);

    // 4. Change the brightness of an image.
    int ChangeBrightness(const cv::Mat& sourceImage, cv::Mat& destinationImage, int b);

    // 5. Change the contrast of an image.
    int ChangeContrast(const cv::Mat& sourceImage, cv::Mat& destinationImage, float c);

    // 6. Filter an image using average filter.
    int AvgFilter(const cv::Mat& sourceImage, cv::Mat& destinationImage, int k);

    // 7. Filter an image using median filter.
    int MedianFilter(const cv::Mat& sourceImage, cv::Mat& destinationImage, int k);

    // 8. Filter an image using gaussian filter.
    int GaussianFilter(const cv::Mat& sourceImage, cv::Mat& destinationImage, int k);

    // 9. Detect edge of an image using Sobel of kernel size 3 × 3 (fixed-size kernel so we dont need k).
    int Sobel(const cv::Mat& sourceImage, cv::Mat& destinationImage);

    // 10. Detect edge of an image using Laplace of kernel size 3 × 3 (fixed-size kernel so we dont need k).
    int Laplace(const cv::Mat& sourceImage, cv::Mat& destinationImage);

private:
    // Support function to keep the value in the range [0, 255]            
    uchar Clamp(int value) {
        return (uchar)(value > 255 ? 255 : (value < 0 ? 0 : value));
    }
};