#include "ColorTransformer.hpp"

#define PI 3.14159265358979323846

int ColorTransformer::LoadImage(const std::string& filePath, cv::Mat& sourceImage) {
    sourceImage = cv::imread(filePath, cv::IMREAD_COLOR);
    if (sourceImage.empty()) return 0; 
    return 1;
}

int ColorTransformer::ShowAndSaveImage(const std::string& filePath, const cv::Mat& destinationImage, const std::string& windowTitle) {
    if (destinationImage.empty()) return 0;
    
    // 1. Show image
    cv::imshow(windowTitle, destinationImage);
    
    // 2. Save image
    try {
        bool result = cv::imwrite(filePath, destinationImage);
        return result ? 1 : 0;
    } catch (...) {
        return 0;
    }
}

int ColorTransformer::RGB2Grayscale(const cv::Mat& sourceImage, cv::Mat& destinationImage) {
    if (sourceImage.empty()) return 0;

    int height = sourceImage.rows;
    int width = sourceImage.cols;
    destinationImage = cv::Mat(height, width, CV_8UC1);

    int srcWidthStep = sourceImage.step[0];
    int dstWidthStep = destinationImage.step[0];
    int nSrcChannels = sourceImage.channels(); 

    uchar* pSrcData = sourceImage.data;
    uchar* pDstData = destinationImage.data;

    for (int y = 0; y < height; y++, pSrcData += srcWidthStep, pDstData += dstWidthStep) {
        uchar* pSrcRow = pSrcData;
        uchar* pDstRow = pDstData;
        for (int x = 0; x < width; x++, pSrcRow += nSrcChannels, pDstRow++) {
            // Formula in teacher Viet's slide: 0.114*B + 0.587*G + 0.299*R
            uchar B = pSrcRow[0];
            uchar G = pSrcRow[1];
            uchar R = pSrcRow[2];
            float gray = 0.114f * B + 0.587f * G + 0.299f * R;
            pDstRow[0] = (uchar)gray;
        }
    }
    return 1;
}

int ColorTransformer::ChangeBrightness(const cv::Mat& sourceImage, cv::Mat& destinationImage, int b) {
    if (sourceImage.empty()) return 0;
    destinationImage = sourceImage.clone();

    int height = sourceImage.rows;
    int width = sourceImage.cols;
    int nChannels = sourceImage.channels();
    int widthStep = sourceImage.step[0];

    // Applying the lookup table technique
    // Instead of adding b for millions of pixels, we only calculate 256 values ​​beforehand.
    uchar lookup[256];
    for (int i = 0; i < 256; i++) {
        int val = i + b;
        lookup[i] = Clamp(val);
    }

    uchar* pData = destinationImage.data;
    for (int y = 0; y < height; y++, pData += widthStep) {
        uchar* pRow = pData;
        for (int x = 0; x < width * nChannels; x++) {
            // Using table to get new value
            pRow[x] = lookup[pRow[x]];
        }
    }
    return 1;
}

int ColorTransformer::ChangeContrast(const cv::Mat& sourceImage, cv::Mat& destinationImage, float c) {
    if (sourceImage.empty()) return 0;
    destinationImage = sourceImage.clone();

    int height = sourceImage.rows;
    int width = sourceImage.cols;
    int nChannels = sourceImage.channels();
    int widthStep = sourceImage.step[0];

    // Applying the lookup table technique as above
    uchar lookup[256];
    for (int i = 0; i < 256; i++) {
        int val = (int)(i * c);
        lookup[i] = Clamp(val);
    }

    uchar* pData = destinationImage.data;
    for (int y = 0; y < height; y++, pData += widthStep) {
        uchar* pRow = pData;
        for (int x = 0; x < width * nChannels; x++) {
            pRow[x] = lookup[pRow[x]];
        }
    }
    return 1;
}

// For filter functions with variable kernel size k (Avg, Median, Gaussian),
// creating a static offset array is not possible. We use widthStep to jump between rows.
int ColorTransformer::AvgFilter(const cv::Mat& sourceImage, cv::Mat& destinationImage, int k) {
    if (sourceImage.empty() || k % 2 == 0) return 0;
    
    destinationImage = sourceImage.clone();
    int height = sourceImage.rows;
    int width = sourceImage.cols;
    int nChannels = sourceImage.channels();
    int widthStep = sourceImage.step[0]; // Byte distance between 2 rows
    int offset = k / 2;

    uchar* pSrcData = sourceImage.data;
    uchar* pDstData = destinationImage.data;

    // Iterate through pixels (excluding borders)
    for (int y = offset; y < height - offset; y++) {
        uchar* pDstRow = pDstData + y * widthStep;
        
        for (int x = offset; x < width - offset; x++) {
            for (int c = 0; c < nChannels; c++) {
                int sum = 0;
                // Access neighbors by directly adding widthStep to the pointer
                // pCenter is a pointer to the center pixel (x, y)
                uchar* pCenter = pSrcData + y * widthStep + x * nChannels + c;

                for (int ky = -offset; ky <= offset; ky++) {
                    for (int kx = -offset; kx <= offset; kx++) {
                        int neighborOffset = ky * widthStep + kx * nChannels;
                        sum += pCenter[neighborOffset];
                    }
                }
                pDstRow[x * nChannels + c] = (uchar)(sum / (k * k));
            }
        }
    }
    return 1;
}

int ColorTransformer::MedianFilter(const cv::Mat& sourceImage, cv::Mat& destinationImage, int k) {
    if (sourceImage.empty() || k % 2 == 0) return 0;
    
    destinationImage = sourceImage.clone();
    int height = sourceImage.rows;
    int width = sourceImage.cols;
    int nChannels = sourceImage.channels();
    int widthStep = sourceImage.step[0];
    int offset = k / 2;
    std::vector<uchar> window;
    window.reserve(k * k);

    uchar* pSrcData = sourceImage.data;
    uchar* pDstData = destinationImage.data;

    for (int y = offset; y < height - offset; y++) {
        uchar* pDstRow = pDstData + y * widthStep;
        for (int x = offset; x < width - offset; x++) {
            for (int c = 0; c < nChannels; c++) {
                window.clear();
                uchar* pCenter = pSrcData + y * widthStep + x * nChannels + c;
                
                for (int ky = -offset; ky <= offset; ky++) {
                    for (int kx = -offset; kx <= offset; kx++) {
                         // Access neighbor
                        int neighborOffset = ky * widthStep + kx * nChannels;
                        window.push_back(pCenter[neighborOffset]);
                    }
                }
                std::sort(window.begin(), window.end());
                pDstRow[x * nChannels + c] = window[window.size() / 2];
            }
        }
    }
    return 1;
}

int ColorTransformer::GaussianFilter(const cv::Mat& sourceImage, cv::Mat& destinationImage, int k) {
    if (sourceImage.empty() || k % 2 == 0) return 0;
    
    std::vector<float> kernel(k * k);
    float sigma = 0.3f * ((k - 1) * 0.5f - 1) + 0.8f;
    float sumKernel = 0;
    int offset = k / 2;

    for (int y = -offset; y <= offset; y++) {
        for (int x = -offset; x <= offset; x++) {
            float val = exp(-(x * x + y * y) / (2 * sigma * sigma)) / (2 * PI * sigma * sigma);
            kernel[(y + offset) * k + (x + offset)] = val;
            sumKernel += val;
        }
    }
    for (int i = 0; i < k * k; i++) kernel[i] /= sumKernel;

    destinationImage = sourceImage.clone();
    int height = sourceImage.rows;
    int width = sourceImage.cols;
    int nChannels = sourceImage.channels();
    int widthStep = sourceImage.step[0];

    uchar* pSrcData = sourceImage.data;
    uchar* pDstData = destinationImage.data;

    for (int y = offset; y < height - offset; y++) {
        uchar* pDstRow = pDstData + y * widthStep;
        for (int x = offset; x < width - offset; x++) {
            for (int c = 0; c < nChannels; c++) {
                float sum = 0;
                uchar* pCenter = pSrcData + y * widthStep + x * nChannels + c;

                for (int ky = -offset; ky <= offset; ky++) {
                    for (int kx = -offset; kx <= offset; kx++) {
                        int neighborOffset = ky * widthStep + kx * nChannels;
                        float pixelVal = (float)pCenter[neighborOffset];
                        sum += pixelVal * kernel[(ky + offset) * k + (kx + offset)];
                    }
                }
                pDstRow[x * nChannels + c] = Clamp((int)sum);
            }
        }
    }
    return 1;
}

// Sobel and Laplace have a fixed 3x3 kernel, so we can apply the neighbor access technique,
// storing offsets in an array as shown in the slides
int ColorTransformer::Sobel(const cv::Mat& sourceImage, cv::Mat& destinationImage) {
    if (sourceImage.empty()) return 0;
    
    cv::Mat grayImg;
    if (sourceImage.channels() == 3) RGB2Grayscale(sourceImage, grayImg);
    else grayImg = sourceImage.clone();

    destinationImage = cv::Mat(grayImg.size(), CV_8UC1);
    destinationImage.setTo(cv::Scalar(0)); 

    int height = grayImg.rows;
    int width = grayImg.cols;
    int widthStep = grayImg.step[0]; 
    int threshold = 128; 

    int offsets[9] = {
        -widthStep - 1, -widthStep, -widthStep + 1,
        -1,              0,          1,
        widthStep - 1,  widthStep,  widthStep + 1
    };

    // Sobel kernel is mapped according to the above offsets (row-major)
    // Row -1: -widthStep-1, -widthStep, -widthStep+1
    // Row  0: -1, 0, 1
    // Row +1: widthStep-1, widthStep, widthStep+1
    int kx_val[9] = {-1, 0, 1, -2, 0, 2, -1, 0, 1}; 
    int ky_val[9] = {-1, -2, -1, 0, 0, 0, 1, 2, 1};

    uchar* pData = grayImg.data;
    uchar* pDstData = destinationImage.data;

    for (int y = 1; y < height - 1; y++) {
        for (int x = 1; x < width - 1; x++) {
            // p is a pointer to the current pixel (x, y)
            uchar* p = pData + y * widthStep + x;
            
            int gx = 0, gy = 0;
            for (int k = 0; k < 9; k++) {
                int val = p[offsets[k]];
                gx += val * kx_val[k];
                gy += val * ky_val[k];
            }
            
            int sum = abs(gx) + abs(gy);
            uchar* pDst = pDstData + y * widthStep + x;
            *pDst = (sum > threshold) ? 255 : 0;
        }
    }
    return 1;
}

int ColorTransformer::Laplace(const cv::Mat& sourceImage, cv::Mat& destinationImage) {
    if (sourceImage.empty()) return 0;
    
    cv::Mat grayImg;
    if (sourceImage.channels() == 3) RGB2Grayscale(sourceImage, grayImg);
    else grayImg = sourceImage.clone();

    destinationImage = cv::Mat(grayImg.size(), CV_8UC1);
    destinationImage.setTo(cv::Scalar(0)); 

    int height = grayImg.rows;
    int width = grayImg.cols;
    int widthStep = grayImg.step[0];
    int threshold = 80; 

    int offsets[9] = {
        -widthStep - 1, -widthStep, -widthStep + 1,
        -1,              0,          1,
        widthStep - 1,  widthStep,  widthStep + 1
    };

    // Laplace kernel according to the offsets order
    // 0  1  0
    // 1 -4  1
    // 0  1  0
    int kernel_val[9] = {0, 1, 0, 1, -4, 1, 0, 1, 0};

    uchar* pData = grayImg.data;
    uchar* pDstData = destinationImage.data;

    for (int y = 1; y < height - 1; y++) {
        for (int x = 1; x < width - 1; x++) {
            uchar* p = pData + y * widthStep + x;
            
            int sum = 0;
            for (int k = 0; k < 9; k++) {
                sum += p[offsets[k]] * kernel_val[k]; 
            }
            
            uchar* pDst = pDstData + y * widthStep + x;
            *pDst = (abs(sum) > threshold) ? 255 : 0;
        }
    }
    return 1;
}