#include "ColorTransformer.hpp"
#include <iostream>
#include <string>

using namespace std;
using namespace cv;

int main(int argc, char* argv[]) {
    if (argc < 4) {
        cout << "Error: Not enough arguments." << endl;
        return 1;
    }

    string command = argv[1];
    string inputPath = argv[2];
    string outputPath = argv[3];

    ColorTransformer transformer;
    Mat inputImage;
    Mat outputImage;

    if (transformer.LoadImage(inputPath, inputImage) == 0) {
        cerr << "Error: Could not load image from " << inputPath << endl;
        return 1;
    }

    int result = 0;
    string windowTitle = "Result Image";

    if (command == "-rgb2gray") {
        windowTitle = "Gray Image";
        result = transformer.RGB2Grayscale(inputImage, outputImage);
    } 
    else if (command == "-brightness") {
        if (argc < 5) { cout << "Missing brightness value" << endl; return 1; }
        int b = atoi(argv[4]);
        windowTitle = "Brightness Image (b=" + string(argv[4]) + ")";
        result = transformer.ChangeBrightness(inputImage, outputImage, b);
    } 
    else if (command == "-contrast") {
        if (argc < 5) { cout << "Missing contrast factor" << endl; return 1; }
        float c = (float)atof(argv[4]);
        windowTitle = "Contrast Image (c=" + string(argv[4]) + ")";
        result = transformer.ChangeContrast(inputImage, outputImage, c);
    }
    else if (command == "-avg") {
        if (argc < 5) { cout << "Missing kernel size" << endl; return 1; }
        int k = atoi(argv[4]);
        windowTitle = "Average Filter (k=" + string(argv[4]) + ")";
        result = transformer.AvgFilter(inputImage, outputImage, k);
    }
    else if (command == "-med") {
        if (argc < 5) { cout << "Missing kernel size" << endl; return 1; }
        int k = atoi(argv[4]);
        windowTitle = "Median Filter (k=" + string(argv[4]) + ")";
        result = transformer.MedianFilter(inputImage, outputImage, k);
    }
    else if (command == "-gau") {
        if (argc < 5) { cout << "Missing kernel size" << endl; return 1; }
        int k = atoi(argv[4]);
        windowTitle = "Gaussian Filter (k=" + string(argv[4]) + ")";
        result = transformer.GaussianFilter(inputImage, outputImage, k);
    }
    else if (command == "-sobel") {
        windowTitle = "Sobel Edge Detection";
        result = transformer.Sobel(inputImage, outputImage);
    }
    else if (command == "-laplace") {
        windowTitle = "Laplace Edge Detection";
        result = transformer.Laplace(inputImage, outputImage);
    }
    else {
        cout << "Unknown command: " << command << endl;
        return 1;
    }

    if (result == 1) {
        imshow("Original Input", inputImage);

        if (transformer.ShowAndSaveImage(outputPath, outputImage, windowTitle) == 1) {
            cout << "Success! Image shown and saved to " << outputPath << endl;
        } else {
            cerr << "Error: Could not save image." << endl;
        }

        cout << ">>> Press any key to exit..." << endl;
        waitKey(0); 
        destroyAllWindows();
    } else {
        cerr << "Error: Processing failed." << endl;
        return 1;
    }

    return 0;
}