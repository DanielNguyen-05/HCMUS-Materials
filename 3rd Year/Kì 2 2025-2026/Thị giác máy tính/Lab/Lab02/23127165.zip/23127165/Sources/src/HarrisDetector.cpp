#include "../include/HarrisDetector.hpp"

int HarrisDetector::LoadImage(const std::string& filePath, cv::Mat& sourceImage) {
    // Load image in color mode
    sourceImage = cv::imread(filePath, cv::IMREAD_COLOR);
    // Return 0 if image is empty/not found
    if (sourceImage.empty()) return 0; 
    // Return 1 on successful load
    return 1;
}

int HarrisDetector::ShowAndSaveImage(const std::string& filePath, const cv::Mat& destinationImage, const std::string& windowTitle) {
    // Return 0 if there is no image to show
    if (destinationImage.empty()) return 0;
    // Display the image in a window
    cv::imshow(windowTitle, destinationImage);
    try {
        // Attempt to save the image to the specified path
        bool result = cv::imwrite(filePath, destinationImage);
        // Return 1 if saved successfully, else 0
        return result ? 1 : 0;
    } catch (...) {
        // Catch any exceptions and return 0
        return 0;
    }
}

int HarrisDetector::RGB2Grayscale(const cv::Mat& sourceImage, cv::Mat& destinationImage) {
    // Check if source is empty
    if (sourceImage.empty()) return 0;
    // Get image dimensions
    int height = sourceImage.rows;
    int width = sourceImage.cols;
    // Initialize destination image as 1-channel 8-bit
    destinationImage = cv::Mat(height, width, CV_8UC1);
    // Get strides (step) for pointer arithmetic
    int srcStep = sourceImage.step[0];
    int dstStep = destinationImage.step[0];
    int nChannels = sourceImage.channels(); 
    // Get raw data pointers
    uchar* pSrcData = sourceImage.data;
    uchar* pDstData = destinationImage.data;
    // Loop through each row
    for (int y = 0; y < height; y++) {
        // Loop through each column
        for (int x = 0; x < width; x++) {
            // Get Blue channel using pointer arithmetic
            uchar B = *(pSrcData + y * srcStep + x * nChannels + 0);
            // Get Green channel using pointer arithmetic
            uchar G = *(pSrcData + y * srcStep + x * nChannels + 1);
            // Get Red channel using pointer arithmetic
            uchar R = *(pSrcData + y * srcStep + x * nChannels + 2);
            // Calculate grayscale value
            float gray = 0.114f * B + 0.587f * G + 0.299f * R;
            // Assign calculated value to destination pointer
            *(pDstData + y * dstStep + x) = (uchar)gray;
        }
    }
    // Return success
    return 1;
}

int HarrisDetector::DetectStandard(const cv::Mat& sourceImage, cv::Mat& destinationImage) {
    // Check if input is valid
    if (sourceImage.empty()) return 0;
    // Clone original image to draw circles later
    destinationImage = sourceImage.clone();
    // Matrix to hold grayscale image
    cv::Mat grayImg;
    // Convert to grayscale
    RGB2Grayscale(sourceImage, grayImg);
    // Get image dimensions
    int width = grayImg.cols;
    int height = grayImg.rows;
    int step = grayImg.step;
    // Get raw pointer to grayscale data
    uchar* data = grayImg.data;
    // Allocate memory for gradients and response
    float* Ix = new float[width * height]();
    float* Iy = new float[width * height]();
    float* R = new float[width * height]();

    // STEP 1: Compute Gradients (Sobel)
    // Loop rows, ignoring 1px border
    for (int y = 1; y < height - 1; ++y) {
        // Loop columns, ignoring 1px border
        for (int x = 1; x < width - 1; ++x) {
            // Calculate Sobel X manually using pointer arithmetic
            float gx = -1 * *(data + (y - 1) * step + (x - 1)) + 1 * *(data + (y - 1) * step + (x + 1))
                       -2 * *(data + y * step + (x - 1))       + 2 * *(data + y * step + (x + 1))
                       -1 * *(data + (y + 1) * step + (x - 1)) + 1 * *(data + (y + 1) * step + (x + 1));
            // Calculate Sobel Y manually using pointer arithmetic
            float gy = -1 * *(data + (y - 1) * step + (x - 1)) - 2 * *(data + (y - 1) * step + x) - 1 * *(data + (y - 1) * step + (x + 1))
                       +1 * *(data + (y + 1) * step + (x - 1)) + 2 * *(data + (y + 1) * step + x) + 1 * *(data + (y + 1) * step + (x + 1));
            // Store gradient X
            *(Ix + y * width + x) = gx;
            // Store gradient Y
            *(Iy + y * width + x) = gy;
        }
    }

    // STEP 2: Structure Tensor and Harris Response
    // Empirical constant for Harris equation
    float k = 0.04f;
    // Threshold to filter weak corners
    float threshold = 5000000.0f; 
    // Loop rows, ignoring 2px border (due to 3x3 window)
    for (int y = 2; y < height - 2; ++y) {
        // Loop columns
        for (int x = 2; x < width - 2; ++x) {
            // Initialize tensor sums
            float Sxx = 0, Syy = 0, Sxy = 0;
            // 3x3 Window loop (Row)
            for (int dy = -1; dy <= 1; ++dy) {
                // 3x3 Window loop (Col)
                for (int dx = -1; dx <= 1; ++dx) {
                    // Get Ix at window position
                    float ix = *(Ix + (y + dy) * width + (x + dx));
                    // Get Iy at window position
                    float iy = *(Iy + (y + dy) * width + (x + dx));
                    // Accumulate squares
                    Sxx += ix * ix;
                    Syy += iy * iy;
                    Sxy += ix * iy;
                }
            }
            // Calculate Determinant
            float det = (Sxx * Syy) - (Sxy * Sxy);
            // Calculate Trace
            float trace = Sxx + Syy;
            // Calculate Harris Response R
            float response = det - k * (trace * trace);
            // Store R
            *(R + y * width + x) = response;
        }
    }

    // STEP 3: Non-Maximum Suppression (NMS)
    // Loop rows
    for (int y = 2; y < height - 2; ++y) {
        // Loop columns
        for (int x = 2; x < width - 2; ++x) {
            // Get current R value
            float current_R = *(R + y * width + x);
            // Check if it passes threshold
            if (current_R > threshold) {
                // Flag for local maximum
                bool isMax = true;
                // Check 8 neighbors
                for (int dy = -1; dy <= 1; ++dy) {
                    for (int dx = -1; dx <= 1; ++dx) {
                        // Compare with neighbor
                        if (*(R + (y + dy) * width + (x + dx)) > current_R) {
                            // If neighbor is larger, not a local max
                            isMax = false;
                        }
                    }
                }
                // If it is a local max
                if (isMax) {
                    // Draw a red circle at the corner location
                    cv::circle(destinationImage, cv::Point(x, y), 3, cv::Scalar(0, 0, 255), 1);
                }
            }
        }
    }
    // Free allocated memory
    delete[] Ix; delete[] Iy; delete[] R;
    // Return success
    return 1;
}

int HarrisDetector::DetectOptimized(const cv::Mat& sourceImage, cv::Mat& destinationImage) {
    if (sourceImage.empty()) return 0;
    destinationImage = sourceImage.clone();
    cv::Mat grayImg;
    RGB2Grayscale(sourceImage, grayImg);
    
    int width = grayImg.cols;
    int height = grayImg.rows;
    int step = grayImg.step;
    uchar* data = grayImg.data;
    
    // Allocate memory
    float* Ix = new float[width * height]();
    float* Iy = new float[width * height]();
    float* Sxx = new float[width * height]();
    float* Syy = new float[width * height]();
    float* Sxy = new float[width * height]();
    float* R = new float[width * height]();

    // OPTIMIZATION 1: Pointer Incrementing (Avoid y*step+x multiplication in inner loop)
    // Loop rows
    for (int y = 1; y < height - 1; ++y) {
        // Setup row pointers
        uchar* pPrev = data + (y - 1) * step + 1;
        uchar* pCurr = data + y * step + 1;
        uchar* pNext = data + (y + 1) * step + 1;
        // Setup output pointers
        float* pIx = Ix + y * width + 1;
        float* pIy = Iy + y * width + 1;
        // Loop columns
        for (int x = 1; x < width - 1; ++x) {
            // Fast Sobel X
            *pIx = -1 * *(pPrev - 1) + 1 * *(pPrev + 1) - 2 * *(pCurr - 1) + 2 * *(pCurr + 1) - 1 * *(pNext - 1) + 1 * *(pNext + 1);
            // Fast Sobel Y
            *pIy = -1 * *(pPrev - 1) - 2 * *(pPrev) - 1 * *(pPrev + 1) + 1 * *(pNext - 1) + 2 * *(pNext) + 1 * *(pNext + 1);
            // Pre-calculate tensor products (Sxx, Syy, Sxy temporary storage)
            *(Sxx + y * width + x) = (*pIx) * (*pIx);
            *(Syy + y * width + x) = (*pIy) * (*pIy);
            *(Sxy + y * width + x) = (*pIx) * (*pIy);
            // Increment pointers directly
            pPrev++; pCurr++; pNext++; pIx++; pIy++;
        }
    }

    // OPTIMIZATION 2: Separable Box Filter (O(2N) instead of O(N^2))
    // Allocate intermediate buffers for 1D horizontal pass
    float* tempSxx = new float[width * height]();
    float* tempSyy = new float[width * height]();
    float* tempSxy = new float[width * height]();

    // 1D Horizontal Pass
    for (int y = 1; y < height - 1; ++y) {
        for (int x = 2; x < width - 2; ++x) {
            // Sum 3 horizontal pixels
            tempSxx[y * width + x] = Sxx[y * width + x - 1] + Sxx[y * width + x] + Sxx[y * width + x + 1];
            tempSyy[y * width + x] = Syy[y * width + x - 1] + Syy[y * width + x] + Syy[y * width + x + 1];
            tempSxy[y * width + x] = Sxy[y * width + x - 1] + Sxy[y * width + x] + Sxy[y * width + x + 1];
        }
    }
    // 1D Vertical Pass & Calculate Response R
    float k = 0.04f;
    for (int y = 2; y < height - 2; ++y) {
        for (int x = 2; x < width - 2; ++x) {
            // Sum 3 vertical pixels (completes the 3x3 2D blur)
            float finalSxx = tempSxx[(y - 1) * width + x] + tempSxx[y * width + x] + tempSxx[(y + 1) * width + x];
            float finalSyy = tempSyy[(y - 1) * width + x] + tempSyy[y * width + x] + tempSyy[(y + 1) * width + x];
            float finalSxy = tempSxy[(y - 1) * width + x] + tempSxy[y * width + x] + tempSxy[(y + 1) * width + x];
            
            // Calculate Response
            float det = (finalSxx * finalSyy) - (finalSxy * finalSxy);
            float trace = finalSxx + finalSyy;
            *(R + y * width + x) = det - k * (trace * trace);
        }
    }

    // NMS and Drawing (Same as Standard, but using pointer incrementing for speed)
    float threshold = 5000000.0f;
    for (int y = 2; y < height - 2; ++y) {
        float* pR = R + y * width + 2;
        for (int x = 2; x < width - 2; ++x) {
            float current_R = *pR;
            if (current_R > threshold) {
                bool isMax = true;
                // Fast neighbor check
                for (int dy = -1; dy <= 1 && isMax; ++dy) {
                    for (int dx = -1; dx <= 1; ++dx) {
                        if (*(R + (y + dy) * width + (x + dx)) > current_R) {
                            isMax = false;
                            break;
                        }
                    }
                }
                if (isMax) {
                    cv::circle(destinationImage, cv::Point(x, y), 3, cv::Scalar(0, 0, 255), 1);
                }
            }
            pR++;
        }
    }

    // Free memory
    delete[] Ix; delete[] Iy; delete[] R;
    delete[] Sxx; delete[] Syy; delete[] Sxy;
    delete[] tempSxx; delete[] tempSyy; delete[] tempSxy;
    
    return 1;
}