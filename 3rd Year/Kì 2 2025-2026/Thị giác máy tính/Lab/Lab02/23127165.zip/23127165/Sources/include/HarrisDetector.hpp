#pragma once
#include <opencv2/opencv.hpp>
#include <iostream>
#include <vector>
#include <cmath>
#include <string>

class HarrisDetector {
public:
    /*
     * Purpose: Load an image from a file path.
     * Inputs: 
     * - filePath: String containing the path to the image.
     * - sourceImage: cv::Mat reference to store the loaded image.
     * Return: Integer (1 for success, 0 for failure).
     */
    int LoadImage(const std::string& filePath, cv::Mat& sourceImage);

    /*
     * Purpose: Show the image in a window and save it to a file.
     * Inputs:
     * - filePath: String containing the path to save the image.
     * - destinationImage: cv::Mat containing the image to be saved.
     * - windowTitle: String for the display window title.
     * Return: Integer (1 for success, 0 for failure).
     */
    int ShowAndSaveImage(const std::string& filePath, const cv::Mat& destinationImage, const std::string& windowTitle);

    /*
     * Purpose: Detect Harris corners using standard, unoptimized mathematical formulas.
     * Inputs:
     * - sourceImage: The input BGR cv::Mat image.
     * - destinationImage: The output BGR cv::Mat image with drawn circles on corners.
     * Return: Integer (1 for success, 0 for failure).
     */
    int DetectStandard(const cv::Mat& sourceImage, cv::Mat& destinationImage);

    /*
     * Purpose: Detect Harris corners using optimized methods (pointer increments and separable filters).
     * Inputs:
     * - sourceImage: The input BGR cv::Mat image.
     * - destinationImage: The output BGR cv::Mat image with drawn circles on corners.
     * Return: Integer (1 for success, 0 for failure).
     */
    int DetectOptimized(const cv::Mat& sourceImage, cv::Mat& destinationImage);

private:
    /*
     * Purpose: Helper function to convert RGB/BGR image to Grayscale using raw pointers.
     * Inputs:
     * - sourceImage: The input color image.
     * - destinationImage: The output grayscale image.
     * Return: Integer (1 for success, 0 for failure).
     */
    int RGB2Grayscale(const cv::Mat& sourceImage, cv::Mat& destinationImage);
};