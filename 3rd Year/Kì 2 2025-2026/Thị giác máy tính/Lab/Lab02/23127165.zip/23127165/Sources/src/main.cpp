#include "../include/HarrisDetector.hpp"
#include <iostream>
#include <string>

using namespace std;
using namespace cv;

int main(int argc, char* argv[]) {
    // Check if the command line arguments are sufficient
    if (argc < 4) {
        cout << "Usage 1: <Executable> -harris <InputFilePath> <OutputFilePath>" << endl;
        cout << "Usage 2: <Executable> -optHarris <InputFilePath> <OutputFilePath>" << endl;
        return 1;
    }

    // Parse arguments
    string command = argv[1];
    string inputPath = argv[2];
    string outputPath = argv[3];

    // Initialize detector and image matrices
    HarrisDetector detector;
    Mat inputImage;
    Mat outputImage;

    // Attempt to load the image
    if (detector.LoadImage(inputPath, inputImage) == 0) {
        cerr << "Error: Could not load image from " << inputPath << endl;
        return 1;
    }

    int result = 0;
    string windowTitle = "Result Image";

    // Process based on command
    if (command == "-harris") {
        windowTitle = "Standard Harris Detection";
        cout << "Running Standard Harris Keypoint Detection..." << endl;
        result = detector.DetectStandard(inputImage, outputImage);
    } 
    else if (command == "-optHarris") {
        windowTitle = "Optimized Harris Detection";
        cout << "Running Optimized Harris Keypoint Detection..." << endl;
        result = detector.DetectOptimized(inputImage, outputImage);
    } 
    else {
        // Unknown command error
        cout << "Error: Unknown command: " << command << endl;
        return 1;
    }

    // If detection was successful
    if (result == 1) {
        // Show original image for comparison
        imshow("Original Input", inputImage);

        // Show and save the output image
        if (detector.ShowAndSaveImage(outputPath, outputImage, windowTitle) == 1) {
            cout << "Success! Image shown and saved to " << outputPath << endl;
        } else {
            cerr << "Error: Could not save image to " << outputPath << endl;
        }

        // Wait for user key press before exiting
        cout << ">>> Press any key to exit..." << endl;
        waitKey(0); 
        destroyAllWindows();
    } else {
        cerr << "Error: Image processing failed." << endl;
        return 1;
    }

    return 0;
}