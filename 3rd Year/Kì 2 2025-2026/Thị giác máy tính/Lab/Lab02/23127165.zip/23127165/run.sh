#!/bin/bash

# Thiết lập các biến đường dẫn
SRC_DIR="Sources"
EXEC_DIR="Executable"
DATA_DIR="Data"
EXEC_FILE="23127165"

INPUT_IMG_1="${DATA_DIR}/input_images/input_1.jpg"
OUTPUT_HARRIS_1="${DATA_DIR}/output_images/output_1/output_harris.jpg"
OUTPUT_OPT_HARRIS_1="${DATA_DIR}/output_images/output_1/output_optHarris.jpg"

INPUT_IMG_2="${DATA_DIR}/input_images/input_2.jpg"
OUTPUT_HARRIS_2="${DATA_DIR}/output_images/output_2/output_harris.jpg"
OUTPUT_OPT_HARRIS_2="${DATA_DIR}/output_images/output_2/output_optHarris.jpg"

echo "=================================================="
echo "    BẮT ĐẦU BUILD VÀ TEST HARRIS DETECTOR"
echo "=================================================="

# 1. Biên dịch chương trình
echo "[1/3] Đang biên dịch mã nguồn trong thư mục ${SRC_DIR}..."
cd ${SRC_DIR}
make clean
make
BUILD_STATUS=$?
cd ..

# Kiểm tra xem compile có thành công không
if [ $BUILD_STATUS -ne 0 ]; then
    echo "Lỗi: Biên dịch thất bại. Vui lòng kiểm tra lại mã nguồn hoặc Makefile."
    exit 1
fi

# Kiểm tra xem file thực thi có được tạo ra đúng thư mục không
if [ ! -f "${EXEC_DIR}/${EXEC_FILE}" ]; then
    echo "Lỗi: Không tìm thấy file thực thi tại ${EXEC_DIR}/${EXEC_FILE}!"
    exit 1
fi
echo "Biên dịch thành công!"
echo "--------------------------------------------------"

# 2. Kiểm tra ảnh đầu vào
if [ ! -f "$INPUT_IMG_1" ]; then
    echo "Lỗi: Không tìm thấy ảnh đầu vào tại $INPUT_IMG_1"
    echo "Vui lòng copy một bức ảnh và đổi tên thành 'input_image.jpg' bỏ vào thư mục Data/."
    exit 1
fi

if [ ! -f "$INPUT_IMG_2" ]; then
    echo "Lỗi: Không tìm thấy ảnh đầu vào tại $INPUT_IMG_2"
    echo "Vui lòng copy một bức ảnh và đổi tên thành 'input_image.jpg' bỏ vào thư mục Data/."
    exit 1
fi

# 3. Chạy test thuật toán Standard Harris
# ./Executable/23127165 -harris Data/input_images/input_1.jpg Data/output_images/output_1/output_harris.jpg

echo "[2/3] Đang chạy thuật toán Standard Harris cho ảnh 1..."
./${EXEC_DIR}/${EXEC_FILE} -harris $INPUT_IMG_1 $OUTPUT_HARRIS_1

if [ $? -eq 0 ]; then
    echo "Standard Harris hoàn tất! Ảnh lưu tại: $OUTPUT_HARRIS_1"
else
    echo "Standard Harris gặp lỗi trong quá trình thực thi."
fi

echo "Đang chạy thuật toán Standard Harris cho ảnh 2..."
./${EXEC_DIR}/${EXEC_FILE} -harris $INPUT_IMG_2 $OUTPUT_HARRIS_2

if [ $? -eq 0 ]; then
    echo "Standard Harris hoàn tất! Ảnh lưu tại: $OUTPUT_HARRIS_2"
else
    echo "Standard Harris gặp lỗi trong quá trình thực thi."
fi
echo "--------------------------------------------------"

# 4. Chạy test thuật toán Optimized Harris
# ./Executable/23127165 -optHarris Data/input_images/input_1.jpg Data/output_images/output_1/output_optHarris.jpg

echo "[3/3] Đang chạy thuật toán Optimized Harris cho ảnh 1..."
./${EXEC_DIR}/${EXEC_FILE} -optHarris $INPUT_IMG_1 $OUTPUT_OPT_HARRIS_1

if [ $? -eq 0 ]; then
    echo "Optimized Harris hoàn tất! Ảnh lưu tại: $OUTPUT_OPT_HARRIS_1"
else
    echo "Optimized Harris gặp lỗi trong quá trình thực thi."
fi

echo "Đang chạy thuật toán Optimized Harris cho ảnh 2..."
./${EXEC_DIR}/${EXEC_FILE} -optHarris $INPUT_IMG_2 $OUTPUT_OPT_HARRIS_2
``
if [ $? -eq 0 ]; then
    echo "Optimized Harris hoàn tất! Ảnh lưu tại: $OUTPUT_OPT_HARRIS_2"
else
    echo "Optimized Harris gặp lỗi trong quá trình thực thi."
fi

echo "--------------------------------------------------"

echo "=================================================="
echo "TEST HOÀN TẤT! Hãy vào thư mục Data/ để xem kết quả."
echo "=================================================="