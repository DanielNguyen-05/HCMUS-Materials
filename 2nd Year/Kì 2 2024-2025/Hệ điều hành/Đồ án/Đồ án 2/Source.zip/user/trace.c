#include "kernel/param.h"
#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
#include "kernel/fs.h"
#include "kernel/syscall.h"

int
main(int argc, char *argv[])
{
  char *nargv[MAXARG];
  int i;
  int mask = 0;
  int print_arguments = 0; // Flag for argument printing
  int nargc = argc; // Keep track of the original argc

  if (argc < 2) {
    fprintf(2, "Usage: %s [-a] mask command\n", argv[0]);
    exit(1);
  }

  // Parse command-line arguments
  for (i = 1; i < argc; i++) {
    if (argv[i][0] == '-') {
      if (argv[i][1] == 'a') { // -a flag for argument printing
        print_arguments = 1;
        nargc--;  // Decrement nargc for each flag
      }
      else {
        fprintf(2, "Usage: %s [-a] mask command\n", argv[0]);
        exit(1);
      }
    }
    else if (mask == 0) {
      mask = atoi(argv[i]);
      nargc--; // Decrement nargc for the mask
    }
    else
    {
      break; //End of the flags and mask, start of the command.
    }
  }


  if (mask == 0) {
    fprintf(2, "Usage: %s [-a] mask command\n", argv[0]);
    exit(1);
  }

  if (trace(mask) < 0) {  // Pass ONLY the mask to trace()
    fprintf(2, "%s: trace failed\n", argv[0]);
    exit(1);
  }

  //Set the print_arguments variable.
  setargs(print_arguments);

  // Construct the argument vector for exec.  Start from 'i'
  // which now points to the command to execute.
  for (int j = 0; i < argc && j < MAXARG; i++, j++) {
    nargv[j] = argv[i];
  }
  nargv[i - (argc - nargc)] = 0; // null terminate
  exec(nargv[0], nargv);
  exit(0);
}
