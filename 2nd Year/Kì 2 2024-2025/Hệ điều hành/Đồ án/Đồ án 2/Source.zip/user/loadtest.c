#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
#include "kernel/sysinfo.h"

#define NUM_PROCESSES 10
#define WORKLOAD 3000000 // Lighter workload for quicker execution

void print_sysinfo() {
    struct sysinfo info;
    if (sysinfo(&info) < 0) {
        printf("sysinfo failed\n");
        exit(1);
    }
    printf("Load Avg: %d.%d%d | Processes: %d | Free Mem: %d bytes\n",
           (int)(info.loadavg / 100), (int)((info.loadavg / 10) % 10), (int)(info.loadavg % 10),
           (int)info.nproc, (int)info.freemem);
}

void create_load(int num_procs) {
    for (int i = 0; i < num_procs; i++) {
        if (fork() == 0) {
            for (volatile int j = 0; j < WORKLOAD; j++) asm(""); // Consume CPU
            exit(0);
        }
    }
}

int main() {
    printf("=== Load Test (`loadtest`) ===\n");

    printf("[1] Initial system state:\n");
    print_sysinfo();

    printf("[2] Creating %d processes...\n", NUM_PROCESSES);
    create_load(NUM_PROCESSES);
    sleep(50);  // Allow load to register

    printf("[3] After load creation:\n");
    print_sysinfo();

    sleep(50);  // Another measurement after some time
    printf("[4] Load stabilizing:\n");
    print_sysinfo();

    printf("[5] Cleaning up processes...\n");
    for (int i = 0; i < NUM_PROCESSES; i++) wait(0);
    sleep(100); // Allow load to register 

    printf("[6] Final system state:\n");
    print_sysinfo();
    printf("=== Test Complete ===\n");
    exit(0);
}
