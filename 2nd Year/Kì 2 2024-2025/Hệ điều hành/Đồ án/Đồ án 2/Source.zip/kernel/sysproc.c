#include "types.h"
#include "riscv.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "spinlock.h"
#include "proc.h"
#include "syscall.h"
#include "sysinfo.h"

// Declare as external
extern int print_args;

uint64
sys_exit(void)
{
  int n;
  argint(0, &n);
  exit(n);
  return 0;  // not reached
}

uint64
sys_getpid(void)
{
  return myproc()->pid;
}

uint64
sys_fork(void)
{
  return fork();
}

uint64
sys_wait(void)
{
  uint64 p;
  argaddr(0, &p);
  return wait(p);
}

uint64
sys_sbrk(void)
{
  uint64 addr;
  int n;

  argint(0, &n);
  addr = myproc()->sz;
  if(growproc(n) < 0)
    return -1;
  return addr;
}

uint64
sys_sleep(void)
{
  int n;
  uint ticks0;

  argint(0, &n);
  if(n < 0)
    n = 0;
  acquire(&tickslock);
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    if(killed(myproc())){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

uint64
sys_kill(void)
{
  int pid;

  argint(0, &pid);
  return kill(pid);
}

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}

// implement sys_trace

uint64
sys_trace(void) {
  int trace_mask;
  argint(0, &trace_mask);
  myproc()->mask = (uint64)trace_mask;
  return 0;
}

// implement sys_sysinfo
uint64
sys_sysinfo(void)
{
  struct sysinfo si;
  si.freemem = kfreemem();  // Function to compute free memory
  si.nproc = countproc();   // Function to count active processes
  si.loadavg = get_load_avg();

  uint64 addr;
  argaddr(0, &addr);

  return copyout(myproc()->pagetable, addr, (char *)&si, sizeof(si));
}

// implement sys_setargs
int sys_setargs(void)
{
  int n;
  argint(0, &n);
  if (n < 0)
  {
    return -1;
  }
  print_args = n;
  return 0;
}
