struct sysinfo {
  uint64 freemem;   // Amount of free memory (bytes)
  uint64 nproc;     // Number of process
  uint64 loadavg;   // Load average (multiplied by 100 to avoid floating point)
};
