import java.util.Random;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

/**
 * States of philosophers in the dining philosophers problem
 */
enum State {
    THINKING, // Philosopher is thinking
    HUNGRY, // Philosopher is trying to pick up chopsticks
    EATING // Philosopher is eating
}

/**
 * Class to manage the chopsticks (resources) for 5 philosophers
 * Implements pickup and putdown methods as required by the exercise
 * Uses monitor solution with state variables
 */
class DiningPhilosophers {
    private final State[] states = new State[5]; // Track state of each philosopher
    private final Condition[] self = new Condition[5]; // Condition variable for each philosopher
    private final ReentrantLock lock = new ReentrantLock(); // Main lock for synchronization

    /**
     * Constructor initializes all philosophers to thinking state
     * and creates condition variables
     */
    public DiningPhilosophers() {
        // Initialize all philosophers to THINKING state
        for (int i = 0; i < 5; i++) {
            states[i] = State.THINKING;
        }

        // Create a condition variable for each philosopher
        for (int i = 0; i < 5; i++) {
            self[i] = lock.newCondition();
        }
    }

    /**
     * Helper method to check if a philosopher can eat
     * A philosopher can eat if neither neighbor is eating
     * 
     * @param i The philosopher to check
     */
    private void check(int i) {
        // Left neighbor is (i+4)%5, right neighbor is (i+1)%5
        // Philosopher can eat if hungry and neither neighbor is eating
        if (states[(i + 4) % 5] != State.EATING &&
                states[i] == State.HUNGRY &&
                states[(i + 1) % 5] != State.EATING) {

            // Update state to eating
            states[i] = State.EATING;

            // Signal this philosopher's condition
            self[i].signal();
        }
    }

    /**
     * Method for philosopher i to pick up chopsticks
     * Required by the exercise
     * 
     * @param philosopherId The ID of the philosopher (0-4)
     */
    public void pickup(int philosopherId) {
        lock.lock();
        try {
            // Update state to hungry
            states[philosopherId] = State.HUNGRY;
            System.out.println("Philosopher " + philosopherId + " is hungry and trying to pick up chopsticks.");

            // Check if this philosopher can eat now
            check(philosopherId);

            // If not eating yet, wait until signaled
            if (states[philosopherId] != State.EATING) {
                System.out.println("Philosopher " + philosopherId + " is waiting for chopsticks.");
                self[philosopherId].await();
            }

            System.out.println("Philosopher " + philosopherId + " picked up chopsticks and starts eating.");
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            System.err.println("Philosopher " + philosopherId + " was interrupted while waiting.");
        } finally {
            lock.unlock();
        }
    }

    /**
     * Method for philosopher i to put down chopsticks
     * Required by the exercise
     * 
     * @param philosopherId The ID of the philosopher (0-4)
     */
    public void putdown(int philosopherId) {
        lock.lock();
        try {
            // Update state to thinking
            states[philosopherId] = State.THINKING;
            System.out.println("Philosopher " + philosopherId + " put down chopsticks and is now thinking.");

            // Check if left neighbor can eat now
            check((philosopherId + 4) % 5);

            // Check if right neighbor can eat now
            check((philosopherId + 1) % 5);
        } finally {
            lock.unlock();
        }
    }
}

/**
 * Class representing a Philosopher thread
 * Implements Runnable as required by the exercise
 */
class Philosopher implements Runnable {
    private final DiningPhilosophers diningPhilosophers;
    private final int id;
    private final Random random = new Random();

    /**
     * Constructor as specified in the exercise
     * 
     * @param dp The DiningPhilosophers object that manages the chopsticks
     * @param i  The ID of this philosopher (0-4)
     */
    public Philosopher(DiningPhilosophers dp, int i) {
        this.diningPhilosophers = dp;
        this.id = i;
    }

    /**
     * Run method that implements the philosopher's lifecycle
     * Each philosopher thinks, picks up chopsticks, eats, and puts down chopsticks
     * This cycle repeats 10,000 times as required by the exercise
     */
    @Override
    public void run() {
        try {
            // Run 10,000 cycles as specified in the exercise
            for (int n = 0; n < 10000; n++) {
                // Think for a short time
                think();

                // Try to pick up chopsticks
                diningPhilosophers.pickup(id);

                try {
                    // Eat for 5-10 seconds as specified in the exercise
                    int eatTimeSeconds = random.nextInt(6) + 5; // Random sleep from 5-10 seconds
                    System.out.println("Philosopher " + id + " eating for " + eatTimeSeconds + " seconds...");
                    Thread.sleep(eatTimeSeconds * 1000); // Converting to milliseconds
                } finally {
                    // Put down chopsticks
                    diningPhilosophers.putdown(id);
                }
            }
            System.out.println("Philosopher " + id + " finished all 10,000 cycles.");
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            System.err.println("Philosopher " + id + " was interrupted.");
        } catch (Exception e) {
            System.err.println("Philosopher " + id + " encountered an error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Helper method to simulate philosopher thinking
     */
    private void think() throws InterruptedException {
        // Think for a short time before getting hungry
        int thinkTimeMs = random.nextInt(100) + 50;
        Thread.sleep(thinkTimeMs);
    }
}

/**
 * Main class to start the simulation with 5 philosophers
 */
public class DiningPhilosophersSimulation {
    public static void main(String[] args) {
        // Create one DiningPhilosophers object as required
        DiningPhilosophers diningPhilosophers = new DiningPhilosophers();

        // Create and start 5 threads as required by the exercise
        Thread[] threads = new Thread[5];
        System.out.println("Starting the Dining Philosophers simulation with 5 philosophers...");

        for (int i = 0; i < 5; i++) {
            threads[i] = new Thread(new Philosopher(diningPhilosophers, i), "Philosopher-" + i);
            threads[i].start();
        }

        // Wait for all philosophers to complete their 10,000 cycles
        try {
            for (int i = 0; i < 5; i++) {
                threads[i].join();
            }
            System.out.println("All philosophers have finished their cycles. Simulation complete.");
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            System.err.println("Main thread interrupted while waiting for philosophers.");
        }
    }
}