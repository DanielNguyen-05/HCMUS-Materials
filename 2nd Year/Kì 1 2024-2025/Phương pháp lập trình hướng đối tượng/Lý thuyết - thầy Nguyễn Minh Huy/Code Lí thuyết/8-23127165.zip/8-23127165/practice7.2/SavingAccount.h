#pragma once
#include "Account.h"

class SavingAccount : public Account {
private:
    int m_period;     // Kỳ hạn (tháng)
    float m_rate;     // Lãi suất hàng năm (%, ví dụ 0.5 tương đương 50%)
    int m_duration;   // Thời gian kể từ lần giao dịch cuối (tháng)

public:
    // Constructor với đầy đủ thông tin
    SavingAccount(float initial_balance, float rate, int duration, int period);

    // Tính lãi
    float calculateInterest() const;

    // Gửi tiền
    void deposit(float money);

    // Rút tiền
    bool withdraw(float money);

    // Tăng thời gian lên 1 tháng
    void incrementDuration();

    // Getters
    int getDuration() const;
    int getPeriod() const;
    float getRate() const;

    SavingAccount operator++(int);
};
