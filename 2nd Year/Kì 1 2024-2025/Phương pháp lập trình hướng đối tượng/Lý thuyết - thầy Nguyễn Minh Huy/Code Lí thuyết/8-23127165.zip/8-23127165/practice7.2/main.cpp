#include "SavingAccount.h"

int main() {
    SavingAccount account(1000, 4.1, 6, 12);
    SavingAccount account2(2300, 3.5, 12, 15);
    account2++; // Increase the duration by 1 month
    cout << "Account interest: " << account.calculateInterest() << "\n";
    account.deposit(1000);
    account2.withdraw(500);
    cout << "Account balance: " << fixed << setprecision(2) << account.getBalance() << "\n";
    cout << "Account2 balance: " << fixed << setprecision(2) << account2.getBalance() << "\n";
    return 0;
}
