#pragma once
#include <iostream>
#include <cmath>
#include <iomanip>
#include <stdexcept>
using namespace std;

class Account {
private:
    float m_balance;
public:
    float getBalance() const;
    void deposit(float money);
    bool withdraw(float money);
    float getBalance();
    void setBalance(float balance);
};