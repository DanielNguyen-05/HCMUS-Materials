#include "SavingAccount.h"

SavingAccount::SavingAccount(float initial_balance, float rate, int period, int duration) {
    setBalance(initial_balance);
    m_rate = rate;
    m_period = period;
    m_duration = duration;
}

float SavingAccount::calculateInterest() const {
    return getBalance() * pow(1 + m_rate / 100 / (12 / m_period), m_duration / m_period) - getBalance();
}

void SavingAccount::deposit(float money) {
    Account::deposit(calculateInterest() + money); // kêu hàm cha xử lí
    m_duration = 0;         // Reset duration
}

bool SavingAccount::withdraw(float money) {
    float newBalance = getBalance() + calculateInterest();
    if (money > newBalance) {
        return false; // Withdrawal fails if money exceeds available balance
    }
    setBalance(newBalance - money); // Update balance
    m_duration = 0;                 // Reset duration
    return true;
}

void SavingAccount::incrementDuration() {
    m_duration++;
}

int SavingAccount::getDuration() const {
    return m_duration;
}

int SavingAccount::getPeriod() const {
    return m_period;
}

float SavingAccount::getRate() const {
    return m_rate;
}

SavingAccount SavingAccount::operator++(int) {
    SavingAccount temp = *this; // Copy the current object
    m_duration++;              // Increment the duration
    return temp;               // Return the old value
}