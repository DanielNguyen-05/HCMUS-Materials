#include "Truck.h"

void Truck::run(double distance) {
    double baseConsumption = 20; // liters per 100 km
    double extraConsumption = 1 * (weight / 1000); // additional liters per 1000 kg
    double totalConsumption = (baseConsumption + extraConsumption) * (distance / 100);

    if (fuel >= totalConsumption) {
        fuel -= totalConsumption;
        cout << "Truck ran " << distance << " km.\nRemaining fuel: " << fuel << " liters.\n";
    }
    else {
        cout << "Not enough fuel for the trip.\n";
    }
}
