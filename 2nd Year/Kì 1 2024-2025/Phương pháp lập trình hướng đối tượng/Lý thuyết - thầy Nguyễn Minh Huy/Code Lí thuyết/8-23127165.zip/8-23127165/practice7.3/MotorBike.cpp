#include "MotorBike.h"

void MotorBike::run(double distance) {
    double baseConsumption = 2; // liters per 100 km
    double extraConsumption = 0.1 * (weight / 10); // additional liters per 10 kg
    double totalConsumption = (baseConsumption + extraConsumption) * (distance / 100);

    if (fuel >= totalConsumption) {
        fuel -= totalConsumption;
        cout << "MotorBike ran " << distance << " km.\nRemaining fuel: " << fuel << " liters.\n";
    }
    else {
        cout << "Not enough fuel for the trip.\n";
    }
}
