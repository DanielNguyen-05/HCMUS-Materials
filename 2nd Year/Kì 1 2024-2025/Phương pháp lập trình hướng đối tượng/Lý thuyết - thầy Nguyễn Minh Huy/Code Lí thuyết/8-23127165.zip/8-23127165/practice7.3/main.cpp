#include "MotorBike.h"
#include "Truck.h"

int main() {
    MotorBike bike;
    Truck truck;

    bike.addFuel(5);
    bike.addGoods(20);
    bike.run(50);

    truck.addFuel(50);
    truck.addGoods(2000);
    truck.run(100);

    return 0;
}
