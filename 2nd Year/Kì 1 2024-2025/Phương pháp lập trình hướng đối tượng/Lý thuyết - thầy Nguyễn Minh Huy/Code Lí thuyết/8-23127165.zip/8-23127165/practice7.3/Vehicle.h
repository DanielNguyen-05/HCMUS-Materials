#pragma once
#include <iostream>
#include <stdexcept>
using namespace std;

class Vehicle {
protected:
    double fuel; // Fuel in liters
    double weight; // Weight of goods in kg

public:
    Vehicle();
    virtual void addGoods(double goodsWeight);
    virtual void removeGoods(double goodsWeight);
    void addFuel(double fuelAmount);
    virtual void run(double distance) = 0; // Pure virtual function
    double getFuelLeft() const;
};

