#pragma once
#include "Vehicle.h"

class Truck : public Vehicle {
public:
    void run(double distance) override;
};

