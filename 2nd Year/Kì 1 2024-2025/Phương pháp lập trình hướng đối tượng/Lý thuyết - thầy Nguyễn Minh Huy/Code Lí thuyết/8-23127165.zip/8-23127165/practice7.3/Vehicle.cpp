#include "Vehicle.h"

Vehicle::Vehicle() : fuel(0), weight(0) {}

void Vehicle::addGoods(double goodsWeight) {
    if (goodsWeight < 0) {
        throw invalid_argument("Goods weight must be non-negative.");
    }
    weight += goodsWeight;
}

void Vehicle::removeGoods(double goodsWeight) {
    if (goodsWeight < 0) {
        throw invalid_argument("Goods weight must be non-negative.");
    }
    if (goodsWeight > weight) {
        throw invalid_argument("Not enough goods to remove.");
    }
    weight -= goodsWeight;
}

void Vehicle::addFuel(double fuelAmount) {
    if (fuelAmount < 0) {
        throw invalid_argument("Fuel amount must be non-negative.");
    }
    fuel += fuelAmount;
}

double Vehicle::getFuelLeft() const {
    return fuel;
}


