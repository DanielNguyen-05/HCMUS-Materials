#pragma once
#include "Vehicle.h"

class MotorBike : public Vehicle {
public:
    void run(double distance) override;
};

