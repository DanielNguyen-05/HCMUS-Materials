#include "Human.h"

int Human::getSpeed() const {
    return 50;
}

string Human::getType() const {
    return "Human";
}