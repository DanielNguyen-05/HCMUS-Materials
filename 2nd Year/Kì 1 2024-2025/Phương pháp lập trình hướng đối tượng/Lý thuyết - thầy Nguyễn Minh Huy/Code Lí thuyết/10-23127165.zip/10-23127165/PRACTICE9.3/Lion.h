#pragma once
#include "Animal.h"

class Lion : public Animal {
public:
    int getSpeed() const override;
    string getType() const override;
};