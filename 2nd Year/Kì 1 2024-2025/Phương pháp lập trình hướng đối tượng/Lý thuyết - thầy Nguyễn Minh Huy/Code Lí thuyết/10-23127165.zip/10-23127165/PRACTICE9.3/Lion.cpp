#include "Lion.h"

int Lion::getSpeed() const {
    return 70;
}

string Lion::getType() const {
    return "Lion";
}