#include "Animal.h"

string raceWinner(const Animal& animal1, const Animal& animal2) {
    int speed1 = animal1.getSpeed();
    int speed2 = animal2.getSpeed();
    if (speed1 > speed2) {
        return animal1.getType() + " wins the race!";
    }
    else if (speed1 < speed2) {
        return animal2.getType() + " wins the race!";
    }
    else {
        return "It's a tie between " + animal1.getType() + " and " + animal2.getType() + "!!!";
    }
}