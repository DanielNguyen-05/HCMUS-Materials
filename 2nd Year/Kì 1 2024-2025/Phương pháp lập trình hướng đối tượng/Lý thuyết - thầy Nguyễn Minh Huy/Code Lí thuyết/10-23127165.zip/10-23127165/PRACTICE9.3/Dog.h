#pragma once
#include "Animal.h"

class Dog : public Animal {
public:
    int getSpeed() const override;
    string getType() const override;
};