#include "Dog.h"

int Dog::getSpeed() const {
    return 60;
}

string Dog::getType() const {
    return "Dog";
}