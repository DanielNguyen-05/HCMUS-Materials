#include "Cheetah.h"

int Cheetah::getSpeed() const {
    return 100;
}

string Cheetah::getType() const {
    return "Cheetah";
}