#include "Horse.h"

int Horse::getSpeed() const {
    return 60;
}

string Horse::getType() const {
    return "Horse";
}