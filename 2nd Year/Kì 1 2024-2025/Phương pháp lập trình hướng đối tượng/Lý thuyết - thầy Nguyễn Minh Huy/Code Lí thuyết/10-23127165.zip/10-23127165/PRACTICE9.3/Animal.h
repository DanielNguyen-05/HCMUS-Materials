#pragma once
#include <iostream>
#include <string>
#include <vector>
using namespace std;

class Animal {
public:
    virtual int getSpeed() const = 0;     // Pure virtual function for speed
    virtual string getType() const = 0;   // Pure virtual function for name
    virtual ~Animal() = default;          // Virtual destructor

};

string raceWinner(const Animal& animals1, const Animal& animals2);