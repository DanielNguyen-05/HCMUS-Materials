#include "Antelope.h"
#include "Cheetah.h"
#include "Dog.h"
#include "Horse.h"
#include "Human.h"
#include "Lion.h"

int main() {
    // Store pointers to animals in a vector
    vector<Animal*> animals;
    animals.push_back(new Cheetah);
    animals.push_back(new Antelope);
    animals.push_back(new Lion);
    animals.push_back(new Dog);
    animals.push_back(new Human);
    animals.push_back(new Horse);

    // Compare animals in a race
    cout << "\nRace between " << animals[0]->getType() << " and " << animals[2]->getType() << ":\n";
    cout << "=> " << raceWinner(*animals[0], *animals[2]) << "\n";

    cout << "\nRace between " << animals[3]->getType() << " and " << animals[5]->getType() << ":\n";
    cout << "=> " << raceWinner(*animals[3], *animals[5]) << "\n";

    cout << "\nRace between " << animals[4]->getType() << " and " << animals[1]->getType() << ":\n";
    cout << "=> " << raceWinner(*animals[4], *animals[1]) << "\n";

    cout << "\nRace between " << animals[5]->getType() << " and " << animals[5]->getType() << ":\n";
    cout << "=> " << raceWinner(*animals[5], *animals[5]) << "\n";

    for (auto it : animals) {
        delete it;
    }

    return 0;
}

