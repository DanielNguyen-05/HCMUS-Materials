#include "Antelope.h"

int Antelope::getSpeed() const {
    return 80;
}

string Antelope::getType() const {
    return "Antelope";
}