#include "Point.h"

Point::Point() {
    x = 0.0;
    y = 0.0;
}

Point::Point(double xCoord, double yCoord) {
    x = xCoord;
    y = yCoord;
}

double Point::getX() const {
    return this->x;
}

double Point::getY() const {
    return this->y;
}

void Point::setX(double xCoord) {
    this->x = xCoord;
}

void Point::setY(double yCoord) {
    this->y = yCoord;
}

double Point::distanceTo(const Point& other) const {
    return sqrt(pow(x - other.getX(), 2) + pow(y - other.getY(), 2));
}

// Print point coordinates
void Point::print() const {
    cout << "(" << x << ", " << y << ")";
}

