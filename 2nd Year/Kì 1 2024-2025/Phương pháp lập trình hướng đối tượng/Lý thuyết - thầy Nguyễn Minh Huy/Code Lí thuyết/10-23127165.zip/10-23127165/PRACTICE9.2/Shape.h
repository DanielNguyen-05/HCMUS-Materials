#pragma once
#include "Point.h"

// Base Shape class using polymorphism
class Shape {
public:
    // Pure virtual function for printing shape information
    virtual void printInfo() const = 0;

    // Virtual destructor for proper inheritance
    virtual ~Shape() = default;
};

// Function to print shapes using polymorphism
void printShapes(const std::vector<Shape*>& shapes);