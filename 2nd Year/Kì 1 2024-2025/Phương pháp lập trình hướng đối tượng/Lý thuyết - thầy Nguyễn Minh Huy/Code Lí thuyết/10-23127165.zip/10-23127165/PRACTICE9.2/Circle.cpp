#include "Circle.h"

// Circle Implementation
Circle::Circle(const Point& cent, double r) :
    center(cent), radius(r) {
}

void Circle::printInfo() const {
    cout << "Circle:" << "\n";
    cout << "Center: ";
    center.print();
    cout << "\n";

    cout << "Radius: " << radius << "\n";

    // Calculate and print area
    double area = M_PI * radius * radius;
    cout << "Area: " << area << "\n";
}