#pragma once
#include "Shape.h"

// Circle class
class Circle : public Shape {
private:
    Point center;
    double radius;

public:
    Circle(const Point& cent, double r);
    void printInfo() const override;
};