#pragma once
#include "Shape.h"

// Rectangle class
class Rectangle : public Shape {
private:
    Point topLeft;
    Point bottomRight;

public:
    Rectangle(const Point& tl, const Point& br);
    void printInfo() const override;
};