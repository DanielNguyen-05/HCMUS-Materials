#include "Triangle.h"

// Triangle Implementation
Triangle::Triangle(const vector<Point>& trianglePoints) : points(trianglePoints) {
    if (points.size() != 3) {
        throw invalid_argument("Triangle must have exactly 3 points !!!");
    }
}

void Triangle::printInfo() const {
    cout << "Triangle:" << "\n";
    for (size_t i = 0; i < points.size(); ++i) {
        cout << "Point " << i + 1 << ": ";
        points[i].print();
        cout << "\n";
    }

    // Calculate and print area (using shoelace formula)
    double area = abs(points[0].getX() * (points[1].getY() - points[2].getY()) + points[1].getX() * (points[2].getY() - points[0].getY()) + points[2].getX() * (points[0].getY() - points[1].getY())) / 2.0;

    cout << "Area: " << area << "\n";
}