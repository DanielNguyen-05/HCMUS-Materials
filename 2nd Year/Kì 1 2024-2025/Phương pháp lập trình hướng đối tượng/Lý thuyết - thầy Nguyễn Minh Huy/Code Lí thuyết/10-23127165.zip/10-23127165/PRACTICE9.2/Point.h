#pragma once
#include <iostream>
#include <vector>
#include <cmath>
#include <stdexcept>
using namespace std;

// Point class to encapsulate 2D point coordinates
class Point {
private:
    double x, y;

public:
    // Constructors
    Point();
    Point(double xCoord, double yCoord);

    // Getters
    double getX() const;
    double getY() const;

    // Setter methods
    void setX(double xCoord);
    void setY(double yCoord);

    // Method to calculate distance between two points
    double distanceTo(const Point& other) const;

    // Print point coordinates
    void print() const;
};
