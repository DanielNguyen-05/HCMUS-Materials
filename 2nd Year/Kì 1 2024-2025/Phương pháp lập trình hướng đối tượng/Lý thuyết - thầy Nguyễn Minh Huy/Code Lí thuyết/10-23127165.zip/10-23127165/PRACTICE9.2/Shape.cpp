#include "Shape.h"

// Print Shapes Function Implementation
void printShapes(const vector<Shape*>& shapes) {
    for (const auto& it : shapes) {
        it->printInfo();
        cout << "-------------------" << "\n";
    }
}