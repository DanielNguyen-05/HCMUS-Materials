#pragma once
#include "Shape.h"

// Triangle class
class Triangle : public Shape {
private:
    vector<Point> points;

public:
    Triangle(const vector<Point>& trianglePoints);
    void printInfo() const override;
};