#include "Triangle.h"
#include "Rectangle.h"
#include "Circle.h"

int main() {
    // Create vectors of shapes
    vector<Shape*> shapes;

    // Add a triangle
    shapes.push_back(new Triangle({ Point(), Point(4.0, 0.0), Point(2.0, 3.0) }));

    // Add a rectangle
    shapes.push_back(new Rectangle(Point(1.0, 1.0), Point(5.0, 5.0)));

    // Add a circle
    shapes.push_back(new Circle(Point(3.0, 3.0), 2.0));

    // Print all shapes
    printShapes(shapes);

    // Clean up dynamically allocated memory
    for (auto it : shapes) {
        delete it;
    }

    return 0;
}