#include "Rectangle.h"

// Rectangle Implementation
Rectangle::Rectangle(const Point& tl, const Point& br) :
    topLeft(tl), bottomRight(br) {
}

void Rectangle::printInfo() const {
    cout << "Rectangle:" << "\n";
    cout << "Top-Left: ";
    topLeft.print();
    cout << "\n";

    cout << "Bottom-Right: ";
    bottomRight.print();
    cout << "\n";

    // Calculate and print width, height, area
    double width = abs(bottomRight.getX() - topLeft.getX());
    double height = abs(bottomRight.getY() - topLeft.getY());
    cout << "Width: " << width << "\n";
    cout << "Height: " << height << "\n";
    cout << "Area: " << width * height << "\n";
}
