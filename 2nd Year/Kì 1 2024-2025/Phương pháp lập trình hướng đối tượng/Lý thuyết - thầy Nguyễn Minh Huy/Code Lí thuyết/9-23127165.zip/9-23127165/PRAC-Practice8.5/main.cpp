#include "StandardCinema.h"
#include "VIPCinema.h"


int main() {
    try {
        // Tạo rạp chiếu phim
        StandardCinema standardCinema(5, 6); // 5 hàng, 6 cột
        VIPCinema vipCinema(5, 6);

        // Khởi tạo giá vé
        standardCinema.initializeStandardPrices(); // Giá cơ bản StandardCinema
        vipCinema.initializeVIPPrices(); // Giá cơ bản VIPCinema

        double total_price, temp_price;

        int choice;
        do {
            cout << "\n====== CINEMA MENU ======\n";
            cout << "1. Book a seat in Standard Cinema\n";
            cout << "2. Book a seat in VIP Cinema\n";
            cout << "3. Check a seat in Standard Cinema\n";
            cout << "4. Check a seat in VIP Cinema\n";
            cout << "5. Calculate total price for Standard Cinema\n";
            cout << "6. Calculate total price for VIP Cinema\n";
            cout << "7. Calculate total price of this account\n";
            cout << "8. Display seat map for Standard Cinema\n";
            cout << "9. Display seat map for VIP Cinema\n";
            cout << "10. Exit\n";
            cout << "=========================\n";
            cout << "Choose an option: ";
            cin >> choice;

            int row, col;
            switch (choice) {
            case 1:
                cout << "Enter row to book in Standard Cinema: ";
                cin >> row;
                cout << "Enter column to book in Standard Cinema: ";
                cin >> col;
                if (standardCinema.bookSeat(row - 1, col - 1)) {
                    cout << "Seat successfully booked.\n";
                }
                else {
                    cout << "Seat is already booked or invalid.\n";
                }
                break;

            case 2:
                cout << "Enter row to book in VIP Cinema: ";
                cin >> row;
                cout << "Enter column to book in VIP Cinema: ";
                cin >> col;
                if (vipCinema.bookSeat(row - 1, col - 1)) {
                    cout << "Seat successfully booked.\n";
                }
                else {
                    cout << "Seat is already booked or invalid.\n";
                }
                break;

            case 3:
                cout << "Enter row to check in Standard Cinema: ";
                cin >> row;
                cout << "Enter column to check in Standard Cinema: ";
                cin >> col;
                if (standardCinema.checkSeat(row - 1, col - 1)) {
                    cout << "Seat is booked.\n";
                }
                else {
                    cout << "Seat is available.\n";
                }
                break;

            case 4:
                cout << "Enter row to check in VIP Cinema: ";
                cin >> row;
                cout << "Enter column to check in VIP Cinema: ";
                cin >> col;
                if (vipCinema.checkSeat(row - 1, col - 1)) {
                    cout << "Seat is booked.\n";
                }
                else {
                    cout << "Seat is available.\n";
                }
                break;

            case 5:
                cout << "Total price for Standard Cinema: $"
                    << standardCinema.calculateTotalPrice() << "\n";
                break;

            case 6:
                temp_price = vipCinema.calculateTotalPrice();
                cout << "Total price for VIP Cinema: $" << temp_price << "\n";;
                break;
            case 7:
                total_price = vipCinema.calculateTotalPrice();
                cout << "Total price for this account: $"
                    << standardCinema.calculateTotalPrice() + total_price << "\n";
                break;

            case 8:
                cout << "\nSeat Map of Standard Cinema:\n";
                for (int i = 0; i < standardCinema.getRows(); i++) {
                    for (int j = 0; j < standardCinema.getCols(); j++) {
                        cout << (standardCinema.checkSeat(i, j) ? "[X]" : "[ ]") << " ";
                    }
                    cout << "\n";
                }
                break;

            case 9:
                cout << "\nSeat Map of Vip Cinema:\n";
                for (int i = 0; i < vipCinema.getRows(); i++) {
                    for (int j = 0; j < vipCinema.getCols(); j++) {
                        cout << (vipCinema.checkSeat(i, j) ? "[X]" : "[ ]") << " ";
                    }
                    cout << "\n";
                }
                break;

            case 10:
                cout << "Exiting...\n";
                break;

            default:
                cout << "Invalid option. Please try again.\n";
                break;
            }
        } while (choice != 10);

    }
    catch (const exception& e) {
        cout << "Error: " << e.what() << "\n";
    }

    return 0;
}
