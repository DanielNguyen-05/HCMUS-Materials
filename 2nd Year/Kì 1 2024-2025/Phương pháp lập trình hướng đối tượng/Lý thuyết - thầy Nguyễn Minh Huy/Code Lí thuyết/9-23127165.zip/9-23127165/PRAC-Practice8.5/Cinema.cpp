#include "Cinema.h"

Cinema::Cinema(int rows, int cols) {
    if (rows <= 0 || cols <= 0) {
        throw invalid_argument("Invalid rows or cols !!!");
    }
    m_rows = rows;
    m_cols = cols;
    m_central = rows / 2; // Central row index
    m_seats.resize(rows, vector<bool>(cols, false));
    m_price.resize(rows, 0);
}

bool Cinema::bookSeat(int row, int col) {
    if (row < 0 || row >= m_rows || col < 0 || col >= m_cols) {
        throw out_of_range("Invalid seat position.");
    }
    if (m_seats[row][col]) {
        return false; // Already booked
    }
    m_seats[row][col] = true;
    return true;
}

bool Cinema::checkSeat(int row, int col) const {
    if (row < 0 || row >= m_rows || col < 0 || col >= m_cols) {
        throw out_of_range("Invalid seat position.");
    }
    return m_seats[row][col];
}

int Cinema::getRows() const {
    return m_rows;
}

int Cinema::getCols() const {
    return m_cols;
}

double Cinema::getPrice(int row) const {
    if (row < 0 || row >= m_rows) {
        throw out_of_range("Invalid row.");
    }
    return m_price[row];
}

void Cinema::initializeRowPrices(double centralPrice) {
    if (centralPrice < 0) {
        throw invalid_argument("Central price must be non-negative.");
    }
    m_price[m_central] = centralPrice;

    for (int i = 0; i < m_rows; ++i) {
        if (i != m_central) {
            double price = centralPrice - abs(i - m_central) * 0.5;
            m_price[i] = max(price, 0.0); // Ensure non-negative prices
        }
    }
}

bool Cinema::isFull() const {
    for (const auto& row : m_seats) {
        if (find(row.begin(), row.end(), false) != row.end()) {
            return false;
        }
    }
    return true;
}

void Cinema::resetSeat(int row, int col) {
    if (row < 0 || row >= m_rows || col < 0 || col >= m_cols) {
        throw out_of_range("Invalid seat position.");
    }
    m_seats[row][col] = false;
}

Cinema::Cinema(const Cinema& other)
    : m_rows(other.m_rows), m_cols(other.m_cols), m_central(other.m_central),
    m_seats(other.m_seats), m_price(other.m_price) {
}

Cinema& Cinema::operator=(const Cinema& other) {
    if (this != &other) {
        m_rows = other.m_rows;
        m_cols = other.m_cols;
        m_central = other.m_central;
        m_seats = other.m_seats;
        m_price = other.m_price;
    }
    return *this;
}

Cinema::~Cinema() {
    m_seats.clear();
    m_price.clear();
}
