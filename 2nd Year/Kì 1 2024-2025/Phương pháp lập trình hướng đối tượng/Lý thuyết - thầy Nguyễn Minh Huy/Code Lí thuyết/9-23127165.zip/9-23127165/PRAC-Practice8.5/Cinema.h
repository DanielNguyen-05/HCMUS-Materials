#pragma once
#include <iostream>
#include <vector>
#include <stdexcept>
#include <algorithm>
#include <string>

using namespace std;

class Cinema {
private:
    int m_rows, m_cols, m_central;
    vector<vector<bool>> m_seats;
    vector<double> m_price;

public:
    Cinema(int rows, int cols);

    bool bookSeat(int row, int col);
    bool checkSeat(int row, int col) const;

    int getRows() const;
    int getCols() const;
    double getPrice(int row) const;
    void initializeRowPrices(double centralPrice);

    // Utility methods
    bool isFull() const;
    void resetSeat(int row, int col);

    // Big Three
    Cinema(const Cinema& other);
    Cinema& operator = (const Cinema& other);
    ~Cinema();
};
