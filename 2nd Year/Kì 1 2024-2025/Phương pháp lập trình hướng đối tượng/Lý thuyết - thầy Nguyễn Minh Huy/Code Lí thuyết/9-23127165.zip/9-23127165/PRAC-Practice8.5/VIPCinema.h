#pragma once
#include "Cinema.h"

class VIPCinema : public Cinema {
private:
    const double VIP_PRICE = 15.0; // Default price for VIP seats

public:
    VIPCinema(int rows, int cols);

    double calculateTotalPrice() const; // Calculate total revenue with discounts
    bool isThursday(const std::string& day) const; // Check if the day is Thursday
    void initializeVIPPrices();


    // Big Three
    VIPCinema(const VIPCinema& other);
    VIPCinema& operator=(const VIPCinema& other);
    ~VIPCinema();
};
