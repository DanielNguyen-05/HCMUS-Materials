#pragma once
#include "Cinema.h"

class StandardCinema : public Cinema {
private:
    const double STANDARD_PRICE = 10.0; // Default standard price

public:
    StandardCinema(int rows, int cols);
    double calculateTotalPrice() const; // Calculate the total revenue
    void initializeStandardPrices();

    // Big Three
    StandardCinema(const StandardCinema& other);
    StandardCinema& operator=(const StandardCinema& other);
    ~StandardCinema();
};
