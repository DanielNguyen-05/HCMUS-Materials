#include "StandardCinema.h"

StandardCinema::StandardCinema(int rows, int cols) : Cinema(rows, cols) {}

double StandardCinema::calculateTotalPrice() const {
    double total_price = 0;
    for (int i = 0; i < getRows(); ++i) {
        for (int j = 0; j < getCols(); ++j) {
            if (checkSeat(i, j)) {
                total_price += getPrice(i); // Standard price applied
            }
        }
    }
    return total_price;
}

void StandardCinema::initializeStandardPrices() {
    initializeRowPrices(STANDARD_PRICE);
}

// Copy constructor
StandardCinema::StandardCinema(const StandardCinema& other) : Cinema(other) {}

// Assignment operator
StandardCinema& StandardCinema::operator=(const StandardCinema& other) {
    if (this != &other) {
        Cinema::operator=(other); // Delegate to the base class
    }
    return *this;
}

// Destructor
StandardCinema::~StandardCinema() {
    cout << "=> Standard Cinema destructor called." << "\n";
}
