#include "VIPCinema.h"

VIPCinema::VIPCinema(int rows, int cols) : Cinema(rows, cols) {}

double VIPCinema::calculateTotalPrice() const {
    double total_price = 0;
    for (int i = 0; i < getRows(); ++i) {
        for (int j = 0; j < getCols(); ++j) {
            if (checkSeat(i, j)) {
                total_price += getPrice(i); // Add the price of booked seats
            }
        }
    }

    string day;
    cout << "Is it Thursday? (Y/N): ";
    cin >> day;
    cout << "\n";

    // Apply Thursday discount
    if (isThursday(day)) {
        total_price *= 0.8; // 20% discount
    }

    return total_price;
}

bool VIPCinema::isThursday(const string& day) const {
    if (day == "Y" || day == "y" || day == "Yes" || day == "yes") {
        return true;
    }
    return false;
}

void VIPCinema::initializeVIPPrices() {
    initializeRowPrices(VIP_PRICE); // All rows use the VIP pricing
}

// Copy constructor
VIPCinema::VIPCinema(const VIPCinema& other) : Cinema(other) {}

// Assignment operator
VIPCinema& VIPCinema::operator=(const VIPCinema& other) {
    if (this != &other) {
        Cinema::operator=(other); // Delegate to the base class
    }
    return *this;
}

// Destructor
VIPCinema::~VIPCinema() {
    cout << "=> VIP Cinema destructor called." << endl;
}
