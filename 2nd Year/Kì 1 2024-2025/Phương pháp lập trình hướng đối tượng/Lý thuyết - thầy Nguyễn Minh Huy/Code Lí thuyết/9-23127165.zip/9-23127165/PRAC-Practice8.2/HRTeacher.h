#pragma once
#include "Teacher.h"

class HRTeacher : public Teacher {
private:
    char* m_classRoom;
public:
    HRTeacher();
    HRTeacher(const char* m_class);
    HRTeacher(const char* name, float salary, int vacation, const char* classRoom);

    // Getter
    char* getClassRoom() const;

    // Big Three in Inheritance
    HRTeacher(const HRTeacher& other);
    HRTeacher& operator = (const HRTeacher& other);
    ~HRTeacher();
};