#include "HRTeacher.h"

int main() {
    HRTeacher hrTeacher1("John", 1000, 10, "Room 1");
    cout << "HRTeacher1: " << hrTeacher1.getName() << ", " << hrTeacher1.getSalary() << ", " << hrTeacher1.getVacation() << ", " << hrTeacher1.getClassRoom() << "\n";
    HRTeacher hrTeacher2 = hrTeacher1;
    cout << "HRTeacher2: " << hrTeacher2.getName() << ", " << hrTeacher2.getSalary() << ", " << hrTeacher2.getVacation() << ", " << hrTeacher2.getClassRoom() << "\n";
    HRTeacher hrTeacher3;
    hrTeacher3 = hrTeacher1;
    cout << "HRTeacher3: " << hrTeacher3.getName() << ", " << hrTeacher3.getSalary() << ", " << hrTeacher3.getVacation() << ", " << hrTeacher3.getClassRoom() << "\n";

    return 0;
}

