#include "HRTeacher.h"

HRTeacher::HRTeacher() {
    m_classRoom = NULL;
}

HRTeacher::HRTeacher(const char* classRoom) {
    m_classRoom = new char[strlen(classRoom) + 1];
    strcpy(m_classRoom, classRoom);
}

HRTeacher::HRTeacher(const char* name, float salary, int vacation, const char* classRoom) : Teacher(name, salary, vacation) {
    m_classRoom = new char[strlen(classRoom) + 1];
    strcpy(m_classRoom, classRoom);
}

char* HRTeacher::getClassRoom() const {
    return m_classRoom;
}

HRTeacher::HRTeacher(const HRTeacher& other) : Teacher(other) {
    m_classRoom = new char[strlen(other.m_classRoom) + 1];
    strcpy(m_classRoom, other.m_classRoom);
}

HRTeacher& HRTeacher::operator = (const HRTeacher& other) {
    if (this != &other) {
        Teacher::operator = (other);
        if (m_classRoom != NULL) {
            delete[] m_classRoom;
        }
        m_classRoom = new char[strlen(other.m_classRoom) + 1];
        strcpy(m_classRoom, other.m_classRoom);
    }
    return *this;
}

HRTeacher::~HRTeacher() {
    if (m_classRoom != NULL) {
        delete[] m_classRoom;
    }
}
