#pragma once
#include <iostream>
#include <cstring>
#include <cmath>
#include <iomanip>
#include <stdexcept>
using namespace std;

class Teacher {
private:
    char* m_name;
    float m_salary;
    int m_vacation;
public:
    Teacher();
    Teacher(const char* name, float salary, int vacation);

    // Getter
    char* getName() const;
    float getSalary() const;
    int getVacation() const;

    // Big Three in Inheritance
    Teacher(const Teacher& other);
    Teacher& operator = (const Teacher& other);
    ~Teacher();
};