#include "Teacher.h"

Teacher::Teacher() {
    m_name = NULL;
    m_salary = 0;
    m_vacation = 0;
}

Teacher::Teacher(const char* name, float salary, int vacation) {
    m_name = new char[strlen(name) + 1];
    strcpy(m_name, name);
    m_salary = salary;
    m_vacation = vacation;
}

char* Teacher::getName() const {
    return m_name;
}

float Teacher::getSalary() const {
    return m_salary;
}

int Teacher::getVacation() const {
    return m_vacation;
}

Teacher::Teacher(const Teacher& other) {
    m_name = new char[strlen(other.m_name) + 1];
    strcpy(m_name, other.m_name);
    m_salary = other.m_salary;
    m_vacation = other.m_vacation;
}

Teacher& Teacher::operator = (const Teacher& other) {
    if (this != &other) {
        if (m_name != NULL) {
            delete[] m_name;
        }
        m_name = new char[strlen(other.m_name) + 1];
        strcpy(m_name, other.m_name);
        m_salary = other.m_salary;
        m_vacation = other.m_vacation;
    }
    return *this;
}

Teacher::~Teacher() {
    if (m_name != NULL) {
        delete[] m_name;
    }
}
