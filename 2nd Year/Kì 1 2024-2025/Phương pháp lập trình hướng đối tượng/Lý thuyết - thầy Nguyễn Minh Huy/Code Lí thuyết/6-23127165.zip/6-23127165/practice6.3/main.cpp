#include <iostream>
#include <string>
#include <algorithm>
#include <cctype>
#include <sstream>
using namespace std;

string normalizeText(const string& input) {
    // Trim leading and trailing non-alphanumeric characters
    auto start = find_if(input.begin(), input.end(), [](char ch) { return isalnum(ch); });
    auto end = find_if(input.rbegin(), input.rend(), [](char ch) { return isalnum(ch); }).base();

    string trimmed(start, end); // Substring with trimmed spaces and punctuations

    // Replace multiple consecutive spaces or punctuations with a single space, and capitalize the first letter of each word
    string normalized;
    bool isInWord = false;  // Flag to track if we are in the middle of a word
    bool shouldCapitalize = true;  // Flag to capitalize the first letter of each word

    for (char ch : trimmed) {
        if (isalnum(ch)) {
            // Capitalize the first letter of each word
            if (shouldCapitalize) {
                normalized += toupper(ch);
                shouldCapitalize = false;
            }
            else {
                normalized += tolower(ch);
            }
            isInWord = true;
        }
        else if (isInWord) {  // When a space or punctuation follows a word
            normalized += ' ';  // Add a single space between words
            isInWord = false;
            shouldCapitalize = true;  // Prepare to capitalize the next word
        }
    }

    return normalized;
}

int main() {
    string rawText = " [[[the quick,,, brown fox ]]] ";

    string normalizedText = normalizeText(rawText);

    cout << "Original Text: \"" << rawText << "\"" << "\n";
    cout << "Normalized Text: \"" << normalizedText << "\"" << "\n";

    return 0;
}
