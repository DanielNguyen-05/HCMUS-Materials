#include <iostream>
#include <list>
#include <vector>
#include <cstdlib>
#include <ctime>
#include <algorithm>
#include <cmath>
using namespace std;

// Generates a list with specified even and odd index values.
list<int> generateEvenOddList(int size) {
    vector<int> values(size);
    srand(static_cast<unsigned>(time(0)));

    // Assign sequential values at even indexes.
    for (int i = 0; i < size; i += 2) {
        values[i] = i / 2 + 1;
    }

    // Assign random values at odd indexes.
    for (int i = 1; i < size; i += 2) {
        values[i] = rand() % 2810 + 1;
    }

    return list<int>(values.begin(), values.end());
}

bool isPrime(int number) {
    if (number < 2) return false;
    for (int i = 2; i * i <= number; i++) {
        if (number % i == 0) return false;
    }
    return true;
}

// Generates a list of the first 'count' prime numbers.
list<int> generatePrimeList(int count) {
    list<int> primeNumbers;
    int current = 2;

    generate_n(back_inserter(primeNumbers), count, [&current]() {
        while (!isPrime(current)) {
            current++;
        }
        return current++;
        });
    return primeNumbers;
}

int main() {
    int numElements = 10;

    list<int> evenOddList = generateEvenOddList(numElements);
    cout << "List with even and odd index values:\n";
    for (int value : evenOddList) {
        cout << value << " ";
    }
    cout << "\n";

    list<int> primeList = generatePrimeList(numElements);
    cout << "List of first " << numElements << " prime numbers:\n";
    for (int prime : primeList) {
        cout << prime << " ";
    }
    cout << "\n";

    return 0;
}
