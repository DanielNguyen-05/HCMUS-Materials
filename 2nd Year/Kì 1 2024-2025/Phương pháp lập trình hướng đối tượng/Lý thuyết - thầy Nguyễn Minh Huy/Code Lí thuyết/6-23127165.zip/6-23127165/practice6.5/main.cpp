#include "GPA_Manager.h"

int main() {
    GPA_Manager manager;

    manager.addStudent(Student("John", 7));
    manager.addStudent(Student("Eve", 9));
    manager.addStudent(Student("Ander", 7));
    manager.addStudent(Student("Dora", 8));
    manager.addStudent(Student("Tom", 7));
    manager.addStudent(Student("Alex", 9));

    manager.printGPA();

    return 0;
}
