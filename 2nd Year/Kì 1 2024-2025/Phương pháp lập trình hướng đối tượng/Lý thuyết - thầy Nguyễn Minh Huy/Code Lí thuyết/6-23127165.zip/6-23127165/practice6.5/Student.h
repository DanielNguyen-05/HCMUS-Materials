#pragma once
#include <iostream>
#include <vector>
#include <unordered_map>
#include <string>
#include <algorithm>
#include <stdexcept>
using namespace std;

class Student {
private:
    string name;
    int gpa;
public:
    Student(const string& name, int gpa);
    string getName() const;
    int getGPA() const;
};

