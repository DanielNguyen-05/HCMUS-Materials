#include "GPA_Manager.h"

// Add student to the list
void GPA_Manager::addStudent(const Student& student) {
    students.push_back(student);
}

// Print GPA counts sorted by frequency
void GPA_Manager::printGPA() {
    unordered_map<int, int> gpaCounts;

    // Count occurrences of each GPA
    for (const auto& student : students) {
        gpaCounts[student.getGPA()]++;
    }

    // Create a vector from the map for sorting by count
    vector<pair<int, int>> sortedGpaCounts(gpaCounts.begin(), gpaCounts.end());

    // Sort in descending order of the count (second value of the pair)
    sort(sortedGpaCounts.begin(), sortedGpaCounts.end(),
        [](const pair<int, int>& a, const pair<int, int>& b) {
            return a.second > b.second;
        });

    // Print the GPA counts in sorted order
    for (const auto& gpaCount : sortedGpaCounts) {
        cout << "GPA " << gpaCount.first << ": " << gpaCount.second << " students.\n";
    }
}
