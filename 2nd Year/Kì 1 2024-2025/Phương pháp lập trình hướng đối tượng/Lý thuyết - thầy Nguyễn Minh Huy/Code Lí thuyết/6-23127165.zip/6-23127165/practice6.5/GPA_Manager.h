#pragma once
#include "Student.h"

class GPA_Manager {
private:
    vector<Student> students;
public:
    void addStudent(const Student& student);
    void printGPA();
};

