#include "Student.h"

Student::Student(const string& name, int gpa) {
    this->name = name;
    if (gpa < 0 || gpa > 10) {
        throw invalid_argument("GPA must be between 0 and 10.");
    }
    this->gpa = gpa;
}

string Student::getName() const {
    return name;
}

int Student::getGPA() const {
    return gpa;
}
