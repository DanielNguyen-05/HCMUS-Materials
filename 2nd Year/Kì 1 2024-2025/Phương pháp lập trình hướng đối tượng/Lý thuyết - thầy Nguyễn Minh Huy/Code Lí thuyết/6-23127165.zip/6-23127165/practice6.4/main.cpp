#include <iostream>
#include <fstream>
#include <iterator>
#include <cmath>
#include <stdexcept>
#include <algorithm>
using namespace std;

bool isPrime(int number) {
    if (number <= 1) return false;
    for (int i = 2; i * i <= number; ++i) {
        if (number % i == 0) return false;
    }
    return true;
}

void filterPrimeNumbers(const string& inputFileName, const string& outputFileName) {
    ifstream fIn(inputFileName);
    ofstream fOut(outputFileName);

    if (!fIn.is_open()) {
        throw invalid_argument("Error: Cannot open input file !!!");
    }

    if (!fOut.is_open()) {
        throw invalid_argument("Error: Cannot open output file !!!");
    }

    copy_if(istream_iterator<int>(fIn), istream_iterator<int>(),
        ostream_iterator<int>(fOut, "\n"),
        [](int number) { return !isPrime(number); });

    fIn.close();
    fOut.close();
}

int main() {
    try {
        filterPrimeNumbers("INPUT.TXT", "OUTPUT.TXT");
        cout << "Processing complete. Prime numbers have been written to OUTPUT.TXT" << "\n";
    }
    catch (const invalid_argument& ex) {
        cerr << "File error: " << ex.what() << "\n";
    }
    catch (const exception& ex) {
        cerr << "An unexpected error occurred: " << ex.what() << "\n";
    }

    return 0;
}
