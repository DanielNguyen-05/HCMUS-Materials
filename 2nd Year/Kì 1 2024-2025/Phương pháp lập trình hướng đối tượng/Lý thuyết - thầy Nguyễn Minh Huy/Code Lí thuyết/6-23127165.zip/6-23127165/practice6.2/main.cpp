#include <iostream>
#include <string>
#include <algorithm>
#include <cctype>
using namespace std;

bool isPalindrome(const string& input) {
    // Remove non-alphanumeric characters and convert to lowercase
    string filtered;
    copy_if(input.begin(), input.end(), back_inserter(filtered),
        [](char ch) { return isalnum(static_cast<unsigned char>(ch)); });

    // Convert all characters to lowercase for case-insensitive comparison
    transform(filtered.begin(), filtered.end(), filtered.begin(), ::tolower);

    // Check if the filtered string is the same when reversed
    int left = 0, right = filtered.size() - 1;
    while (left < right) {
        if (filtered[left] != filtered[right]) {
            return false;
        }
        ++left;
        --right;
    }

    return true;
}

int main() {
    string test1 = "Race car";
    string test2 = "A man, a plan, a canal, Panama!";
    string test3 = "Hello, World!";

    // Output results for each test case
    cout << "\"" << test1 << "\" is "
        << (isPalindrome(test1) ? "a palindrome" : "not a palindrome")
        << "." << "\n";

    cout << "\"" << test2 << "\" is "
        << (isPalindrome(test2) ? "a palindrome" : "not a palindrome")
        << "." << "\n";

    cout << "\"" << test3 << "\" is "
        << (isPalindrome(test3) ? "a palindrome" : "not a palindrome")
        << "." << "\n";

    return 0;
}
