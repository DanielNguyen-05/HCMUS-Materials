#include "Student.h"

Student::Student(char* name, float literature, float math) {
    this->name = new char[strlen(name) + 1];
    strcpy(this->name, name);
    this->literature = literature;
    this->math = math;
}

Student::Student(char* name) {
    this->name = new char[strlen(name) + 1];
    strcpy(this->name, name);
    this->literature = 0;
    this->math = 0;
}

Student::Student(const Student& stu) {
    this->name = new char[strlen(stu.name) + 1];
    strcpy(this->name, stu.name);   
    this->literature = stu.literature;
    this->math = stu.math;
}

Student::~Student() {
    delete[] this->name;
    cout << "Student " << name << " is disposed successfully !!!" << "\n";
}

char* Student::getName() {
    return this->name;
}

float Student::getLiterature() {
    return this->literature;
}

float Student::getMath() {
    return this->math;
}



