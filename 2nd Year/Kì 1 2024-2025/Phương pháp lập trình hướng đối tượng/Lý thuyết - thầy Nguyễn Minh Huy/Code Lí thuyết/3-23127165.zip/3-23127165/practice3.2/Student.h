#pragma once
#include <iostream>
#include <cstring>
using namespace std;

class Student {
    private:
        char* name;
        float literature;
        float math;
    public:
        // This is the constructor to initialize a student with name, math, literature points
        Student(char* name, float literature, float math);

        // This is the constructor to initialize a student with name, math = literature = 0
        Student(char* name);

        // This is the constructor to initialize a student from another student
        Student(const Student& stu);

        // This is the destructor to dispose a student without memory leak
        ~Student();

        // This is the getter to get student name
        char* getName();

        // This is the getter to get student literature points
        float getLiterature();

        // This is the getter to get student math points
        float getMath();
};