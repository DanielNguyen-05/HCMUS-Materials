#include "Student.h"

int main() {
    // Create a student object with name, literature, math points
    Student student1("John", 8.5, 9.0);
    
    // Create a student object with name, literature = math = 0
    Student student2("Alice");
    
    // Create a student object with name, literature, math points (copy of student1)
    Student student3(student1);
    
    // Print student1 information
    cout << "- Student 1: " << student1.getName() << "\n";
    cout << "- Literature: " << student1.getLiterature() << "\n";
    cout << "- Math: " << student1.getMath() << "\n\n";
    
    // Print student2 information
    cout << "- Student 2: " << student2.getName() << "\n";
    cout << "- Literature: " << student2.getLiterature() << "\n";
    cout << "-Math: " << student2.getMath() << "\n\n";
    
    // Print student3 information
    cout << "- Student 3 (copy of Student 1): " << student3.getName() << "\n"; 
    cout << "- Literature: " << student3.getLiterature() << "\n";
    cout << "- Math: " << student3.getMath() << "\n\n";
    
    // When the program ends, all student objects are disposed

    return 0;
}