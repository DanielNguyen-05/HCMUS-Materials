#pragma once
#include <iostream>
#include <algorithm>
using namespace std;

template <class T>
class Array {
    private:
        T* data;
        size_t size;
    public: 
        // Default constructor initializes an array with zero-length
        Array();

        // Constructor initializes an array with length, and all elements are set to 0
        Array(size_t size);

        // Constructor initializes an array with length, and all elements are set to data
        Array(size_t size, T* data);

        // Copy constructor initializes an array with the same length and data as another array
        Array(const Array& other);

        // Destructor disposes an array without memory leaks
        ~Array();

        // Overload operator [] to access elements in the array
        T& operator[](size_t index);

        // Get the size of the array
        size_t getSize();
};

template <class T>
Array<T>::Array() {
    this->size = 0;
    this->data = NULL;
}

template <class T>
Array<T>::Array(size_t size) {
    this->size = size;
    this->data = new T[size];
    for (int i = 0; i < size; i++) {
        data[i] = 0;
    }
}

template <class T>
Array<T>::Array(size_t size, T* data) {
    this->size = size;
    this->data = new T[size];
    for (int i = 0; i < size; i++) {
        this->data[i] = data[i];
    }
}

template <class T>
Array<T>::Array(const Array& other) {
    this->size = other.size;
    this->data = new T[size];
    for (int i = 0; i < size; i++) {
        this->data[i] = other.data[i];
    }
}

template <class T>
Array<T>::~Array() {
    delete[] data;
    cout << "Array is disposed successfully !!!" << "\n";
}

template <class T>
T& Array<T>::operator[](size_t index) {
    return this->data[index];
}

template <class T>
size_t Array<T>::getSize() {
    return this->size;
}