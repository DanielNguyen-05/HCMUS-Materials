#include "Array.hpp"

int main() {
    // Create an Array object with size 0
    Array<int> arr0;
    cout << "- Array 0 (size 0): " << arr0.getSize() << "\n";

    // Create an Array object with size 5 and default values set to 0
    Array<int> arr1(5);
    cout << "- Array 1 (default values): ";
    for (size_t i = 0; i < arr1.getSize(); ++i) {
        cout << arr1[i] << " ";
    }
    cout << "\n";

    // Create a data array and initialize an Array object using this data
    int data[] = {1, 2, 3, 4, 5};
    Array<int> arr2(5, data);
    cout << "- Array 2 (initialized with data): ";
    for (size_t i = 0; i < arr2.getSize(); ++i) {
        cout << arr2[i] << " ";
    }
    cout << "\n";

    // Use the copy constructor to create a copy of arr2
    Array<int> arr3(arr2);
    cout << "- Array 3 (copy of Array 2): ";
    for (size_t i = 0; i < arr3.getSize(); ++i) {
        cout << arr3[i] << " ";
    }
    cout << "\n";

    // Destructor will be called automatically when the objects go out of scope
    return 0;
}
