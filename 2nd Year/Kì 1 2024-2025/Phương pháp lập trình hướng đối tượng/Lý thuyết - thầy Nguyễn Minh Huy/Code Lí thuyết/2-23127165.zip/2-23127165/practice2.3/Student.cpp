#include "Student.h"

Student::Student() {
    this->name = "";
    this->lit = 0;
    this->math = 0;
}

Student::Student(string name, float lit, float math) {
    this->name = name;
    this->lit = lit;
    this->math = math;
}

void Student::input() {
    cout << "- Enter name: ";
    getline(cin, this->name);
    cout << "- Enter literature score: ";
    while (!(cin >> this->lit) || this->lit < 0 || this->lit > 10) {
        // if the input is not a float number or the score is not in the range from 0 to 10, we clear the input buffer and ask the user to enter again
        cout << "\nInvalid input! Please enter a valid score from 0 to 10: ";
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
    }
    cout << "- Enter math score: ";
    while (!(cin >> this->math) || this->math < 0 || this->math > 10) {
        // if the input is not a float number or the score is not in the range from 0 to 10, we clear the input buffer and ask the user to enter again
        cout << "\nInvalid input! Please enter a valid score from 0 to 10: ";
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
    }
}

void Student::output() {
    cout << "- The student's name is: " << this->name << "\n";
    cout << "- The student's Literature point is: " << this->lit << "\n";
    cout << "- The student's Math score: " << this->math << "\n";
}

string Student::getName() {
    return this->name;
}

void Student::setName(string name) {
    this->name = name;
}

float Student::getLit() {
    return this->lit;
}

void Student::setLit(float lit) {
    this->lit = lit;
}

float Student::getMath() {
    return this->math;
}

void Student::setMath(float math) {
    this->math = math;
}

float Student::calculateGPA() {
    // The GPA is the average of the literature score and the math score
    return (this->lit + this->math) / 2;
}

char Student::grade() {
    float gpa = this->calculateGPA();
    if (gpa >= 9.0) return 'A';
    else if (gpa >= 7.0) return 'B';
    else if (gpa >= 5.0) return 'C';
    else return 'D';
}

