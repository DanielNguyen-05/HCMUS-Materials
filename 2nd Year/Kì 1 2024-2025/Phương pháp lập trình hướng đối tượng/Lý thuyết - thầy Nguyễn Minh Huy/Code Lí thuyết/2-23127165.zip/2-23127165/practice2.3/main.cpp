#include "Student.h"

int main() {
    // Declare variable
    Student stu;

    // Input student information
    cout << "\tENTER THE STUDENT INFORMATION:\n";
    stu.input();

    // Output the results
    cout << "\n\tTHE STUDENT INFORMATION: \n";
    stu.output();
    cout << "- The student's GPA is: " << stu.calculateGPA() << "\n";
    cout << "- The student's grade is: " << stu.grade() << "\n";

    // Input to set new name, literature score and math score
    cout << "\n\tENTER NEW INFORMATION:\n";
    cout << "- Enter new name: ";
    string newName;
    cin.ignore();
    getline(cin, newName);
    stu.setName(newName);
    cout << "- Enter new literature score: ";
    float newLit;
    while (!(cin >> newLit) || newLit < 0 || newLit > 10) {
        cout << "\nInvalid input! Please enter a valid score from 0 to 10: ";
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
    }
    stu.setLit(newLit);
    cout << "- Enter new math score: ";
    float newMath;
    while (!(cin >> newMath) || newMath < 0 || newMath > 10) {
        cout << "\nInvalid input! Please enter a valid score from 0 to 10: ";
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
    }
    stu.setMath(newMath);

    // Output the results
    cout << "\n\tUPDATE STUDENT INFORMATION: \n";
    stu.output();
    cout << "- The student's GPA is: " << stu.calculateGPA() << "\n";
    cout << "- The student's grade is: " << stu.grade() << "\n\n";

    return 0;
}