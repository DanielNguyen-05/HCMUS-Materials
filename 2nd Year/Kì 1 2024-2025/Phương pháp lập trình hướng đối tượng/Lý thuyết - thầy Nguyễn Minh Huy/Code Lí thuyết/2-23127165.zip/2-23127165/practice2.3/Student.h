#pragma once
#include <iostream>
#include <string>
using namespace std;

class Student {
    private:
        string name;
        float lit;
        float math;
    public:
        // This is the default constructor
        Student();

        // This is the parameterized constructor
        Student(string, float, float);

        // This function is used to input the name, literature score and math score of a student
        void input();

        // This function is used to output the name, literature score, math score and GPA of a student
        void output();

        // This function is used to get the name of the student
        string getName();

        // This function is used to set the name of the student
        void setName(string);

        // This function is used to get the literature score of the student
        float getLit();

        // This function is used to set the literature score of the student
        void setLit(float);

        // This function is used to get the math score of the student
        float getMath();

        // This function is used to set the math score of the student
        void setMath(float);

        // This function is used to calculate the GPA of the student
        float calculateGPA();

        // This function is used to return the grade of the student
        char grade();
};