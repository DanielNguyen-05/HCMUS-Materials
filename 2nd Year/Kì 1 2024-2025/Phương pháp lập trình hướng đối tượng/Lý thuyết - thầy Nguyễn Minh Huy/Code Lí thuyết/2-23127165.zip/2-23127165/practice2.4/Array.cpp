#include "Array.h"

void Array::input() {
    cout << "- Enter size of array: ";
    while (!(cin >> this->size) || this->size <= 0) {
        // if the input is not an integer or the size is less than or equal to 0, we clear the input buffer and ask the user to enter again
        cout << "\nInvalid input! Please enter a valid size: ";
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
    }
    this->arr = new int[this->size];
    for (int i = 0; i < this->size; i++) {
        cout << "- Enter elements " << i << ": ";
        while (!(cin >> this->arr[i])) {
            // if the input is not an integer, we clear the input buffer and ask the user to enter again
            cout << "\nInvalid input! Please enter a valid integer: ";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }
    }
}

void Array::output() {
    cout << "- The array is: ";
    for (int i = 0; i < this->size; i++) {
        cout << this->arr[i] << " ";
    }
    cout << "\n";
}

int Array::getSize() {
    return this->size;
}

void Array::setSize(int size) {
    this->size = size;
}

int Array::getElement(int index) {
    return this->arr[index];
}

void Array::setElement(int index, int value) {
    this->arr[index] = value;
}

int Array::find(int value) {
    // we look for the value in the array by iterating through all elements and comparing them with the given value
    for (int i = 0; i < this->size; i++) {
        if (this->arr[i] == value) return i;
    }
    return -1; // if the value is not found, we return -1
}

void Array::sort() {
    // we sort the array in ascending order using bubble sort algorithm
    for (int i = 0; i < this->size - 1; i++) {
        for (int j = i + 1; j < this->size; j++) {
            if (this->arr[i] > this->arr[j])
                swap(this->arr[i], this->arr[j]);
        }
    }
}