#pragma once
#include <iostream>
#include <algorithm>
using namespace std;

class Array {
    private:
        int *arr;
        int size;
    public: 
        // This function is used to enter array size and elements from the keyboard
        void input();

        // This function is used to print array elements to the screen
        void output();

        // This function is used to get the size of the array
        int getSize();

        // This function is used to set the size of the array
        void setSize(int);

        // This function is used to get the element at a specific index
        int getElement(int);

        // This function is used to set the element at a specific index
        void setElement(int, int);

        // This function is used to look for an element and return found index (-1 if not found)
        int find(int);

        // This function is used to sort the array in ascending order
        void sort();
};