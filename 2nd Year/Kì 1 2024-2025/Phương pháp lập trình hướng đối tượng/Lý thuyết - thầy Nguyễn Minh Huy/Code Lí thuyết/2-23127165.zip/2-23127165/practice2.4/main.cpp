#include "Array.h"

int main() {
    // Declare variable
    Array arr;

    // Input array size and elements
    cout << "\tENTER THE ARRAY INFORMATION:\n";
    arr.input();

    // Output the results
    cout << "\n\tTHE ARRAY INFORMATION: \n";
    arr.output();
    cout << "- The size of the array is: " << arr.getSize() << "\n";

    // Input to set new size and elements
    cout << "\n\tUPDATE ARRAY INFORMATION:\n";
    arr.input();

    // Output the results
    cout << "\n\tTHE ARRAY INFORMATION: \n";
    arr.output();
    cout << "- The size of the array is: " << arr.getSize() << "\n\n";

    return 0;
}