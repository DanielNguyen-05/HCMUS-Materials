#include "Monominal.h"

int main() {
    // Declare variables
    int number;
    Monomial m1, m2;

    // Input two monomials and a float number;
    cout << "\tENTER THE FIRST MONOMINAL:\n";
    m1.input();
    cout << "\tENTER THE SECOND MONOMINAL:\n";
    m2.input();
    cout << "\tENTER THE FLOAT NUMBER WHICH WILL BE EVALUATED WITH 2 MONOMINALS:\n";
    cout << "- Enter number: ";
    cin >> number;

    // Output the results
    cout << "\n\tRESULTS: \n";
    cout << "- The first monomial is: ";
    m1.output();
    cout << "- The second monomial is: ";
    m2.output();
    cout << "- The result of evaluating the first monomial with " << number << " is: " << m1.evaluate(number) << "\n"; 
    cout << "- The result of evaluating the second monomial with " << number << " is: " << m2.evaluate(number) << "\n";
    cout << "- The derivative of the first monomial is: ";
    Monomial derivative1 = m1.derive();
    derivative1.output();
    cout << "- The derivative of the second monomial is: ";
    Monomial derivative2 = m2.derive();
    derivative2.output();
    cout << "- The product of two monomials is: ";
    Monomial product = m1.mul(m2);
    product.output();
    cout << "\n";

    return 0;
}