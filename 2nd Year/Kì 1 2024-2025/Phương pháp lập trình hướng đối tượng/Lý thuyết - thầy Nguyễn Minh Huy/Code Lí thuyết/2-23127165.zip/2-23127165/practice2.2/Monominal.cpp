#include "Monominal.h"

Monomial::Monomial() {
    this->coefficient = 0;
    this->exponent = 0;
}

Monomial::Monomial(float coef, int expo) {
    this->coefficient = coef;
    this->exponent = expo;
}

void Monomial::input() {
    cout << "- Enter coefficient: ";
    while (!(cin >> this->coefficient)) {
        // if the input is not a float number, we clear the input buffer and ask the user to enter again
        cout << "\nInvalid input! Please enter a valid float number: ";
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
    }
    cout << "- Enter exponent: ";
    while (!(cin >> this->exponent) || this->exponent < 0) {
        // if the input is not an integer or the exponent is less than 0, we clear the input buffer and ask the user to enter again
        cout << "\nInvalid input! Please enter a valid integer greater than or equal to 0: ";
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
    }
    cout << "\n";
}

void Monomial::output() {
    cout << this->coefficient << "x^" << this->exponent << "\n";
}

float Monomial::getCoef() {
    return this->coefficient;
}

void Monomial::setCoef(float coef) {
    this->coefficient = coef;
}

int Monomial::getExpo() {
    return this->exponent;
}

void Monomial::setExpo(int expo) {
    this->exponent = expo;
}

float Monomial::evaluate(float x) {
    return this->coefficient * pow(x, this->exponent);
}

Monomial Monomial::derive() {
    Monomial derivative;
    // The derivative of a monomial is the product of the exponent and the coefficient of the monomial
    derivative.coefficient = this->coefficient * this->exponent;
    // The exponent of the derivative is the exponent of the monomial minus 1
    derivative.exponent = this->exponent - 1;
    return derivative;
}

Monomial Monomial::mul(const Monomial& other) {
    Monomial product;
    // The product of two monomials is the product of their coefficients and the sum of their exponents
    product.coefficient = this->coefficient * other.coefficient;
    product.exponent = this->exponent + other.exponent;
    return product;
}





