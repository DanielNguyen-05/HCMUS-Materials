#pragma once
#include <iostream>
#include <cmath>
using namespace std;

class Monomial {
private:
    float coefficient;
    int exponent;
public:
    // This is the default constructor
    Monomial();

    // This is the parameterized constructor
    Monomial(float, int);

    // This function is used to enter monominal from the keyboard
    void input();

    // This function is used to print monomial to screen
    void output();

    // This function is used to get the coefficient of the monomial
    float getCoef();

    // This function is used to set the coefficient of the monomial
    void setCoef(float);

    // This function is used to get the exponent of the monomial
    int getExpo();

    // This function is used to set the exponent of the monomial
    void setExpo(int);

    // This function is used to return result of evaluating monominal with float number
    float evaluate(float);

    // This function is used to return the derivative the monomial
    Monomial derive();  

    // This function is used to return product of multiplying two monomials
    Monomial mul(const Monomial&);
};

