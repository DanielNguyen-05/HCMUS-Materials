#include "Fraction.h"

int main() {
    // Declare variables
    Fraction f1, f2, sum;
    
    // Input two fractions
    cout << "\tENTER THE FIRST FRACTION:\n";
    f1.input();
    cout << "\tENTER THE SECOND FRACTION:\n";
    f2.input();

    // Output the results
    cout << "\n\tRESULTS: \n";
    cout << "- The first fraction is: ";
    f1.output();
    cout << "- The second fraction is: ";
    f2.output();
    cout << "- The reduction of the first fraction is: ";
    f1.reduce().output();
    cout << "- The reduction of the second fraction is: ";
    f2.reduce().output();
    cout << "- The inversion of the first fraction is: ";
    f1.inverse().output();
    cout << "- The inversion of the second fraction is: ";
    f2.inverse().output();
    cout << "- The sum of two fractions is: ";
    sum = f1.add(f2);
    sum.output();
    if (f1.compare(f2) == 1) cout << "=> The first fraction is greater than the second fraction\n\n";
    else if (f1.compare(f2) == -1) cout << "=> The first fraction is less than the second fraction\n\n";
    else cout << "=> The first fraction is equal to the second fraction\n\n";

    return 0;
}