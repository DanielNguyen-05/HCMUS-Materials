#include "Fraction.h"

Fraction::Fraction() {
    this->numerator = 0;
    this->denominator = 1;
}

Fraction::Fraction(int num, int den) {
    this->numerator = num;
    this->denominator = den;
}

void Fraction::input() {
    cout << "- Enter numerator: ";
    while (!(cin >> this->numerator)) {
        // if the input is not an integer, we clear the input buffer and ask the user to enter again
        cout << "\nInvalid input! Please enter a valid integer: ";
        cin.clear(); 
        cin.ignore(numeric_limits<streamsize>::max(), '\n'); 
    }
    cout << "- Enter denominator: ";
    while (!(cin >> this->denominator) || this->denominator == 0) {
        if (this->denominator == 0) {
            // if the denominator is zero, we clear the input buffer and ask the user to enter again
            cout << "\nDenominator cannot be zero! Enter again: ";
        } else {
            // if the input is not an integer, we clear the input buffer and ask the user to enter again
            cout << "\nInvalid input! Please enter a valid integer: ";
        }
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n'); 
    }
}

void Fraction::output() {
    if (this->denominator == 1) cout << this->numerator << "\n";
    else if (this->numerator == 0) cout << this->numerator << "\n";
    else cout << this->numerator << "/" << this->denominator << "\n";
}

int Fraction::getNum() {
    return this->numerator;
}

void Fraction::setNum(int num) {
    this->numerator = num;
}

int Fraction::getDenom() {
    return this->denominator;
}

void Fraction::setDenom(int denom) {
    this->denominator = denom;
}

Fraction Fraction::reduce() {
    // we calculate the greatest common divisor of the numerator and the denominator and divide both by it
    int gcd = this->gcd(this->numerator, this->denominator);
    this->numerator /= gcd;
    this->denominator /= gcd;
    if (this->denominator < 0) {
        this->numerator *= -1;
        this->denominator *= -1;
    }
    return *this;
}

Fraction Fraction::inverse() {
    if (this->numerator == 0) {
        // throw an exception if the numerator is zero
        throw invalid_argument("Numerator cannot be zero when inverting a fraction!!!");
    }
    Fraction result = Fraction{this->denominator, this->numerator};
    result.reduce();
    return result;
}

Fraction Fraction::add(Fraction other) {
    int num = this->numerator * other.denominator + other.numerator * this->denominator;
    int denom = this->denominator * other.denominator;
    Fraction result{num, denom};
    result.reduce();
    return result;
}

int Fraction::compare(Fraction other) {
    // we convert the fractions to double to compare them
    double frac1 = (double)this->numerator / this->denominator;
    double frac2 = (double)other.numerator / other.denominator;
    return frac1 == frac2 ? 0 : frac1 > frac2 ? 1 : -1;
}

int Fraction::gcd(int a, int b) {
    return b == 0 ? a : gcd(b, a % b);
}

