#pragma once
#include <iostream>
using namespace std;

class Fraction {
    private:
        int numerator;
        int denominator;
    public:
        // This is the default constructor
        Fraction();

        // This is the parameterized constructor
        Fraction(int, int);

        // This function is used to enter fraction from keyboard
        void input();

        // This function is used to print fraction to screen
        void output();

        // This function is used to get the numerator of the fraction
        int getNum();

        // This function is used to set the numerator of the fraction
        void setNum(int);

        // This function is used to get the denominator of the fraction
        int getDenom();

        // This function is used to set the denominator of the fraction
        void setDenom(int);

        // This function is used to return the reduction of fraction
        Fraction reduce();

        // This function is used to return the inversion the fraction
        Fraction inverse();

        // This function is used to return the sum of two fractions
        Fraction add(Fraction);

        // This function is used to return the comparison result of two fractions
        int compare(Fraction);

        // This function is used to calculate the greatest common divisor of two numbers
        int gcd(int, int);
};