#include <iostream>
#include <stdexcept>
#include <limits>
using namespace std;

// this is the structure of a fraction with a numerator and a denominator
struct Fraction {
    int numerator;
    int denominator;

    Fraction(int num = 0, int denom = 1) : numerator(num), denominator(denom) {}

    // Function to convert fraction to a double for comparison
    double value() const {
        return static_cast<double>(numerator) / denominator;
    }
};

// Function to enter an array of Fraction objects from the user
void input(Fraction* &arr, int size);

// Function to sort an array of Fraction objects using Bubble Sort
void sort(Fraction* arr, int size, bool (*compare)(const Fraction&, const Fraction&));

// Sort in ascending order
bool ascendingSort(const Fraction& a, const Fraction& b);

// Sort in descending order
bool descendingSort(const Fraction& a, const Fraction& b);

// Function to output an array of Fraction objects
void output(Fraction* arr, int size);

// Function to deallocate memory for an array of Fraction objects
void deallocateArray(Fraction* arr);
