#include "headerFile.h"

void input(Fraction* &arr, int size) {
    arr = new Fraction[size];
    for (int i = 0; i < size; ++i) {
        cout << "- Enter numerator " << i + 1 << ": ";
        // Loop until a valid integer is entered for the numerator
        while (!(cin >> arr[i].numerator)) {
            cout << "=> Invalid input! Please enter a valid integer: ";
            cin.clear(); // Clear the error state
            cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Ignore the rest of the input line
        }

        cout << "- Enter denominator " << i + 1 << ": ";
        // Loop until a valid integer is entered for the denominator and it is not zero
        while (!(cin >> arr[i].denominator) || arr[i].denominator == 0) {
            if (arr[i].denominator == 0) {
                cout << "=> Denominator cannot be zero! Enter again: ";
            } else {
                cout << "=> Invalid input! Please enter a valid integer: ";
            }
            cin.clear(); // Clear the error state
            cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Ignore the rest of the input line
        }
    }
}

bool ascendingSort(const Fraction& a, const Fraction& b) {
    return a.value() <= b.value();
}

bool descendingSort(const Fraction& a, const Fraction& b) {
    return a.value() >= b.value();
}

void output(Fraction* arr, int size) {
    for (int i = 0; i < size; ++i) {
        cout << arr[i].numerator << "/" << arr[i].denominator << " ";
    }
}

void deallocateArray(Fraction* arr) {
    delete[] arr;
}
