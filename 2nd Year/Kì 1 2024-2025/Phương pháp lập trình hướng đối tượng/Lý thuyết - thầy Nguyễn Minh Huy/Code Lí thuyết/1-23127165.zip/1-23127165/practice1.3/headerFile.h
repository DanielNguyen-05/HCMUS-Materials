#include <iostream>
#include <stdexcept>
#include <limits>
using namespace std;

// this is the structure of a fraction with a numerator and a denominator
struct Fraction {
    int numerator;
    int denominator;

    // Function to convert fraction to a double for comparison
    double value() const {
        return static_cast<double>(numerator) / denominator;
    }
};

// Function to enter an array of Fraction objects from the user
void input(Fraction* &arr, int size);

// Function to compare two Fraction objects in ascending order
bool ascendingSort(const Fraction& a, const Fraction& b);

// Function to compare two Fraction objects in descending order
bool descendingSort(const Fraction& a, const Fraction& b);

// Function to output an array of Fraction objects
void output(Fraction* arr, int size);

// Function to deallocate memory for an array of Fraction objects
void deallocateArray(Fraction* arr);

// Function template to swap two values
template <typename T>
void sort(T* arr, int size, bool (*compare)(const T&, const T&)) {
    for (int i = 0; i < size - 1; ++i) {
        for (int j = 0; j < size - i - 1; ++j) {
            // Use the compare function to determine the order
            if (compare(arr[j + 1], arr[j])) {
                swap(arr[j], arr[j + 1]);
            }
        }
    }
}
