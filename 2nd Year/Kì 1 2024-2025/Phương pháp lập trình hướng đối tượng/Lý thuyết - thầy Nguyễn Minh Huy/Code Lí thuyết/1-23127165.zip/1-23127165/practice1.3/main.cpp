#include "headerFile.h"

int main() {
    cout << "\t INPUT:\n";
    int size;
    cout << "Enter the number of fractions: ";
    cin >> size;

    // Enter an array of fractions
    Fraction* arr;
    input(arr, size);

    cout << "\n\t RESULTS:";
    // Output the array of fractions after being sorted in ascending order
    cout << "\n- Sorting in ascending order: ";
    sort(arr, size, ascendingSort);
    output(arr, size);

    // Output the array of fractions after being sorted in descending order
    cout << "\n- Sorting in descending order: ";
    sort(arr, size, descendingSort);
    output(arr, size);
    cout << "\n\n";
    
    deallocateArray(arr); // Deallocate memory for the array
    return 0;
}