#include "headerFile.h"

void input(Fraction& frac) {
    cout << "- Enter numerator: ";
    // Loop until a valid integer is entered for the numerator
    while (!(cin >> frac.numerator)) {
        cout << "=> Invalid input! Please enter a valid integer: ";
        cin.clear(); // Clear the error state
        cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Ignore the rest of the input line
    }

    cout << "- Enter denominator: ";
    // Loop until a valid integer is entered for the denominator and it is not zero
    while (!(cin >> frac.denominator) || frac.denominator == 0) {
        if (frac.denominator == 0) {
            cout << "=> Denominator cannot be zero! Enter again: ";
        } else {
            cout << "=> Invalid input! Please enter a valid integer: ";
        }
        cin.clear(); // Clear the error state
        cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Ignore the rest of the input line
    }

    // Reduce the fraction to its simplest form
    reduce(frac);
}

void output(const Fraction& frac) {
    if (frac.denominator == 1) {
        cout << frac.numerator << "\n";
    } else {
        cout << frac.numerator << "/" << frac.denominator << "\n";
    }
}

// Function to reduce a fraction to its simplest form
Fraction reduce(Fraction& frac) {
    // Calculate the greatest common divisor (GCD) of the numerator and denominator
    int divisor = gcd(frac.numerator, frac.denominator);
    
    // Divide both the numerator and denominator by the GCD to simplify the fraction
    frac.numerator /= divisor;
    frac.denominator /= divisor;
    
    // Ensure the denominator is positive
    if (frac.denominator < 0) {
        frac.numerator = -frac.numerator;
        frac.denominator = -frac.denominator;
    }
    
    return frac;
}

Fraction inverse(const Fraction& frac) {
    if (frac.numerator == 0) {
        // Cannot invert a fraction with a numerator of zero
        throw runtime_error("!!! Cannot invert this fraction due to a numerator of zero !!!");
    }
    return Fraction{frac.denominator, frac.numerator};
}

Fraction add(const Fraction& frac1, const Fraction& frac2) {
    int num = frac1.numerator * frac2.denominator + frac2.numerator * frac1.denominator;
    int denom = frac1.denominator * frac2.denominator;
    Fraction result{num, denom};
    result = reduce(result);
    return result;
}

int compare(const Fraction& frac1, const Fraction& frac2) {
    int lhs = frac1.numerator * frac2.denominator;
    int rhs = frac2.numerator * frac1.denominator;
    if (lhs == rhs) return 0;
    return (lhs < rhs) ? -1 : 1;
}

int gcd(int a, int b) {
    while (b != 0) {
        int temp = b;
        b = a % b;
        a = temp;
    }
    return a;
}
