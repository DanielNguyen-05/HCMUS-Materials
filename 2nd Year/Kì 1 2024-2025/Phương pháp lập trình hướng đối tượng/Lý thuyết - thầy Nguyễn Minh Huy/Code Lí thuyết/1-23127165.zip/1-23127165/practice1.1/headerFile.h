#include <iostream>
#include <stdexcept>
#include <limits>
using namespace std;

// this is the structure of a fraction with a numerator and a denominator
struct Fraction {
    int numerator;
    int denominator;

    // Function to convert fraction to a double for comparison
    double value() const {
        return static_cast<double>(numerator) / denominator;
    }
};

// this function is used to enter fraction from keyboard
void input(Fraction& frac);

// this function is used to print fraction to screen.
void output(const Fraction& frac);

// this function is used to return the reduction of fraction
Fraction reduce(Fraction& frac);

// this function inverts a fraction
Fraction inverse(const Fraction& frac);

// this function adds two fractions
Fraction add(const Fraction& frac1, const Fraction& frac2);

// this function compares two fractions
int compare(const Fraction& frac1, const Fraction& frac2);

// this function calculates the greatest common divisor of two numbers
int gcd(int a, int b);