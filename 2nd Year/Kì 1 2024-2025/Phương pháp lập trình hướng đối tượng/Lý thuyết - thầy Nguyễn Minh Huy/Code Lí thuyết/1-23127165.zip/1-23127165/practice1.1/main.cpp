#include "headerFile.h"

int main() {
    Fraction frac1, frac2;

    // Enter two fractions
    cout << "\t ENTER THE FIRST FRACTION:\n";
    input(frac1);
    
    cout << "\t ENTER THE SECOND FRACTION:\n";
    input(frac2);

    cout << "\n\t RESULT:\n";
    // Output the fractions
    cout << "- First fraction after being reduced: ";
    output(frac1);
    
    cout << "- Second fraction after being reduced: ";
    output(frac2);

    // Sum of two fractions
    Fraction sum = add(frac1, frac2);
    cout << "- Sum of two fractions: ";
    output(sum);


    // Inverse of the first fraction
    try {
        Fraction inverseFrac1 = inverse(frac1);
        cout << "- Inverse of the first fraction: ";
        output(inverseFrac1);
    } catch (const exception& e) {
        cerr << e.what() << "\n";
    }

    // Inverse of the second fraction
    try {
        Fraction inverseFrac2 = inverse(frac2);
        cout << "- Inverse of the second fraction: ";
        output(inverseFrac2);
    } catch (const exception& e) {
        cerr << e.what() << "\n";
    }

    // Comparison of two fractions
    int comparison = compare(frac1, frac2);
    if (comparison == 0) {
        cout << "=> The fractions are equal.\n\n";
    } else if (comparison == 1) {
        cout << "=> The first fraction is greater than the second.\n\n";
    } else {
        cout << "=> The first fraction is less than the second.\n\n";
    }

    return 0;
}
