#pragma once
#include <iostream>
#include <sstream>
#include <stdexcept>
using namespace std;

class Polynomial {
private:
    int degree;
    double* coefficients; // index is exponent (x^index) and the value is the coefficient

public:
    /***                                CONSTRUCTORS & DESTRUCTOR                             ***/
    Polynomial(); // default constructor with degree = 0;
    Polynomial(int deg, double* coef); // constructor with degree and coefficients
    Polynomial(const Polynomial& p); // copy constructor
    ~Polynomial(); // destructor

    /***                                GETTER & SETTER                             ***/
    int getDegree() const; // return the degree of the polynomial
    double getCoefficient(int deg) const; // get coefficient at a degree
    void setDegree(int deg); // set the degree of the polynomial
    void setCoefficient(int deg, double coef); // set coefficient at a degree

    /***                                ARITHMETICS                             ***/
    Polynomial operator + (const Polynomial& p); // add two polynomials
    Polynomial operator - (const Polynomial& p); // subtract two polynomials
    Polynomial operator * (const Polynomial& p); // multiply two polynomials
    Polynomial& operator = (const Polynomial& p); // assignment operator

    /***                                COMPARISONS                             ***/
    bool operator > (const Polynomial& p);
    bool operator < (const Polynomial& p);
    bool operator == (const Polynomial& p);
    bool operator >= (const Polynomial& p);
    bool operator <= (const Polynomial& p);
    bool operator != (const Polynomial& p);

    /***                                DERIVATIVE & ANTI-DERIVATIVE                             ***/
    Polynomial operator ! (); //
    Polynomial operator ~ (); // 

    /***                                INPUT & OUTPUT                            ***/
    friend ostream& operator << (ostream& os, const Polynomial& p); // output the polynomial
    friend istream& operator >> (istream& is, Polynomial& p); // input the polynomial

    double* initialize(int deg); // initialize the polynomial with degree and coefficients
};