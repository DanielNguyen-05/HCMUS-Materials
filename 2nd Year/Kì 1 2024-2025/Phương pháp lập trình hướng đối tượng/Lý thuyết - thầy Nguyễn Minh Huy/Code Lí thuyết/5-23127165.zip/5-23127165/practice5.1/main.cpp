#include "Polynomial.h"

int main() {
    /***            Create some polynomials using the input operator            ***/
    Polynomial p1, p2;
    cout << "\n\t ENTER THE FIRST POLYNOMIAL:\n";
    cin >> p1;
    cout << "\n\t ENTER THE SECOND POLYNOMIAL:\n";
    cin >> p2;

    cout << "\n\t POLYNOMIAL RESULTS:\n";
    cout << "=> First Polynomial: " << p1 << "\n";
    cout << "=> Second Polynomial: " << p2 << "\n";

    // Perform arithmetic operations
    Polynomial sum = p1 + p2;
    Polynomial diff = p1 - p2;
    Polynomial product = p1 * p2;

    cout << "=> Sum (p1 + p2): " << sum << "\n";
    cout << "=> Difference (p1 - p2): " << diff << "\n";
    cout << "=> Product (p1 * p2): " << product << "\n";

    // Perform comparison operations
    cout << "=> p1 > p2: " << (p1 > p2) << "\n";
    cout << "=> p1 < p2: " << (p1 < p2) << "\n";
    cout << "=> p1 == p2: " << (p1 == p2) << "\n";
    cout << "=> p1 >= p2: " << (p1 >= p2) << "\n";
    cout << "=> p1 <= p2: " << (p1 <= p2) << "\n";
    cout << "=> p1 != p2: " << (p1 != p2) << "\n";

    // Calculate derivative and integral
    Polynomial derivative1 = !p1;
    Polynomial derivative2 = !p2;
    Polynomial integral1 = ~p1;
    Polynomial integral2 = ~p2;


    cout << "=> Derivative of p1: " << derivative1 << "\n";
    cout << "=> Derivative of p2: " << derivative2 << "\n";
    cout << "=> Indefinite Integral of p1: " << integral1 << "\n";
    cout << "=> Indefinite Integral of p2: " << integral2 << "\n\n";

    return 0;
}
