#include "Polynomial.h"

double* Polynomial::initialize(int deg) {
    try {
        return new double[deg]();
    }
    catch (bad_alloc& e) {
        return NULL;
    }
}

Polynomial::Polynomial() {
    this->degree = 0;
    this->coefficients = new double[1];
    this->coefficients[0] = 0;
}

Polynomial::Polynomial(int deg, double* coef) : coefficients(initialize(deg + 1)), degree(deg + 1) {
    if (!coef || !coefficients) {
        return;
    }
    copy(coef, coef + deg + 1, coefficients);
}

Polynomial::Polynomial(const Polynomial& p) : degree(p.degree) {
    coefficients = initialize(p.degree + 1);
    copy(p.coefficients, p.coefficients + degree + 1, coefficients);
}

int Polynomial::getDegree() const {
    return this->degree;
}

double Polynomial::getCoefficient(int deg) const {
    if (deg < 0 || deg > this->degree) throw invalid_argument("Invalid degree");
    return this->coefficients[deg];
}

void Polynomial::setDegree(int deg) {
    if (deg < 0) throw invalid_argument("Invalid degree");
    if (deg == this->degree) return;
    else if (deg < this->degree) {
        double* tmp = initialize(deg + 1);
        if (!tmp) throw invalid_argument("Failed to initialize Polynomial");
        copy(this->coefficients, this->coefficients + deg + 1, tmp);
        delete[] this->coefficients;
        this->coefficients = tmp;
        this->degree = deg;
    }
    else {
        double* tmp = initialize(deg + 1);
        if (!tmp) throw invalid_argument("Failed to initialize Polynomial");
        copy(this->coefficients, this->coefficients + this->degree, tmp);
        delete[] this->coefficients;
        this->coefficients = tmp;
    }
}

void Polynomial::setCoefficient(int deg, double coef) {
    if (deg < 0 || deg > this->degree) throw invalid_argument("Invalid degree");
    this->coefficients[deg] = coef;
}

Polynomial Polynomial::operator + (const Polynomial& p) {
    int maxDegree = max(this->degree, p.degree);
    double* newCoefficients = initialize(maxDegree + 1);
    for (int i = 0; i <= this->degree; ++i) {
        newCoefficients[i] = this->coefficients[i];
    }
    for (int i = 0; i <= p.degree; ++i) {
        newCoefficients[i] += p.coefficients[i];
    }
    return Polynomial(maxDegree, newCoefficients);
}

Polynomial Polynomial::operator - (const Polynomial& p) {
    int maxDegree = max(this->degree, p.degree);
    double* newCoefficients = initialize(maxDegree + 1);
    for (int i = 0; i <= this->degree; ++i) {
        newCoefficients[i] = this->coefficients[i];
    }
    for (int i = 0; i <= p.degree; ++i) {
        newCoefficients[i] -= p.coefficients[i];
    }
    return Polynomial(maxDegree, newCoefficients);
}

Polynomial Polynomial::operator * (const Polynomial& p) {
    Polynomial result(this->degree + p.degree, initialize(this->degree + p.degree + 1));
    for (int i = 0; i < this->degree + 1; ++i) {
        for (int j = 0; j < p.degree + 1; ++j) {
            result.coefficients[i + j] += this->coefficients[i] * p.coefficients[j];
        }
    }
    return result;
}

Polynomial& Polynomial::operator = (const Polynomial& p) {
    if (this != &p) {
        double* tmp = initialize(p.degree + 1);
        if (!tmp) {
            throw invalid_argument("Failed to initialize Polynomial");
        }
        copy(p.coefficients, p.coefficients + p.degree + 1, tmp);
        delete[] this->coefficients;
        this->coefficients = tmp;
        this->degree = p.degree;
    }
    return *this;
}

bool Polynomial::operator > (const Polynomial& p) {
    if (this->degree > p.degree) {
        return true;
    }
    else if (this->degree < p.degree) {
        return false;
    }
    for (int i = this->degree; i >= 0; --i) {
        if (this->coefficients[i] > p.coefficients[i]) {
            return true;
        }
        else if (this->coefficients[i] < p.coefficients[i]) {
            return false;
        }
    }
    return false;
}

bool Polynomial::operator < (const Polynomial& p) {
    if (this->degree < p.degree) {
        return true;
    }
    else if (this->degree > p.degree) {
        return false;
    }
    for (int i = this->degree; i >= 0; --i) {
        if (this->coefficients[i] < p.coefficients[i]) {
            return true;
        }
        else if (this->coefficients[i] > p.coefficients[i]) {
            return false;
        }
    }
    return false;
}

bool Polynomial::operator == (const Polynomial& p) {
    if (this->degree != p.degree) {
        return false;
    }
    for (int i = 0; i <= this->degree; ++i) {
        if (this->coefficients[i] != p.coefficients[i]) {
            return false;
        }
    }
    return true;
}

bool Polynomial::operator >= (const Polynomial& p) {
    return !(*this < p);
}


bool Polynomial::operator <= (const Polynomial& p) {
    return !(*this > p);
}

bool Polynomial::operator != (const Polynomial& p) {
    return !(*this == p);
}

Polynomial Polynomial::operator ! () {
    if (this->degree == 0) {
        return Polynomial();
    }
    Polynomial result(this->degree - 1, initialize(this->degree));
    for (int i = 1; i <= this->degree; ++i) {
        result.coefficients[i - 1] = this->coefficients[i] * i;
    }
    return result;
}

Polynomial Polynomial::operator ~ () {
    Polynomial result(this->degree + 1, initialize(this->degree + 2));
    result.coefficients[0] = 0;
    for (int i = 0; i <= this->degree; ++i) {
        result.coefficients[i + 1] = this->coefficients[i] / (i + 1);
    }

    return result;
}

ostream& operator << (ostream& os, const Polynomial& p) {
    bool first = true;
    for (int i = p.degree; i >= 0; --i) {
        if (p.coefficients[i] == 0) continue;
        if (!first) os << " + ";
        if (i == 0) {
            os << p.coefficients[i];
        }
        else if (i == 1) {
            os << p.coefficients[i] << "x";
        }
        else {
            os << p.coefficients[i] << "x^" << i;
        }
        first = false;
    }
    return os;
}

istream& operator >> (istream& is, Polynomial& p) {
    int deg;
    cout << "- Enter the degree of the polynomial: ";
    is >> deg;
    if (deg < 0) {
        throw invalid_argument("Degree must be non-negative");
    }
    double* coef = p.initialize(deg + 1);
    if (!coef) {
        throw bad_alloc();
    }
    cout << "- Enter the coefficients of the polynomial: \n";
    for (int i = 0; i < deg + 1; ++i) {
        cout << "- Coefficient of x^" << i << ": ";
        is >> coef[i];
    }
    delete[] p.coefficients;
    p.coefficients = coef;
    p.degree = deg;
    return is;
}

Polynomial::~Polynomial() {
    delete[] this->coefficients;
    this->coefficients = NULL;
}