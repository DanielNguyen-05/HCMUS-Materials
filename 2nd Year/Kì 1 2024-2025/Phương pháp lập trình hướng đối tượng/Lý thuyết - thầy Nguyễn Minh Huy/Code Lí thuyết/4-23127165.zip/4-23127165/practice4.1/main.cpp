#include "Fraction.h"

int main() {
    // Constructors
    Fraction frac1(3, 4);    // 3/4
    Fraction frac2(2, 5);    // 2/5
    Fraction frac3 = frac1;  // Copy constructor

    cout << "\n=== Initial Fractions ===\n";
    cout << "frac1: " << frac1 << "\n";
    cout << "frac2: " << frac2 << "\n";
    cout << "frac3 (copy of frac1): " << frac3 << "\n";

    // Arithmetic
    cout << "\n=== Arithmetic Operations ===\n";
    Fraction sum = frac1 + frac2;
    cout << "Sum (frac1 + frac2): " << sum << "\n";

    Fraction product = frac1 * frac2;
    cout << "Product (frac1 * frac2): " << product << "\n";

    Fraction difference = frac1 - frac2;
    cout << "Difference (frac1 - frac2): " << difference << "\n";

    // Comparison
    cout << "\n=== Comparisons ===\n";
    cout << "frac1 > frac2? " << (frac1 > frac2 ? "true" : "false") << "\n";
    cout << "frac1 < frac2? " << (frac1 < frac2 ? "true" : "false") << "\n";
    cout << "frac1 == frac3? " << (frac1 == frac3 ? "true" : "false") << "\n";
    cout << "frac1 != frac2? " << (frac1 != frac2 ? "true" : "false") << "\n";
    cout << "frac1 >= frac3? " << (frac1 >= frac3 ? "true" : "false") << "\n";
    cout << "frac2 <= frac1? " << (frac2 <= frac1 ? "true" : "false") << "\n";

    // Assignment
    cout << "\n=== Assignment Operations ===\n";
    Fraction frac4;
    frac4 = frac1;
    cout << "frac4 after assignment (frac4 = frac1): " << frac4 << "\n";

    frac4 += frac2;
    cout << "frac4 after += frac2: " << frac4 << "\n";

    frac4 *= frac1;
    cout << "frac4 after *= frac1: " << frac4 << "\n";

    frac4 -= frac2;
    cout << "frac4 after -= frac2: " << frac4 << "\n";

    // Increment/Decrement
    cout << "\n=== Increment/Decrement ===\n";
    cout << "frac1 before increment: " << frac1 << "\n";
    ++frac1;
    cout << "frac1 after prefix increment: " << frac1 << "\n";
    frac1++;
    cout << "frac1 after postfix increment: " << frac1 << "\n";

    --frac1;
    cout << "frac1 after prefix decrement: " << frac1 << "\n";
    frac1--;
    cout << "frac1 after postfix decrement: " << frac1 << "\n";

    // Type Conversion
    cout << "\n=== Type Conversion ===\n";
    float asFloat = static_cast<float>(frac1);
    int asInt = static_cast<int>(frac1);
    cout << "frac1 as float: " << asFloat << "\n";
    cout << "frac1 as int: " << asInt << "\n";

    // Input and Output
    cout << "\n=== Input and Output ===\n";
    Fraction fracInput;
    cout << "Enter a fraction in the format 'numerator/denominator': \n";
    cin >> fracInput;
    cout << "You entered: " << fracInput << "\n";

    return 0;
}
