#include "Fraction.h"

// Constructors and destructor
Fraction::Fraction() {
    this->numerator = 0;
    this->denominator = 1;
}

Fraction::Fraction(int numerator, int denominator) {
    if (denominator == 0) {
        __throw_invalid_argument("Denominator cannot be zero!!!");
    }
    if (denominator < 0) {
        numerator = -numerator;
        denominator = -denominator;
    }
    this->numerator = numerator;
    this->denominator = denominator;
}

Fraction::Fraction(const Fraction& fraction) {
    this->numerator = fraction.numerator;
    this->denominator = fraction.denominator;
}

Fraction::~Fraction() {
    // cout << "Fraction object is destroyed\n";
}

// Arithmetic
Fraction Fraction::operator + (const Fraction& fraction) {
    int num = this->numerator * fraction.denominator + fraction.numerator * this->denominator;
    int den = this->denominator * fraction.denominator;
    return Fraction(num, den);
}

Fraction Fraction::operator * (const Fraction& fraction) {
    int num = this->numerator * fraction.numerator;
    int den = this->denominator * fraction.denominator;
    return Fraction(num, den);
}

Fraction Fraction::operator - (const Fraction& fraction) {
    int num = this->numerator * fraction.denominator - fraction.numerator * this->denominator;
    int den = this->denominator * fraction.denominator;
    return Fraction(num, den);
}

// Comparison
bool Fraction::operator > (const Fraction& fraction) {
    double frac1 = (double)this->numerator / this->denominator;
    double frac2 = (double)fraction.numerator / fraction.denominator;
    return frac1 > frac2;
}

bool Fraction::operator < (const Fraction& fraction) {
    double frac1 = (double)this->numerator / this->denominator;
    double frac2 = (double)fraction.numerator / fraction.denominator;
    return frac1 < frac2;
}

bool Fraction::operator == (const Fraction& fraction) {
    double frac1 = (double)this->numerator / this->denominator;
    double frac2 = (double)fraction.numerator / fraction.denominator;
    return frac1 == frac2;
}

bool Fraction::operator >= (const Fraction& fraction) {
    double frac1 = (double)this->numerator / this->denominator;
    double frac2 = (double)fraction.numerator / fraction.denominator;
    return frac1 >= frac2;
}

bool Fraction::operator <= (const Fraction& fraction) {
    double frac1 = (double)this->numerator / this->denominator;
    double frac2 = (double)fraction.numerator / fraction.denominator;
    return frac1 <= frac2;
}

bool Fraction::operator != (const Fraction& fraction) {
    double frac1 = (double)this->numerator / this->denominator;
    double frac2 = (double)fraction.numerator / fraction.denominator;
    return frac1 != frac2;
}

// Assignment
Fraction& Fraction::operator = (const Fraction& fraction) {
    this->numerator = fraction.numerator;
    this->denominator = fraction.denominator;
    return *this;
}

Fraction& Fraction::operator += (const Fraction& fraction) {
    *this = *this + fraction;
    return *this;
}

Fraction& Fraction::operator *= (const Fraction& fraction) {
    *this = *this * fraction;
    return *this;
}

Fraction& Fraction::operator -= (const Fraction& fraction) {
    *this = *this - fraction;
    return *this;
}

// Inc/Dec
Fraction& Fraction::operator ++ () {
    *this += Fraction(1, 1);
    return *this;
} // ++frac;

Fraction Fraction::operator ++ (int) {
    Fraction tmp = *this;
    *this += Fraction(1, 1);
    return tmp;
} // frac++;

Fraction& Fraction::operator -- () {
    *this -= Fraction(1, 1);
    return *this;
} // --frac

Fraction Fraction::operator -- (int) {
    Fraction tmp = *this;
    *this -= Fraction(1, 1);
    return tmp;
} // frac--;

Fraction::operator float() const {
    return static_cast<float>(this->numerator) / this->denominator;
}

Fraction::operator int() const {
    return this->numerator / this->denominator;
}

ostream& operator << (ostream& os, const Fraction& fraction) {
    os << fraction.numerator << "/" << fraction.denominator;
    return os;
}

istream& operator >> (istream& is, Fraction& fraction) {
    std::cout << "Enter numerator: ";
    is >> fraction.numerator;
    std::cout << "Enter denominator: ";
    is >> fraction.denominator;

    if (fraction.denominator == 0) {
        throw std::invalid_argument("Denominator cannot be zero!!!");
    }
    return is;
}