#pragma once
#include <iostream>
#include <sstream>
#include <stdexcept>
using namespace std;

class Fraction {
private:
    int numerator;
    int denominator;
public:
    // Constructors and destructor
    Fraction();
    Fraction(int numerator, int denominator);
    Fraction(const Fraction& fraction);
    ~Fraction();

    // Arithmetic
    Fraction operator + (const Fraction& fraction);
    Fraction operator * (const Fraction& fraction);
    Fraction operator - (const Fraction& fraction);

    // Comparison
    bool operator > (const Fraction& fraction);
    bool operator < (const Fraction& fraction);
    bool operator == (const Fraction& fraction);
    bool operator >= (const Fraction& fraction);
    bool operator <= (const Fraction& fraction);
    bool operator != (const Fraction& fraction);

    // Assignment
    Fraction& operator = (const Fraction& fraction);
    Fraction& operator += (const Fraction& fraction);
    Fraction& operator *= (const Fraction& fraction);
    Fraction& operator -= (const Fraction& fraction);

    // Inc/Dec
    Fraction& operator ++ (); // prefix
    Fraction operator ++ (int); // postfix
    Fraction& operator -- (); // prefix
    Fraction operator -- (int); // postfix

    // Type cast
    operator float() const;
    operator int() const;

    // Input/Output
    friend ostream& operator << (ostream& os, const Fraction& fraction);
    friend istream& operator >> (istream& is, Fraction& fraction);
};