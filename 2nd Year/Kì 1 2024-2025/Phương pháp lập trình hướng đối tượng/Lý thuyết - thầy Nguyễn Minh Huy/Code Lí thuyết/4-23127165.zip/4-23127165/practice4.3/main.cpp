#include "Array.hpp"

int main() {
    // Default constructor and input operator >>
    Array<int> array1;
    cin >> array1;

    // Displaying array using output operator <<
    cout << "Array1: " << array1 << "\n";

    // Using the size constructor
    Array<int> array2(5);
    cout << "Array2 (initialized with size 5): " << array2 << "\n";

    // Using assignment operator =
    array2 = array1;
    cout << "Array2 after assignment from Array1: " << array2 << "\n";

    // Using array indexer []
    array2[0] = 100;
    cout << "Array2 after changing first element: " << array2 << "\n";

    // Using type-cast to T* operator
    int* dataPointer = array2;
    cout << "Data in Array2 accessed through T* pointer: ";
    for (size_t i = 0; i < 5; ++i) {
        cout << dataPointer[i] << " ";
    }
    cout << "\n";

    return 0;
}
