#pragma once
#include <iostream>
#include <stdexcept>
#include <sstream>
#include <algorithm>
using namespace std;

template <class T>
class Array {
private:
    T* data;
    size_t size;
public:
    // Default constructor initializes an array with zero-length
    Array();

    // Constructor initializes an array with size
    Array(size_t size);

    // Constructor initializes an array with length, and all elements are set to data
    Array(const T* data, size_t size);

    // Copy constructor initializes an array with the same length and data as another array
    Array(const Array& other);

    // Destructor disposes an array without memory leaks
    ~Array();

    Array& operator = (const Array& other);

    // Overload operator [] to access elements in the array
    T& operator[](size_t index);

    // Type-cast: (T*) (to T pointer)
    operator T* () const;

    template <class U>
    friend istream& operator >> (istream& is, Array<U>& other);

    template <class U>
    friend ostream& operator << (ostream& os, const Array<U>& other);
};

template <class T>
Array<T>::Array() : size(0), data(nullptr) {}

template <class T>
Array<T>::Array(size_t size) : size(size) {
    if (size <= 0) {
        throw invalid_argument("Size must be positive.");
    }
    data = new T[size](); // Value-initialize to avoid uninitialized data
}

template <class T>
Array<T>::Array(const T* data, size_t size) : size(size) {
    if (size <= 0) {
        throw invalid_argument("Size must be positive.");
    }
    this->data = new T[size];
    for (size_t i = 0; i < size; i++) {
        this->data[i] = data[i];
    }
}

template <class T>
Array<T>::Array(const Array& other) : size(other.size) {
    data = new T[size];
    std::copy(other.data, other.data + size, data); // Use std::copy for safety
}

template <class T>
Array<T>::~Array() {
    delete[] this->data;
}

template <class T>
Array<T>& Array<T>::operator = (const Array& other) {
    if (this != &other) { // Prevent self-assignment
        delete[] data; // Clean up existing data
        this->size = other.size;
        this->data = new T[size];
        std::copy(other.data, other.data + this->size, this->data);
    }
    return *this;
}

template <class T>
T& Array<T>::operator [] (size_t index) {
    if (index >= size || index < 0) {
        throw out_of_range("Index out of range");
    }
    return data[index];
}

template <class T>
Array<T>::operator T* () const {
    return this->data;
}

template <class T>
istream& operator >> (istream& is, Array<T>& array) {
    cout << "Enter the size of the array: ";
    is >> array.size;

    if (array.size <= 0) {
        throw invalid_argument("The size of the array must be positive.");
    }

    delete[] array.data; // Delete old data if any
    array.data = new T[array.size]; // Allocate new memory for data

    cout << "Enter " << array.size << " elements:\n";
    for (size_t i = 0; i < array.size; ++i) {
        is >> array.data[i];
    }
    return is;
}

template <class T>
ostream& operator << (ostream& os, const Array<T>& array) {
    os << "[";
    for (size_t i = 0; i < array.size; ++i) {
        os << array.data[i];
        if (i < array.size - 1) {
            os << ", ";
        }
    }
    os << "]";
    return os;
}
