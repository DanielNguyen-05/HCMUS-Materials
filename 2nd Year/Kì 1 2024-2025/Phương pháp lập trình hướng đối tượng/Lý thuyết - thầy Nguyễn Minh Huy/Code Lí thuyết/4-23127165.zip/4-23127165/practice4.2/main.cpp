#include "Monomial.h"

int main() {
    // Test Input/Output
    Monomial m1, m2;
    cout << "\n=== Monomial Input/Output Test ===\n";
    cout << "Enter coefficient and exponent for m1 (e.g., '3 2' for 3x^2): \n";
    cin >> m1;
    cout << "Enter coefficient and exponent for m2: \n";
    cin >> m2;
    cout << "m1: " << m1 << "\nm2: " << m2 << "\n";

    // Test Arithmetic Operators (+ and *)
    cout << "\n=== Arithmetic Operators Test ===\n";
    try {
        Monomial sum = m1 + m2;
        cout << "Sum (m1 + m2): " << sum << "\n";
    }
    catch (const invalid_argument& e) {
        cout << "Addition error: " << e.what() << "\n";
    }

    Monomial product = m1 * m2;
    cout << "Product (m1 * m2): " << product << "\n";

    // Test Comparison Operators
    cout << "\n=== Comparison Operators Test ===\n";
    cout << "m1 == m2: " << (m1 == m2 ? "true" : "false") << "\n";
    cout << "m1 != m2: " << (m1 != m2 ? "true" : "false") << "\n";
    cout << "m1 > m2: " << (m1 > m2 ? "true" : "false") << "\n";
    cout << "m1 < m2: " << (m1 < m2 ? "true" : "false") << "\n";
    cout << "m1 >= m2: " << (m1 >= m2 ? "true" : "false") << "\n";
    cout << "m1 <= m2: " << (m1 <= m2 ? "true" : "false") << "\n";

    // Test Assignment Operators (=, +=, and *=)
    cout << "\n=== Assignment Operators Test ===\n";
    Monomial m3 = m1; // Assignment
    cout << "m3 (assigned from m1): " << m3 << "\n";

    try {
        m3 += m2;
        cout << "m3 after m3 += m2: " << m3 << "\n";
    }
    catch (const invalid_argument& e) {
        cout << "Addition assignment error: " << e.what() << "\n";
    }

    m3 *= m2;
    cout << "m3 after m3 *= m2: " << m3 << "\n";

    // Test Increment/Decrement Operators (++ and --)
    cout << "\n=== Increment/Decrement Operators Test ===\n";
    Monomial incExp = m1;
    ++incExp;
    cout << "incExp after ++incExp: " << incExp << "\n";
    incExp++;
    cout << "incExp after incExp++: " << incExp << "\n";

    Monomial decExp = m2;
    --decExp;
    cout << "decExp after --decExp: " << decExp << "\n";
    decExp--;
    cout << "decExp after decExp--: " << decExp << "\n";

    // Test Derivative Operator (!)
    cout << "\n=== Derivative Operator Test ===\n";
    Monomial derivative = !m1;
    cout << "Derivative of m1 (!m1): " << derivative << "\n";
    Monomial derivative2 = !m2;
    cout << "Derivative of m2 (!m2): " << derivative2 << "\n";

    return 0;
}
