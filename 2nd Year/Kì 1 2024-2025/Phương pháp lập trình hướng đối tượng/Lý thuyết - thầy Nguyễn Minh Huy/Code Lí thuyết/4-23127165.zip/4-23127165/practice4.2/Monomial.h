#pragma once
#include <iostream>
#include <stdexcept>
#include <sstream>
#include <cmath>
using namespace std;

class Monomial {
private:
    float coefficient;
    int exponent;
public:
    // This is the default constructor
    Monomial();

    // This is the parameterized constructor
    Monomial(float, int);

    // Constructor with another Monomial
    Monomial(const Monomial& other);

    // Arithmetic
    Monomial operator + (const Monomial& other); // same exponent
    Monomial operator * (const Monomial& other);

    // Comparison
    bool operator > (const Monomial& other);
    bool operator < (const Monomial& other);
    bool operator == (const Monomial& other);
    bool operator >= (const Monomial& other);
    bool operator <= (const Monomial& other);
    bool operator != (const Monomial& other);

    // Assignment
    Monomial& operator = (const Monomial& other);
    Monomial& operator += (const Monomial& other); // same exponent
    Monomial& operator *= (const Monomial& other);

    // Inc/Dec (add/subtract exponent)
    Monomial& operator ++ (); // prefix: ++a
    Monomial operator ++ (int); // postfix: a++
    Monomial& operator -- (); // prefix: --a
    Monomial operator -- (int); // prefix: a--

    Monomial operator ! ();  // derive

    // Input/Output
    friend istream& operator >> (istream& is, Monomial& m);
    friend ostream& operator << (ostream& os, const Monomial& m);

    // Destructor
    ~Monomial();
};

