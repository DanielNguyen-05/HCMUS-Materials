#include "Monomial.h"

Monomial::Monomial() {
    this->coefficient = 0;
    this->exponent = 0;
}

Monomial::Monomial(float coef, int expo) {
    this->coefficient = coef;
    this->exponent = expo;
}

Monomial::Monomial(const Monomial& other) {
    this->coefficient = other.coefficient;
    this->exponent = other.exponent;
}

Monomial Monomial::operator + (const Monomial& other) {
    if (this->exponent != other.exponent) {
        __throw_invalid_argument("The exponent must be the same !!!\n");
    }
    return Monomial(this->coefficient + other.coefficient, this->exponent);
}

Monomial Monomial::operator * (const Monomial& other) {
    return Monomial(this->coefficient * other.coefficient, this->exponent + other.exponent);
}

bool Monomial::operator < (const Monomial& other) {
    return (this->exponent > other.exponent) || (this->exponent == other.exponent && this->coefficient < other.coefficient);
}

bool Monomial::operator > (const Monomial& other) {
    return (*this) < other;
}

bool Monomial::operator == (const Monomial& other) {
    return (this->coefficient == other.coefficient) && (this->exponent == other.exponent);
}

bool Monomial::operator >= (const Monomial& other) {
    return (*this) > other || (*this) == other;
}

bool Monomial::operator <= (const Monomial& other) {
    return (*this) < other || (*this) == other;
}

bool Monomial::operator != (const Monomial& other) {
    return !((*this) == other);
}

Monomial& Monomial::operator = (const Monomial& other) {
    this->coefficient = other.coefficient;
    this->exponent = other.exponent;
    return *this;
}

// Same Exponent
Monomial& Monomial::operator += (const Monomial& other) {
    if (this->exponent != other.exponent) {
        __throw_invalid_argument("The exponent must be the same !!!\n");
    }
    (*this) = (*this) + other;
    return (*this);
}

Monomial& Monomial::operator *= (const Monomial& other) {
    (*this) = (*this) * other;
    return (*this);
}

Monomial& Monomial::operator ++ () {
    ++(this->exponent);
    return *this;
}

Monomial Monomial::operator ++ (int) {
    Monomial tmp = *this;
    ++(this->exponent);
    return tmp;
}

Monomial& Monomial::operator -- () {
    --(this->exponent);
    return *this;
}

Monomial Monomial::operator -- (int) {
    Monomial tmp = *this;
    --(this->exponent);
    return tmp;
}

Monomial Monomial::operator ! () {
    if (exponent == 0) {
        return Monomial(0, 0);
    }
    return Monomial(coefficient * exponent, exponent - 1);
}

istream& operator >> (istream& is, Monomial& m) {
    cout << "- Enter the coefficient: ";
    is >> m.coefficient;
    cout << "- Enter the exponent: ";
    is >> m.exponent;
    return is;
}

ostream& operator << (ostream& os, const Monomial& m) {
    os << m.coefficient << "x^" << m.exponent;
    return os;
}

Monomial::~Monomial() {
    // cout << "Monomial object is destroyed\n";
}
