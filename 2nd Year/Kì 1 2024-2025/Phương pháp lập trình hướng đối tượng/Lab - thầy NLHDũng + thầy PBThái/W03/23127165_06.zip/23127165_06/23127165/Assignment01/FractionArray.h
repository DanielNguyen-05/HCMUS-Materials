#pragma once
#include "Fraction.h"

class FractionArray {
    private:
        Fraction* arr;
        int n;

    public:
        // Constructors
        FractionArray();
        FractionArray(int n);
        FractionArray(const FractionArray& other);

        void setFraction(int i, Fraction f);
        void setN(int n);

        void loadFromFile(const string& filename);
        Fraction sum() const;
        Fraction max() const;
        Fraction min() const;
        void sortArray();
        void output() const;

        // Destructor
        ~FractionArray();
};