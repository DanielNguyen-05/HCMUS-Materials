#include "Date.h"

int main() {
    Date d, previous_day, next_day;
    int choice;

    cout << "\n\tENTER DATE\n";
    d.input();

    cout << "\n\tMENU\n";   
    cout << "1. Current date\n";
    cout << "2. Previous day\n";
    cout << "3. Next day\n";
    cout << "4. Exit\n";
    cout << "- Enter your choice: ";
    cout << "Your choice: ";
    cin >> choice;

    switch(choice) {
        case 1:
            cout << "\n\tYOUR CURRENT DATE\n";
            d.output();
            break;
        case 2:
            cout << "\n\tYOUR PREVIOUS DATE\n";
            previous_day = d.previousDay();
            previous_day.output();
            break;
        case 3:
            cout << "\n\tYOUR NEXT DATE\n";
            next_day = d.nextDay();
            next_day.output();
            break;
        case 4:
            cout << "Goodbye !!!\n";
            break;
        default:
            cout << "Invalid choice !!!\n";
            break;
    }
    
    return 0;
}
