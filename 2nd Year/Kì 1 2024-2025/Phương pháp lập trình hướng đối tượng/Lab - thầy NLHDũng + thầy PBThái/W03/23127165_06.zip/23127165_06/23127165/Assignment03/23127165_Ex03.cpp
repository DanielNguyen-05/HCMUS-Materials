#include "TriangleArray.h"

int main() {
    TriangleArray tArr;
    tArr.loadFromFile("input.txt");
    cout << "\n- Number of invalid triangles: " << tArr.countInvalid() << "\n";
    tArr.removeInvalid();
    cout << "- Number of equilateral triangles: " << tArr.countEquilateral() << "\n";
    cout << "- Number of right isosceles triangles: " << tArr.countRightIsosceles() << "\n";
    cout << "- Number of right triangles: " << tArr.countRight() << "\n";
    cout << "- Number of acute triangles: " << tArr.countAcute() << "\n";
    cout << "- Number of obtuse triangles: " << tArr.countObtuse() << "\n\n";
    
    return 0;
}