#pragma once
#include <iostream>
#include <cmath>
#include <fstream>
#include <sstream>
#include <string>
using namespace std;

class Triangle {
    private:
        double a;
        double b;
        double c;

    public:
        // Constructors
        Triangle();
        Triangle(double a, double b, double c);
        Triangle(const Triangle& other);

        void setA(const double& a);
        void setB(const double& b);
        void setC(const double& c);

        bool isValidTriangle();
        bool isEquilateral();
        bool isRightIsosceles();
        bool isRight();
        bool isAcute();
        bool isObtuse();

        // Destructor
        ~Triangle();
};