#include "StudentArray.h"

int main() {
    StudentArray sArr;
    sArr.loadFromFile("input.txt");
    sArr.sortByLastName();
    sArr.saveToXML("output.xml");
    
    return 0;
}