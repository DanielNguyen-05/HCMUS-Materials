#include "Triangle.h"

Triangle::Triangle() {
    this->a = 0;
    this->b = 0;
    this->c = 0;
}

Triangle::Triangle(double a, double b, double c) {
    this->a = a;
    this->b = b;
    this->c = c;
}

Triangle::Triangle(const Triangle& other) {
    this->a = other.a;
    this->b = other.b;
    this->c = other.c;
}

void Triangle::setA(const double& a) {
    this->a = a;
}

void Triangle::setB(const double& b) {
    this->b = b;
}

void Triangle::setC(const double& c) {
    this->c = c;
}

bool Triangle::isValidTriangle() {
    if (a + b > c && a + c > b && b + c > a) return true;
    return false;
}

bool Triangle::isEquilateral() {
    if (a == b && b == c) return true;
    return false;
}

bool Triangle::isRightIsosceles() {
    if (a == b && a * a + b * b == c * c) return true;
    if (a == c && a * a + c * c == b * b) return true;
    if (b == c && b * b + c * c == a * a) return true;
    return false;
}

bool Triangle::isRight() {
    if (a * a + b * b == c * c) return true;
    if (a * a + c * c == b * b) return true;
    if (b * b + c * c == a * a) return true;
    return false;
}

bool Triangle::isAcute() {
    if (a * a + b * b > c * c && a * a + c * c > b * b && b * b + c * c > a * a) return true;
    return false;
}

bool Triangle::isObtuse() {
    if (a * a + b * b < c * c || a * a + c * c < b * b || b * b + c * c < a * a) return true;
    return false;
}

Triangle::~Triangle() {
    // cout << "Triangle destructor is called\n";
}
