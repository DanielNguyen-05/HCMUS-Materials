#include "PointArray.h"

int main() {
    PointArray arr;
    arr.loadFromFile("input.txt");
    Point p;
    p.input();
    Point farthest = arr.findFarthestPoint(p);
    cout << "\n=> The farthest point from A";
    p.output();
    cout << " is B";
    farthest.output();
    cout << "\n\n";

    return 0;
}