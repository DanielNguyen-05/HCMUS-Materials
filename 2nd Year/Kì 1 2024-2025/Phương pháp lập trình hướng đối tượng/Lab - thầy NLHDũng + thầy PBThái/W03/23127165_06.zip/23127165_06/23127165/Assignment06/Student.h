#pragma once
#include <iostream>
#include <cstring>
#include <string>
#include <fstream>
#include <sstream>
#include <vector>
#include <algorithm>
using namespace std;

class Student {
    private:
        int id;
        char* name;
        char* address;
        char* dateOfBirth;
        double mark;

    public:
        // Constructors
        Student();
        Student(int id, const char* name, const char* address, const char* dateOfBirth, double mark);
        Student(const Student& other);

        Student& operator=(const Student& other);

        int getId() const { return id; }
        const char* getName() const { return name; }
        const char* getAddress() const { return address; }
        const char* getDateOfBirth() const { return dateOfBirth; }
        double getMark() const { return mark; }
        const char* getLastName() const;

        // Destructor
        ~Student();
};

