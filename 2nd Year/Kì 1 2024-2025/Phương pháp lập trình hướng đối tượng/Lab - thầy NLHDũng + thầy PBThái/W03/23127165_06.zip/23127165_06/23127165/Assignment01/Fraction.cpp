#include "Fraction.h"

Fraction::Fraction() {
    this->num = 0;
    this->den = 1;
}

Fraction::Fraction(int num, int den) {
    this->num = num;
    this->den = den;
}

Fraction::Fraction(const Fraction& other) {
    this->num = other.num;
    this->den = other.den;
}

void Fraction::setNum(int num) {
    this->num = num;
}

void Fraction::setDen(int den) {
    this->den = den;
}

void Fraction::simplify() {
    int a = abs(this->num);
    int b = abs(this->den);
    while (a != b) {
        if (a > b) a -= b;
        else b -= a;
    }
    this->num /= a;
    this->den /= a;
}

Fraction Fraction::operator + (const Fraction& other) const {
    Fraction sum;
    sum.num = this->num * other.den + other.num * this->den;
    sum.den = this->den * other.den;
    sum.simplify();
    return sum;
}

bool Fraction::operator < (const Fraction& other) const {
    double frac1 = (double)this->num / this->den;
    double frac2 = (double)other.num / other.den;
    return frac1 < frac2;
}

ostream& operator << (ostream& os, const Fraction& frac) {
    os << frac.num << "/" << frac.den;
    return os;
}

void Fraction::output() const {
    cout << this->num << "/" << this->den;
}

Fraction::~Fraction() {
    // cout << "Fraction destructor is called\n";
}

