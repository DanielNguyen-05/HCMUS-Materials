#include "Time.h"

Time::Time() {
    hour = 0;
    minute = 0;
    second = 0;
}

Time::Time(int hour, int minute, int second) {
    this->hour = hour;
    this->minute = minute;
    this->second = second;
}

Time::Time(const Time& t) {
    this->hour = t.hour;
    this->minute = t.minute;
    this->second = t.second;
}

bool Time::checkValidTime() {
    if (hour < 0 || hour > 23) return false;
    if (minute < 0 || minute > 59) return false;
    if (second < 0 || second > 59) return false;
    return true;
}

void Time::input() {
    cout << "- Enter hour: ";
    cin >> hour;
    cout << "- Enter minute: ";
    cin >> minute;
    cout << "- Enter second: ";
    cin >> second;
    if (!checkValidTime()) {
        // throw invalid_argument("This is an invalid time !!!\n");
        cout << "\n\tInvalid time. Please enter again.\n\n";
        input();
    }
}

void Time::output() {
    cout << "=> Time: " 
         << setfill('0') << setw(2) << hour << ":"
         << setw(2) << minute << ":"
         << setw(2) << second << "\n\n";
}

Time Time::previousSecond() {
    Time t;
    int total_seconds = (hour * 3600 + minute * 60 + second + 86400 - 1) % 86400;
    t.hour = total_seconds / 3600;
    total_seconds %= 3600;
    t.minute = total_seconds / 60;
    t.second = total_seconds % 60;
    return t;
}

Time Time::nextSecond() {
    Time t;
    int total_seconds = (hour * 3600 + minute * 60 + second + 1) % 86400;
    t.hour = total_seconds / 3600;
    total_seconds %= 3600;
    t.minute = total_seconds / 60;
    t.second = total_seconds % 60;
    return t;
}

Time::~Time() {
    // cout << "Time destructor is called\n";
}
