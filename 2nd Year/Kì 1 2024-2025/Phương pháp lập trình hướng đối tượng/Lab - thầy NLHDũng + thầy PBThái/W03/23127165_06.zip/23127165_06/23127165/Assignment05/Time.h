#pragma once
#include <iostream>
#include <iomanip>
using namespace std;

class Time {
    private:
        int hour;
        int minute;
        int second;
        
    public:
        // Constructors
        Time();
        Time(int hour, int minute, int second);
        Time(const Time& t);

        void input();
        void output();
        Time previousSecond();
        Time nextSecond();

        bool checkValidTime();

        // Destructor
        ~Time();
};