#include "Date.h"

Date::Date() {
    day = 1;
    month = 1;
    year = 2000;
}

Date::Date(int day, int month, int year) {
    this->day = day;
    this->month = month;
    this->year = year;
}

Date::Date(const Date& d) {
    this->day = d.day;
    this->month = d.month;
    this->year = d.year;
}

bool Date::checkValidDate() {
    if (month < 1 || month > 12) return false;
    if (day < 1 || day > 31) return false;
    if (month == 2) {
        if (checkLeapYear()) {
            if (day > 29) return false;
        } else {
            if (day > 28) return false;
        }
    }
    if (month == 4 || month == 6 || month == 9 || month == 11) {
        if (day > 30) return false;
    }
    return true;
}

void Date::input() {
    cout << "- Enter day: ";
    cin >> day;
    cout << "- Enter month: ";
    cin >> month;
    cout << "- Enter year: ";
    cin >> year;
    if (!checkValidDate()) {
        // throw invalid_argument("This is an invalid date !!!\n");
        cout << "\n\tInvalid date. Please enter again.\n\n";
        input();
    }
}

void Date::output() {
    cout << "=> Date: " << day << "/" << month << "/" << year << "\n\n";
}

bool Date::checkLeapYear() {
    if (year % 400 == 0) return true;
    if (year % 100 == 0) return false;
    if (year % 4 == 0) return true;
    return false;
}

bool Date::checkLastDayOfMonth() {
    if (month == 2) {
        if (checkLeapYear()) {
            if (day == 29) return true;
        } else {
            if (day == 28) return true;
        }
    }
    if (month == 4 || month == 6 || month == 9 || month == 11) {
        if (day == 30) return true;
    }
    if (day == 31) return true;
    return false;
}

bool Date::checkLastDayOfYear() {
    if (month == 12 && day == 31) return true;
    return false;
}

Date Date::previousDay() {
    Date d;
    if (this->day == 1) {
        if (this->month == 1) {
            d.day = 31;
            d.month = 12;
            d.year = this->year - 1;
        } else {
            d.month = this->month - 1;
            d.year = this->year; // Gán lại năm
            if (d.month == 2) {
                if (checkLeapYear()) d.day = 29;
                else d.day = 28;
            } else if (d.month == 4 || d.month == 6 || d.month == 9 || d.month == 11) {
                d.day = 30;
            } else {
                d.day = 31;
            }
        }
    } else {
        d.day = this->day - 1;
        d.month = this->month;
        d.year = this->year; // Gán lại tháng và năm
    }
    return d;
}

Date Date::nextDay() {
    Date d;
    if (checkLastDayOfYear()) {
        d.day = 1;
        d.month = 1;
        d.year = this->year + 1;
    } else if (checkLastDayOfMonth()) {
        d.day = 1;
        d.month = this->month + 1;
        d.year = this->year; // Gán lại năm
    } else {
        d.day = this->day + 1;
        d.month = this->month;
        d.year = this->year; // Gán lại tháng và năm
    }
    return d;
}

Date::~Date() { 
    // cout << "Destructor called here !!!\n";
}