#include "FractionArray.h"

int main() {
    FractionArray arr;
    arr.loadFromFile("input.txt");
    cout << "\n=> Sum of fractions: " << arr.sum() << "\n";
    cout << "=> Max fraction: " << arr.max() << "\n";
    cout << "=> Min fraction: " << arr.min() << "\n";
    arr.sortArray();
    cout << "=> Sorted fractions: ";
    arr.output();
    
    return 0;
}