#pragma once
#include "Student.h"

class StudentArray {
    private:
        Student* arr;
        int n;

    public:
        // Constructors
        StudentArray();
        StudentArray(int n);
        StudentArray(const StudentArray& other);

        void loadFromFile(const string& filename);
        void sortByLastName();
        void saveToXML(const char* filename);

        // Destructor
        ~StudentArray();
};
