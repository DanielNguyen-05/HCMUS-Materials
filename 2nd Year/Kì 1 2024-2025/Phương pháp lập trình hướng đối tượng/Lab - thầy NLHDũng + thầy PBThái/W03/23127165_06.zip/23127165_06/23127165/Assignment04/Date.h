#pragma once
#include <iostream>
using namespace std;

class Date {
    private:
        int day;
        int month;
        int year;
        
    public:
        // Constructors
        Date();
        Date(int day, int month, int year);
        Date(const Date& d);

        void input();
        void output();
        Date previousDay();
        Date nextDay();

        bool checkValidDate();
        bool checkLeapYear();
        bool checkLastDayOfMonth();
        bool checkLastDayOfYear();

        // Destructor
        ~Date();
};



