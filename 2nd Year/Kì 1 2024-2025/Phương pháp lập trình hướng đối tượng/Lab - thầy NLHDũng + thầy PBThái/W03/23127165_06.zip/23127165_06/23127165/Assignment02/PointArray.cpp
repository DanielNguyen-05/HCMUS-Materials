#include "PointArray.h"

PointArray::PointArray() {
    this->n = 0;
    this->arr = new Point[0];
}

PointArray::PointArray(int n) {
    this->n = n;
    this->arr = new Point[n];
}

PointArray::PointArray(const PointArray& other) {
    this->n = other.n;
    this->arr = new Point[this->n];
    for (int i = 0; i < this->n; i++) {
        this->arr[i] = other.arr[i];
    }
}

PointArray::~PointArray() {
    delete[] this->arr;
}

void PointArray::setPoint(int i, Point p) {
    this->arr[i] = p;
}

void PointArray::setN(int n) {
    this->n = n;
}

void PointArray::loadFromFile(const string& filename) {
    ifstream fin;
    fin.open(filename);
    if(!fin.is_open()) {
        cout << "Cannot open file " << filename << " !!!\n";
        return;
    }
    int k = 1;
    while (!fin.eof()) {
        Point p;
        int a, b;
        fin >> a;
        fin >> b;
        p.setX(a);
        p.setY(b);
        this->setPoint(k - 1, p);
        k++;
    }
    this->setN(k - 1);
    fin.close();
}

Point PointArray::findFarthestPoint(const Point& P) const {
    double maxDistance = this->arr[0].distanceTo(P);
    int index = 0;
    for (int i = 1; i < this->n; i++) {
        double distance = this->arr[i].distanceTo(P);
        if (distance > maxDistance) {
            maxDistance = distance;
            index = i;
        }
    }
    return this->arr[index];
}

void PointArray::output() const {
    for (int i = 0; i < this->n; i++) {
        this->arr[i].output();
    }
}
