#pragma once
#include <iostream>
#include <cmath>
#include <fstream>
#include <string>
using namespace std;

class Fraction {
    private:
        int num;
        int den;

    public:
        // Constructors
        Fraction();
        Fraction(int num, int den);
        Fraction(const Fraction& other);

        void setNum(int num);
        void setDen(int den);

        void simplify();
        Fraction operator + (const Fraction& other) const;
        bool operator < (const Fraction& other) const;
        friend ostream& operator << (ostream& os, const Fraction& frac);
        void output() const;

        // Destructor
        ~Fraction();
};