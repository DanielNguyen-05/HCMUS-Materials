#include "StudentArray.h"

StudentArray::StudentArray() {
    this->n = 0;
    this->arr = nullptr;
}

StudentArray::StudentArray(int n) {
    this->n = n;
    this->arr = new Student[n];
}

StudentArray::StudentArray(const StudentArray& other) {
    this->n = other.n;
    this->arr = new Student[n];
    for (int i = 0; i < n; i++) {
        this->arr[i] = other.arr[i];
    }
}

StudentArray::~StudentArray() {
    delete[] arr;
}

void StudentArray::loadFromFile(const string& filename) {
    ifstream fin(filename);
    if (!fin.is_open()) {
        cout << "Cannot open file " << filename << " !!!.\n";
        return;
    }

    int count = 0;
    while (fin) {
        int id;
        char name[100];
        char address[100];
        char dateOfBirth[100];
        double mark;
        
        fin >> id;
        if (fin.eof()) break; 
        fin.ignore(); 
        fin.getline(name, 100);
        fin.getline(address, 100);
        fin.getline(dateOfBirth, 100);
        fin >> mark;
        fin.ignore(); 
        
        if (!fin.fail()) {
            count++; 
        }
    }
    fin.clear();
    fin.seekg(0, ios::beg);

    // Allocate memory for the students
    delete[] arr;  
    arr = new Student[count]; 
    n = count; 


    for (int k = 0; k < count; ++k) {
        int id;
        char name[100];
        char address[100];
        char dateOfBirth[100];
        double mark;

        fin >> id;
        if (fin.eof()) break;  
        fin.ignore();  
        fin.getline(name, 100);
        fin.getline(address, 100);
        fin.getline(dateOfBirth, 100);
        fin >> mark;
        fin.ignore();
        
        if (!fin.fail()) {
            arr[k] = Student(id, name, address, dateOfBirth, mark);  // Add student to array
        }
    }

    fin.close(); 
}


void StudentArray::sortByLastName() {
    for (int i = 0; i < n - 1; ++i) {
        for (int j = i + 1; j < n; ++j) {
            const char* lastName1 = arr[i].getLastName();
            const char* lastName2 = arr[j].getLastName();
            if (strcmp(lastName1, lastName2) > 0) {
                Student temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
    }
}

void StudentArray::saveToXML(const char* filename) {
    ofstream fout(filename);
    if (!fout.is_open()) {
        cout << "Cannot open file " << filename << " for writing !!!.\n";
        return;
    }

    fout << "<students>\n";
    for (int i = 0; i < n; ++i) {
        fout << "    <student>\n";
        fout << "        <id>" << arr[i].getId() << "</id>\n";
        fout << "        <name>" << arr[i].getName() << "</name>\n";
        fout << "        <address>" << arr[i].getAddress() << "</address>\n";
        fout << "        <dateOfBirth>" << arr[i].getDateOfBirth() << "</dateOfBirth>\n";
        fout << "        <mark>" << arr[i].getMark() << "</mark>\n";
        fout << "    </student>\n";
    }
    fout << "</students>\n";
    fout.close();
}