#include "Time.h"

int main() {
    Time t, previous_second, next_second;
    int choice;

    cout << "\n\tENTER TIME\n";
    t.input();
    cout << "\n\tMENU\n";
    cout << "1. Current time\n";
    cout << "2. Previous second\n";
    cout << "3. Next second\n";
    cout << "4. Exit\n";
    cout << "- Your choice: ";
    cin >> choice;

    switch(choice) {
        case 1:
            cout << "\n\tYOUR CURRENT TIME\n";
            t.output();
            break;
        case 2:
            cout << "\n\tYOUR PREVIOUS SECOND\n";
            previous_second = t.previousSecond();
            previous_second.output();
            break;
        case 3:
            cout << "\n\tYOUR NEXT SECOND\n";
            next_second = t.nextSecond();
            next_second.output();
            break;
        case 4:
            cout << "Goodbye !!!\n";
            break;
        default:
            cout << "Invalid choice !!!\n";
            break;
    }

    return 0;
}