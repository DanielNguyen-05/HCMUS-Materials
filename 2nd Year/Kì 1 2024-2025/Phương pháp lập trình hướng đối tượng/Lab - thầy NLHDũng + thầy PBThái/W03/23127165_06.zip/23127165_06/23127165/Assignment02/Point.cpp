#include "Point.h"

Point::Point() {
    this->x = 0;
    this->y = 0;
}

Point::Point(double x, double y) {
    this->x = x;
    this->y = y;
}

Point::Point(const Point& other) {
    this->x = other.x;
    this->y = other.y;
}

void Point::setX(double x) {
    this->x = x;
}

void Point::setY(double y) {
    this->y = y;
}

void Point::input() {
    cout << "\n\tENTER THE POINT A: " << "\n";
    cout << "- Enter x: ";
    cin >> this->x;
    cout << "- Enter y: ";
    cin >> this->y;
}

double Point::distanceTo(const Point& other) const {
    return sqrt(pow(this->x - other.x, 2) + pow(this->y - other.y, 2));
}

void Point::output() const {
    cout << "(" << this->x << ", " << this->y << ")";
}

Point::~Point() {
    // cout << "Point destructor is called\n";
}