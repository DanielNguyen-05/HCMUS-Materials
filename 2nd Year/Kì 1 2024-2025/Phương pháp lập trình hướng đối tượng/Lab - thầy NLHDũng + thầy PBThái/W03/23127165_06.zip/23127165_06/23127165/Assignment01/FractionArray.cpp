#include "FractionArray.h"

FractionArray::FractionArray() {
    this->n = 0;
    this->arr = new Fraction[0];
}

FractionArray::FractionArray(int n) {
    this->n = n;
    this->arr = new Fraction[n];
}

FractionArray::FractionArray(const FractionArray& other) {
    this->n = other.n;
    this->arr = new Fraction[this->n];
    for (int i = 0; i < this->n; i++) {
        this->arr[i] = other.arr[i];
    }
}

FractionArray::~FractionArray() {
    delete[] this->arr;
}

void FractionArray::setFraction(int i, Fraction f) {
    this->arr[i] = f;
}

void FractionArray::setN(int n) {
    this->n = n;
}

void FractionArray::loadFromFile(const string& filename) {
    ifstream fin;
    fin.open(filename);
    if(!fin.is_open()) {
        cout << "Cannot open file " << filename << " !!!\n";
        return;
    }
    int k = 1;
    while (!fin.eof()) {
        Fraction f;
        int a, b;
        fin >> a;
        fin >> b;
        f.setNum(a);
        f.setDen(b);
        this->setFraction(k - 1, f);
        k++;
    }
    this->setN(k - 1);
    fin.close();
}

Fraction FractionArray::sum() const {
    Fraction sum;
    for (int i = 0; i < this->n; i++) {
        sum = sum + this->arr[i];
    }
    return sum;
}

Fraction FractionArray::max() const {
    Fraction max = this->arr[0];
    for (int i = 1; i < this->n; i++) {
        if (max < this->arr[i]) {
            max = this->arr[i];
        }
    }
    return max;
}

Fraction FractionArray::min() const {
    Fraction min = this->arr[0];
    for (int i = 1; i < this->n; i++) {
        if (this->arr[i] < min) {
            min = this->arr[i];
        }
    }
    return min;
}

void FractionArray::sortArray() {
    for (int i = 0; i < this->n - 1; i++) {
        for (int j = i + 1; j < this->n; j++) {
            if (this->arr[j] < this->arr[i]) {
                Fraction temp = this->arr[i];
                this->arr[i] = this->arr[j];
                this->arr[j] = temp;
            }
        }
    }
}

void FractionArray::output() const {
    for (int i = 0; i < this->n; i++) {
        cout << this->arr[i] << " ";
    }
    cout << "\n\n";
}

