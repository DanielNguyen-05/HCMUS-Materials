#pragma once
#include <iostream>
#include <cmath>
#include <fstream>
#include <string>
using namespace std;

class Point {
    private:
        double x;
        double y;

    public:
        // Constructors
        Point();
        Point(double x, double y);
        Point(const Point& other);

        void setX(double x);
        void setY(double y);

        void input();
        double distanceTo(const Point& other) const;
        void output() const;

        // Destructor
        ~Point();
};