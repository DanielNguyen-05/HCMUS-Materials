#include "Student.h"

Student::Student() : id(0), mark(0.0) {
    name = new char[1]{ '\0' };
    address = new char[1]{ '\0' };
    dateOfBirth = new char[1]{ '\0' };
}

Student::Student(int id, const char* name, const char* address, const char* dateOfBirth, double mark) : id(id), mark(mark) {
    this->name = new char[strlen(name) + 1];
    strcpy(this->name, name);

    this->address = new char[strlen(address) + 1];
    strcpy(this->address, address);

    this->dateOfBirth = new char[strlen(dateOfBirth) + 1];
    strcpy(this->dateOfBirth, dateOfBirth);
}

Student::Student(const Student& other) : id(other.id), mark(other.mark) {
    name = new char[strlen(other.name) + 1];
    strcpy(name, other.name);

    address = new char[strlen(other.address) + 1];
    strcpy(address, other.address);

    dateOfBirth = new char[strlen(other.dateOfBirth) + 1];
    strcpy(dateOfBirth, other.dateOfBirth);
}

Student& Student::operator = (const Student& other) {
    if (this != &other) {
        delete[] name;
        delete[] address;
        delete[] dateOfBirth;

        id = other.id;
        mark = other.mark;

        name = new char[strlen(other.name) + 1];
        strcpy(name, other.name);

        address = new char[strlen(other.address) + 1];
        strcpy(address, other.address);

        dateOfBirth = new char[strlen(other.dateOfBirth) + 1];
        strcpy(dateOfBirth, other.dateOfBirth);
    }
    return *this;
}

Student::~Student() {
    delete[] name;
    delete[] address;
    delete[] dateOfBirth;
}

const char* Student::getLastName() const {
    const char* first_space = strchr(name, ' '); 
    return first_space ? strndup(name, first_space - name) : name; 
}
