#pragma once
#include "Triangle.h"

class TriangleArray {
    private:
        Triangle* arr;
        int n;
        
    public: 
        // Constructors
        TriangleArray();
        TriangleArray(int n);
        TriangleArray(const TriangleArray& other);

        void loadFromFile(const string& filename);
        void removeInvalid();
        int countInvalid();
        int countEquilateral();
        int countRightIsosceles();
        int countRight();
        int countAcute();
        int countObtuse();

        // Destructor
        ~TriangleArray();
};