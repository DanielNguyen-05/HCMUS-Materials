#pragma once
#include "Point.h"

class PointArray {
    private:
        Point* arr;
        int n;

    public:
        // Constructors
        PointArray();
        PointArray(int n);
        PointArray(const PointArray& other);

        void setPoint(int i, Point p);
        void setN(int n);

        void loadFromFile(const string& filename);
        Point findFarthestPoint(const Point& P) const;
        void output() const;

        // Destructor
        ~PointArray();
};