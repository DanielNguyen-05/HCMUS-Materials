#include "TriangleArray.h"

TriangleArray::TriangleArray() {
    this->n = 0;
    this->arr = nullptr;
}

TriangleArray::TriangleArray(int n) {
    this->n = n;
    this->arr = new Triangle[n];
}

TriangleArray::TriangleArray(const TriangleArray& other) {
    this->n = other.n;
    this->arr = new Triangle[this->n];
    for (int i = 0; i < this->n; i++) {
        this->arr[i] = other.arr[i];
    }
}

TriangleArray::~TriangleArray() {
    delete[] this->arr;
}

void TriangleArray::loadFromFile(const string& filename) {
    ifstream fin(filename);
    if (!fin.is_open()) {
        cout << "Cannot open file " << filename << " !!!\n";
        return;
    }

    int count = 0;
    while (!fin.eof()) {
        double a, b, c;
        fin >> a >> b >> c;
        if (fin.fail()) break;
        count++;
    }
    fin.clear();
    fin.seekg(0, ios::beg);

    // Allocate memory for the triangles
    delete[] arr;
    this->arr = new Triangle[count];
    this->n = count;

    int k = 0;
    while (!fin.eof() && k < count) {
        double a, b, c;
        fin >> a >> b >> c;
        if (fin.fail()) break;
        arr[k].setA(a);
        arr[k].setB(b);
        arr[k].setC(c);
        k++;
    }

    fin.close();
}

int TriangleArray::countInvalid() {
    int count = 0;
    for (int i = 0; i < this->n; i++) {
        if (!this->arr[i].isValidTriangle()) count++;
    }
    return count;
}

void TriangleArray::removeInvalid() {
    int count = countInvalid();
    Triangle* tmp = new Triangle[this->n - count];
    int k = 0;
    for (int i = 0; i < this->n; i++) {
        if (this->arr[i].isValidTriangle()) {
            tmp[k] = this->arr[i];
            k++;
        }
    }
    delete[] this->arr;
    this->arr = tmp;
    this->n -= count;
}

int TriangleArray::countEquilateral() {
    int count = 0;
    for (int i = 0; i < this->n; i++) {
        if (this->arr[i].isEquilateral()) count++;
    }
    return count;
}

int TriangleArray::countRightIsosceles() {
    int count = 0;
    for (int i = 0; i < this->n; i++) {
        if (this->arr[i].isRightIsosceles()) count++;
    }
    return count;
}

int TriangleArray::countRight() {
    int count = 0;
    for (int i = 0; i < this->n; i++) {
        if (this->arr[i].isRight()) count++;
    }
    return count;
}

int TriangleArray::countAcute() {
    int count = 0;
    for (int i = 0; i < this->n; i++) {
        if (this->arr[i].isAcute()) count++;
    }
    return count;
}

int TriangleArray::countObtuse() {
    int count = 0;
    for (int i = 0; i < this->n; i++) {
        if (this->arr[i].isObtuse()) count++;
    }
    return count;
}