#include "Fraction.h"

Fraction::Fraction() {
    numerator = 0;
    denominator = 1;
}

Fraction::Fraction(int num, int den) {
    numerator = num;
    denominator = den;
    reduce();
}

void Fraction::input() {
    cout << "- Enter numerator: ";
    while (!(cin >> numerator)) {
        cout << "\nInvalid input! Please enter a valid integer: ";
        cin.clear(); 
        cin.ignore(numeric_limits<streamsize>::max(), '\n'); 
    }

    cout << "- Enter denominator: ";
    while (!(cin >> denominator) || denominator == 0) {
        if (denominator == 0) {
            cout << "\nDenominator cannot be zero! Enter again: ";
        } else {
            cout << "\nInvalid input! Please enter a valid integer: ";
        }
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n'); 
    }
    reduce();
}

void Fraction::output() {
    if (denominator == 1) {
        cout << numerator << "\n";
    } else {
        cout << numerator << "/" << denominator << "\n";
    }
}

Fraction Fraction::operator + (const Fraction& other) {
        int num = numerator * other.denominator + other.numerator * denominator;
        int denom = denominator * other.denominator;
        Fraction result{num, denom};
        result.reduce();
        return result;
}

Fraction Fraction::operator - (const Fraction& other) {
    int num = numerator * other.denominator - other.numerator * denominator;
    int denom = denominator * other.denominator;
    Fraction result{num, denom};
    result.reduce();
    return result;
}

Fraction Fraction::operator * (const Fraction& other) {
    int num = numerator * other.numerator;
    int denom = denominator * other.denominator;
    Fraction result{num, denom};
    result.reduce();
    return result;
}

Fraction Fraction::operator / (const Fraction& other) {
    if (other.numerator == 0) {
        throw invalid_argument("Division by zero is not allowed!\n");
    }
    int num = numerator * other.denominator;
    int denom = denominator * other.numerator;
    Fraction result{num, denom};
    result.reduce();
    return result;
}

int Fraction::compare(const Fraction& other) {
    int lhs = numerator * other.denominator;
    int rhs = other.numerator * denominator;
    if (lhs == rhs) return 0;
    return (lhs < rhs) ? -1 : 1;
}

bool Fraction::isPositive() {
    return (numerator > 0 && denominator > 0) || (numerator < 0 && denominator < 0);
}

bool Fraction::isNegative() {
    return (numerator < 0 && denominator > 0) || (numerator > 0 && denominator < 0);
}

bool Fraction::isZero() {
    return numerator == 0;
}

int Fraction::gcd(int a, int b) {
    while (b != 0) {
        int temp = b;
        b = a % b;
        a = temp;
    }
    return a;
}

void Fraction::reduce() {
    int divisor = gcd(numerator, denominator);
    
    numerator /= divisor;
    denominator /= divisor;
    
    if (denominator < 0) {
        numerator = -numerator;
        denominator = -denominator;
    }
}