#pragma once
#include <iostream>
#include <cmath>
#include <algorithm>
using namespace std;

class Point {
    private:
        double x;
        double y;
    public:
        void inputPoint();
        void outputPoint();
        double getX();
        void setX(const double&);
        double getY();
        void setY(const double&);
        double distance(const Point&);
        double distanceToOx();
        double distanceToOy();
};