#include "Node.h"

int Node::getData() {
    return this->data;
}

Node* Node::getNext() {
    return this->next;
}

void Node::setData(const int& data) {
    this->data = data;
}

void Node::setNext(Node* next) {
    this->next = next;
}