#include <iostream>
#include <limits>
using namespace std;

class Fraction {
    private:
        int numerator;
        int denominator;
    public:
        // Constructors
        Fraction();
        Fraction(int, int);

        // Overloaded operators
        Fraction operator + (const Fraction&);
        Fraction operator - (const Fraction&);
        Fraction operator * (const Fraction&);
        Fraction operator / (const Fraction&);

        // Member functions
        int gcd(int, int);
        void reduce();
        void input();
        void output();
        int compare(const Fraction&);
        bool isPositive();
        bool isNegative();
        bool isZero();
};

