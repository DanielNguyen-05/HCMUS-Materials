#include "Triangle.h"

void Triangle::inputTriangle() {
    cout << "\t INPUT FOR TRIANGLE:\n";
    cout << "Enter the first point of the triangle: " << "\n";
    a.inputPoint();
    cout << "Enter the second point of the triangle: " << "\n";
    b.inputPoint();
    cout << "Enter the third point of the triangle: " << "\n";
    c.inputPoint();
}

void Triangle::outputTriangle() {
    cout << "=> Your triangle is: ";
    this->a.outputPoint();
    cout << ", ";
    this->b.outputPoint();
    cout << ", ";
    this->c.outputPoint();
}

bool Triangle::isValidTriangle() {
    return this->a.distance(this->b) + this->b.distance(this->c) > this->a.distance(this->c) &&
           this->a.distance(this->b) + this->a.distance(this->c) > this->b.distance(this->c) &&
           this->a.distance(this->c) + this->b.distance(this->c) > this->a.distance(this->b);
}

void Triangle::typeOfTriangle() {
    double a = this->b.distance(this->a);
    double b = this->b.distance(this->c);
    double c = this->a.distance(this->c);
    if (a == b && b == c) cout << "=> This is an equilateral triangle." << "\n";
    else if (a == b || b == c || a == c) cout << "=>This is an isosceles triangle." << "\n";
    else if (a * a + b * b == c * c || a * a + c * c == b * b || b * b + c * c == a * a) cout << "=> This is a right triangle." << "\n";
    else if (a * a + b * b < c * c || a * a + c * c < b * b || b * b + c * c < a * a) cout << "=> This is an obtuse triangle." << "\n";
    else cout << "=> This is a acute triangle." << "\n";
}

double Triangle::perimeter() {
    return this->a.distance(this->b) + this->b.distance(this->c) + this->a.distance(this->c);
}

double Triangle::area() {
    double p = perimeter() / 2;
    return sqrt(p * (p - this->a.distance(this->b)) * (p - this->b.distance(this->c)) * (p - this->a.distance(this->c)));
}

Point Triangle::centerG() {
    Point center;
    center.setX((this->a.getX() + this->b.getX() + this->c.getX()) / 3);
    center.setY((this->a.getY() + this->b.getY() + this->c.getY()) / 3);

    return center;
}
