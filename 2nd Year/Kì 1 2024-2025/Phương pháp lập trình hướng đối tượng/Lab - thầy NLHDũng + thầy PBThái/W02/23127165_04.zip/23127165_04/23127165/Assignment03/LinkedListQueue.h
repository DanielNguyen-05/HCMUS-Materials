#pragma once
#include "Node.h"

class LinkedListQueue {
    private:
        Node* head;
        Node* tail;
        int capacity; // max number of elements in the queue
        int num; // current number of elements in the queue

    public:
        LinkedListQueue();

        void init(const int&);
        void enqueue(const int&);
        int dequeue();
        int peek();
        bool isEmpty();
        bool isFull();
        void clear();
    };