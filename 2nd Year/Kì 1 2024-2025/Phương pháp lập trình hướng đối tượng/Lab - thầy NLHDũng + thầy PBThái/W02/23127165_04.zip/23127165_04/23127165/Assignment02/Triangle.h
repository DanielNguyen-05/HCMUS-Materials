#pragma once
#include "Point.h"

class Triangle {
    private:
        Point a;
        Point b;
        Point c;
    public:
        void inputTriangle();
        void outputTriangle();
        bool isValidTriangle();
        void typeOfTriangle();
        double perimeter();
        double area();
        Point centerG();
};

