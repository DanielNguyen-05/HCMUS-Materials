#include "Point.h"

void Point::inputPoint() {
    cout << "- Enter x: ";
    cin >> this->x;
    cout << "- Enter y: ";
    cin >> this->y;
}

void Point::outputPoint() {
    cout << "(" << this->x << ", " << this->y << ")";
}

double Point::distance(const Point& b) {
    return sqrt(pow(this->x - b.x, 2) + pow(this->y - b.y, 2));
}

double Point::distanceToOx() {
    return abs(this->y);
}

double Point::distanceToOy() {
    return abs(this->x);
}

double Point::getX() {
    return this->x;
}

void Point::setX(const double& x) {
    this->x = x;
}

double Point::getY() {
    return this->y;
}

void Point::setY(const double& y) {
    this->y = y;
}
