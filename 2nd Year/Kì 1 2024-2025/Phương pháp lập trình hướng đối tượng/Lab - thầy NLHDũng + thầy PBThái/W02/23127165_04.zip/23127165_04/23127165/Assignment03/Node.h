#pragma once
#include <iostream>
#include <stdexcept>
using namespace std;

class Node {
    private:
        int data;
        Node* next;
    public:
        int getData();
        Node* getNext();
        void setData(const int&);
        void setNext(Node*);
};