#include "Fraction.h"

int main() {
    Fraction frac1, frac2, results;
    int comparison;

    // Input two fractions
    cout << "\n\t ENTER THE FIRST FRACTION:\n";
    frac1.input();
    cout << "\n\t ENTER THE SECOND FRACTION:\n";
    frac2.input();
    int choice;
    do {
        cout << "\n\t CHOOSE YOUR REQUEST:\n";
        cout << "1. Output the fractions after being reduced\n";
        cout << "2. Add 2 fractions\n";
        cout << "3. Subtract 2 fractions\n";
        cout << "4. Multiply 2 fractions\n";
        cout << "5. Divide 2 fractions\n";
        cout << "6. Compare 2 fractions\n";
        cout << "7. Check if these fractions are positive, negative or zero\n";
        cout << "8. Exit\n";
        cout << "\n- Enter your choice: ";
        cin >> choice;

        cout << "\n";
        switch (choice) {
        case 1:
            cout << "=> First fraction after being reduced: ";
            frac1.output();
            cout << "=> Second fraction after being reduced: ";
            frac2.output();
            break;
        case 2:
            cout << "=> Sum of two fractions: ";
            results = frac1 + frac2;
            results.output();
            break;
        case 3:
            cout << "=> Substract 2 fractions: ";
            results = frac1 - frac2;
            results.output();
            break;
        case 4:
            cout << "=> Multiply 2 fractions: ";
            results = frac1 * frac2;
            results.output();
            break;
        case 5:
            try {
                cout << "=> Divide 2 fractions: ";
                results = frac1 / frac2;
                results.output();
            } catch (const invalid_argument& e) {
                cout << e.what(); 
            }
            break;
        case 6:
            comparison = frac1.compare(frac2);
            if (comparison == 0) cout << "=> The fractions are equal.\n";
            else if (comparison == 1) cout << "=> The first fraction is greater than the second.\n";
            else cout << "=> The first fraction is less than the second.\n";
            break;
        case 7:
            cout << "=> The first fraction is ";

            if (frac1.isPositive()) cout << "positive.\n";
            else if (frac1.isNegative()) cout << "negative.\n";
            else cout << "zero.\n";

            cout << "=> The second fraction is ";
            if (frac2.isPositive()) cout << "positive.\n";
            else if (frac2.isNegative()) cout << "negative.\n";
            else cout << "zero.\n";
            break;
        case 8:
            cout << "=> Thank you for using the program!\n";
            break;
        default:
            cout << "=> Invalid choice! Please enter a valid choice!\n";
            break;
        }
    } while (choice != 8);
    
    return 0;
}
