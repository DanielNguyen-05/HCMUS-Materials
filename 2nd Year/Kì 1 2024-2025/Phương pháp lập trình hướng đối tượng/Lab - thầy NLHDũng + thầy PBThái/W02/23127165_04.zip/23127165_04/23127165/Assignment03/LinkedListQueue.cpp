#include "LinkedListQueue.h"

LinkedListQueue::LinkedListQueue() {
    head = tail = nullptr;
    capacity = num = 0;
}

void LinkedListQueue::init(const int& capacity) {
    this->capacity = capacity;
    clear(); // Delete all elements in the queue
    head = tail = nullptr; // Reset head and tail
    num = 0; // Reset number of elements in the queue
}

void LinkedListQueue::enqueue(const int& x) {
    if (isFull()) throw out_of_range("Queue is full, so cannot enqueue !!!\n");

    Node* temp = new Node;
    temp->setData(x);
    temp->setNext(nullptr);

    if (isEmpty()) {
        head = tail = temp;
    } else {
        tail->setNext(temp);
        tail = temp;
    }
    ++this->num;
}

int LinkedListQueue::dequeue() {
    if(isEmpty()) throw out_of_range("Queue is empty, so cannot dequeue !!!\n");
    else {
        Node* temp = head;
        head = head->getNext();
        int x = temp->getData();
        delete temp;
        --this->num;

        if (isEmpty()) tail = nullptr; // Reset tail if the queue is empty after dequeue

        return x;
    }
}

int LinkedListQueue::peek() {
    if(isEmpty()) throw out_of_range("Queue is empty, so cannot peek !!!\n");
    else return head->getData();
}

bool LinkedListQueue::isEmpty() {
    return this->num == 0;
}

bool LinkedListQueue::isFull() {
    return this->num == this->capacity;
}

void LinkedListQueue::clear() {
    while (!isEmpty()) {
        dequeue();
    }
}