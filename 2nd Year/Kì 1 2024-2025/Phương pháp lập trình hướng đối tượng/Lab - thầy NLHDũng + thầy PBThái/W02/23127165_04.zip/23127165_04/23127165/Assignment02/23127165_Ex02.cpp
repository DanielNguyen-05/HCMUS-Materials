#include "Triangle.h"

int main() {
    Point a, b, c;
    Triangle t;
    int choice, choice_1, choice_2;
    double f;
    do {
        cout << "\n\t CHOOSE YOUR TYPE:\n";
        cout << "1. Point\n";
        cout << "2. Triangle\n";
        cout << "3. Exit\n";
        cout << "\n- Enter your choice: ";
        cin >> choice;
        cout << "\n";
        switch (choice) {
        case 1:
            cout << "\t INPUT 2 POINTS:\n";
            cout << "Enter the first point: " << "\n";
            a.inputPoint();
            cout << "Enter the second point: " << "\n";
            b.inputPoint();
            do {
                cout << "\n\t CHOOSE YOUR REQUEST:\n";
                cout << "1. Calculate the distance between 2 points\n";
                cout << "2. Calculate the distance from A(" << a.getX() << ", " << a.getY() << ") to Ox and Oy\n";
                cout << "3. Calculate the distance from B(" << b.getX() << ", " << b.getY() << ") to Ox and Oy\n";
                cout << "4. Exit\n";
                cout << "\n- Enter your choice: ";
                cin >> choice_1;
                cout << "\n";
                switch (choice_1) {
                case 1:
                    cout << "=> Distance between two points: " << a.distance(b) << "\n";
                    break;
                case 2:
                    cout << "=> Distance from A";
                    a.outputPoint();
                    cout << " to Ox: " << a.distanceToOx() << "\n";
                    cout << "=> Distance from A";
                    a.outputPoint();
                    cout << " to Oy: " << a.distanceToOy() << "\n";
                    break;
                case 3:
                    cout << "=> Distance from B";
                    b.outputPoint();
                    cout << " to Ox: " << b.distanceToOx() << "\n";
                    cout << "=> Distance from B";
                    b.outputPoint();
                    cout << " to Oy: " << b.distanceToOy() << "\n";
                    break;
                case 4:
                    cout << "=> Thank you for using the program!\n";
                    break;
                default:
                    cout << "=> Invalid choice! Please enter a valid choice!\n";
                    break;
                }
            } while (choice_1 != 4);
            break;
        case 2:
            t.inputTriangle();
            do {
                cout << "\n\t CHOOSE YOUR REQUEST:\n";
                cout << "1. Check if three points are a valid triangle\n";
                cout << "2. Determine triangle's type\n";
                cout << "3. Calculate triangle's perimeter\n";
                cout << "4. Calculate triangle's area\n";
                cout << "5. Calculate its center of gravity\n";
                cout << "6. Exit\n";
                cout << "\n- Enter your choice: ";
                cin >> choice_2;
                cout << "\n";
                switch (choice_2) {
                case 1:
                    if (t.isValidTriangle()) cout << "=> Yes, it is a triangle." << "\n";
                    else cout << "=> No, it is not a triangle." << "\n";
                    break;
                case 2:
                    if (!t.isValidTriangle()) {
                        cout << "=> This is not a triangle." << "\n";
                        return -1;
                    }
                    t.typeOfTriangle();
                    break;
                case 3: 
                    if (!t.isValidTriangle()) {
                        cout << "=> This is not a triangle, so cannot calculate its perimeter" << "\n";
                        return -1;
                    }
                    f = t.perimeter();
                    cout << "=> Perimeter: " << f << "\n";
                    break;
                case 4:
                    if (!t.isValidTriangle()) {
                        cout << "=> This is not a triangle, so cannot calculate its area" << "\n";
                        return -1;
                    }
                    f = t.area();
                    cout << "=> Area: " << f << "\n";
                    break;
                case 5:
                    if (!t.isValidTriangle()) {
                        cout << "=> This is not a triangle, so cannot find its center of gravity" << "\n";
                        return -1;
                    }
                    c = t.centerG();
                    cout << "=> Center of gravity: ";
                    c.outputPoint();
                    cout << "\n";
                    break;
                case 6:
                    cout << "=> Thank you for using the program!\n";
                    break;
                default:
                    cout << "=> Invalid choice! Please enter a valid choice!\n";
                    break;
                }
            } while (choice_2 != 6);
            break;
        case 3:
            cout << "=> Thank you for using the program!\n";
            break;
        default:
            cout << "=> Invalid choice! Please enter a valid choice!\n";
            break;
        }
    } while (choice != 3);
    
    return 0;
}