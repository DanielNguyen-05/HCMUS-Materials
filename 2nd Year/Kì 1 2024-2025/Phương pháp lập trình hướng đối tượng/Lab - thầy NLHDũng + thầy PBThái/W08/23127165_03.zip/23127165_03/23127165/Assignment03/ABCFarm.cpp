#include "ABCFarm.h"

void ABCFarm::Input() {
    int numCows, numGoats;
    cout << "Enter number of Dairy Cows: ";
    cin >> numCows;
    for (int i = 0; i < numCows; ++i) {
        int id;
        float weight, age;
        cout << "Enter ID, weight, and age for Dairy Cow " << (i + 1) << ": ";
        cin >> id >> weight >> age;
        cows.emplace_back(id, weight, age);
    }

    cout << "Enter number of Goats: ";
    cin >> numGoats;
    for (int i = 0; i < numGoats; ++i) {
        int id;
        float weight, age;
        cout << "Enter ID, weight, and age for Goat " << (i + 1) << ": ";
        cin >> id >> weight >> age;
        goats.emplace_back(id, weight, age);
    }
}

void ABCFarm::Output() const {
    cout << "\nDairy Cows:\n";
    for (const auto& cow : cows) {
        cow.ToString();
    }

    cout << "\nGoats:\n";
    for (const auto& goat : goats) {
        goat.ToString();
    }
}

void ABCFarm::OutputByAge(int min, int max) const {
    cout << "\nAnimals aged between " << min << " and " << max << " years:\n";

    for (const auto& cow : cows) {
        if (cow.getAge() >= min && cow.getAge() <= max) {
            cow.ToString();
        }
    }

    for (const auto& goat : goats) {
        if (goat.getAge() >= min && goat.getAge() <= max) {
            goat.ToString();
        }
    }
}
