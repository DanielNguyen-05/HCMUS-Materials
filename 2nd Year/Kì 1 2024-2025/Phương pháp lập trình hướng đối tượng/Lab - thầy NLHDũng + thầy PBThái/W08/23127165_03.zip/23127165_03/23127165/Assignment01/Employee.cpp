#include "Employee.h"

Employee::Employee() {
    empID = "";
    fullName = "";
    hireDate = "";
    address = "";
}

Employee::Employee(string id, string name, string date, string addr) {
    empID = id;
    fullName = name;
    hireDate = date;
    address = addr;
}

Employee::Employee(string id, string name, string date) {
    empID = id;
    fullName = name;
    hireDate = date;
    address = "";
}

Employee::Employee(string id, string name) {
    empID = id;
    fullName = name;
    hireDate = "";
    address = "";
}

Employee::Employee(const Employee& other) {
    empID = other.empID;
    fullName = other.fullName;
    hireDate = other.hireDate;
    address = other.address;
}

void Employee::inputInfo() {
    cout << "\n- Enter employee ID: ";
    cin >> empID;
    cout << "- Enter full name: ";
    cin.ignore();
    getline(cin, fullName);
    cout << "- Enter hire date: ";
    cin >> hireDate;
    cout << "- Enter address: ";
    cin.ignore();
    getline(cin, address);
}

void Employee::printInfo() const {
    cout << "\n- Employee ID: " << empID << "\n";
    cout << "- Full name: " << fullName << "\n";
    cout << "- Hire date: " << hireDate << "\n";
    cout << "- Address: " << address << "\n";
}

float Employee::calculateBaseSalary() const {
    return 0;
}

