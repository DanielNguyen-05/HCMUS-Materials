#pragma once
#include "Employee.h"

// Derived class: OfficeEmployee
class OfficeEmployee : public Employee {
private:
    int workingDays;
    const int PAY_RATE_PER_DAY = 300000;

public:
    OfficeEmployee();
    OfficeEmployee(string id, string name, string date, string addr, int days);
    OfficeEmployee(string id, string name);
    OfficeEmployee(string id, string name, string date, string addr);
    OfficeEmployee(const OfficeEmployee& other);

    void inputOfficeEmployeeInfo();
    void printOfficeEmployeeInfo() const;
    float calculateSalary() const;

    OfficeEmployee& operator = (const OfficeEmployee& other);
};