#pragma once
#include "Employee.h"

// Derived class: Worker
class Worker : public Employee {
private:
    int itemsProduced;
    const int PAY_RATE_PER_ITEM = 20000;

public:
    Worker();
    Worker(string id, string name, string date, string addr, int items);
    Worker(string id, string name, string date, string addr);
    Worker(string id, string name);
    Worker(const Worker& other);

    void inputWorkerInfo();
    void printWorkerInfo() const;
    float calculateSalary() const;

    Worker& operator = (const Worker& other);
};