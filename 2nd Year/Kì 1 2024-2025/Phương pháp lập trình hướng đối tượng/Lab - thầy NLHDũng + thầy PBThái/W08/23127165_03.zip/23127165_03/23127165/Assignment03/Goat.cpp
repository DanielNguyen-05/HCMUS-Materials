#include "Goat.h"

Goat::Goat() : Animal() {}

Goat::Goat(int id, float wt, float ag) : Animal(id, wt, ag) {}

Goat::Goat(const Goat& other) : Animal(other) {}

void Goat::ToString() const {
    cout << "Goat -> ";
    Animal::ToString();
    cout << endl;
}

Goat& Goat::operator=(const Goat& other) {
    if (this != &other) {
        Animal::operator=(other);
    }
    return *this;
}
