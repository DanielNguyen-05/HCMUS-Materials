#pragma once
#include "Animal.h"

class DairyCow : public Animal {
public:
    DairyCow();                          // Default Constructor
    DairyCow(int id, float wt, float ag);  // Parameterized Constructor
    DairyCow(const DairyCow& other);     // Copy Constructor

    void ToString() const override;      // Override ToString
    DairyCow& operator=(const DairyCow& other);  // Assignment Operator
};

