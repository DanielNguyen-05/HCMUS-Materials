#include "Worker.h"

Worker::Worker() {
    empID = "";
    fullName = "";
    hireDate = "";
    address = "";
    itemsProduced = 0;
}

Worker::Worker(string id, string name, string date, string addr, int items) {
    empID = id;
    fullName = name;
    hireDate = date;
    address = addr;
    itemsProduced = items;
}

Worker::Worker(string id, string name) {
    empID = id;
    fullName = name;
    hireDate = "";
    address = "";
    itemsProduced = 0;
}

Worker::Worker(string id, string name, string date, string addr) {
    empID = id;
    fullName = name;
    hireDate = date;
    address = addr;
    itemsProduced = 0;
}

Worker::Worker(const Worker& other) {
    empID = other.empID;
    fullName = other.fullName;
    hireDate = other.hireDate;
    address = other.address;
    itemsProduced = other.itemsProduced;
}

void Worker::inputWorkerInfo() {
    cout << "\n- Enter worker ID: ";
    cin >> empID;
    cout << "- Enter full name: ";
    cin.ignore();
    getline(cin, fullName);
    cout << "- Enter hire date: ";
    cin >> hireDate;
    cout << "- Enter address: ";
    cin.ignore();
    getline(cin, address);
    cout << "- Enter the number of items produced: ";
    cin >> itemsProduced;
}

void Worker::printWorkerInfo() const {
    cout << "\n- Employee ID: " << empID << "\n";
    cout << "- Full name: " << fullName << "\n";
    cout << "- Hire date: " << hireDate << "\n";
    cout << "- Address: " << address << "\n";
    cout << "- Number of items produced: " << itemsProduced << "\n";
}

float Worker::calculateSalary() const {
    return itemsProduced * PAY_RATE_PER_ITEM;
}

Worker& Worker::operator = (const Worker& other) {
    empID = other.empID;
    fullName = other.fullName;
    hireDate = other.hireDate;
    address = other.address;
    itemsProduced = other.itemsProduced;
    return *this;
}
