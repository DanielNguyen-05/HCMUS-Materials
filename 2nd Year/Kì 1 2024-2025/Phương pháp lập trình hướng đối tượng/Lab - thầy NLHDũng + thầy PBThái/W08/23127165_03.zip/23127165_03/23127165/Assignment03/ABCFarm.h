#pragma once
#include <vector>
#include "DairyCow.h"
#include "Goat.h"

class ABCFarm {
private:
    vector<DairyCow> cows;
    vector<Goat> goats;

public:
    void Input();                          // Input farm data
    void Output() const;                   // Output all farm data
    void OutputByAge(int min, int max) const;  // Output animals within age range
};
