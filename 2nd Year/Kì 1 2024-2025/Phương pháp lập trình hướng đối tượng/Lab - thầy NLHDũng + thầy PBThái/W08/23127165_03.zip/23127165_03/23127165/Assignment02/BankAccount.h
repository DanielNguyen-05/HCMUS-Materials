#pragma once
#include <iostream>
#include <string>
#include <cmath>
#include <stdexcept>
#include <iomanip>
using namespace std;

class BankAccount {
protected:
    string accountNumber;
    string ownerName;
    string socialID;
    double balance;

public:
    BankAccount();
    void inputBankAccount();
    void printBankAccount() const;
    void depositBankAccount(double amount);
    void withdrawBankAccount(double amount);
    void checkBalance() const;
};
