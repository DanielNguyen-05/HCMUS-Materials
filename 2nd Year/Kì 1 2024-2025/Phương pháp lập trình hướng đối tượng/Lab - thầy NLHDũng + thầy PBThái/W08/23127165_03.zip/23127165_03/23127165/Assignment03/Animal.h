#pragma once
#include <iostream>
#include <iomanip>
#include <stdexcept>
#include <string>
using namespace std;

class Animal {
protected:
    const int identifier;  // Identifier is immutable after initialization
    float weight;          // Weight in kilograms
    float age;             // Age in years

public:
    Animal();  // Default Constructor
    Animal(int id, float wt, float ag);  // Parameterized Constructor
    Animal(const Animal& other);         // Copy Constructor
    virtual ~Animal() = default;         // Virtual Destructor

    // Getters
    int getIdentifier() const;
    float getWeight() const;
    float getAge() const;

    // Setters
    void setWeight(float wt);
    void setAge(float ag);

    // ToString method
    virtual void ToString() const;

    // Assignment operator
    Animal& operator=(const Animal& other);

    // Validation methods
    static bool isValidWeight(float wt);
    static bool isValidAge(float ag);
};
