#pragma once
#include <iostream>
#include <string>
#include <vector>
using namespace std;

// Base class: Employee
class Employee {
protected:
    string empID;
    string fullName;
    string hireDate;
    string address;

public:
    Employee();
    Employee(string id, string name, string date, string addr);
    Employee(string id, string name, string date);
    Employee(string id, string name);
    Employee(const Employee& other);

    void inputInfo();
    void printInfo() const;

    float calculateBaseSalary() const; // Can be used in derived classes
};
