#include "OfficeEmployee.h"
#include "Worker.h"

int main() {
    vector<Worker> workers;
    vector<OfficeEmployee> officeEmployees;
    int choice;

    do {
        cout << "\n=========== Employee Management Menu ===========\n";
        cout << "1. Add a Worker\n";
        cout << "2. Add an Office Employee\n";
        cout << "3. Display all Workers\n";
        cout << "4. Display all Office Employees\n";
        cout << "5. Calculate and display salary of Workers\n";
        cout << "6. Calculate and display salary of Office Employees\n";
        cout << "0. Exit\n";
        cout << "================================================\n";
        cout << "Choose an option: ";
        cin >> choice;

        switch (choice) {
        case 1: {
            Worker newWorker;
            cout << "\nEnter Worker information:";
            newWorker.inputWorkerInfo();
            workers.push_back(newWorker);
            break;
        }
        case 2: {
            OfficeEmployee newOfficeEmployee;
            cout << "Enter Office Employee information:\n";
            newOfficeEmployee.inputOfficeEmployeeInfo();
            officeEmployees.push_back(newOfficeEmployee);
            break;
        }
        case 3: {
            cout << "\n=== List of Workers ===\n";
            for (const auto& worker : workers) {
                worker.printWorkerInfo();
                cout << "-----------------------\n";
            }
            break;
        }
        case 4: {
            cout << "\n=== List of Office Employees ===\n";
            for (const auto& officeEmployee : officeEmployees) {
                officeEmployee.printOfficeEmployeeInfo();
                cout << "-----------------------\n";
            }
            break;
        }
        case 5: {
            cout << "\n=== Workers' Salaries ===\n";
            for (const auto& worker : workers) {
                worker.printWorkerInfo();
                cout << "- Salary: " << worker.calculateSalary() << "\n";
                cout << "-----------------------\n";
            }
            break;
        }
        case 6: {
            cout << "\n=== Office Employees' Salaries ===\n";
            for (const auto& officeEmployee : officeEmployees) {
                officeEmployee.printOfficeEmployeeInfo();
                cout << "- Salary: " << officeEmployee.calculateSalary() << "\n";
                cout << "-----------------------\n";
            }
            break;
        }
        case 0:
            cout << "Exiting the program. Goodbye!\n";
            break;
        default:
            cout << "Invalid choice. Please try again.\n";
        }
    } while (choice != 0);

    return 0;
}