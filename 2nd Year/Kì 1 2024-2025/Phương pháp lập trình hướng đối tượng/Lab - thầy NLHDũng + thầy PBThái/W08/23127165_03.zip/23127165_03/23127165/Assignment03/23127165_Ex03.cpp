#include "ABCFarm.h"

int main() {
    ABCFarm farm;

    farm.Input();                // Input farm data
    farm.Output();               // Display all animals
    farm.OutputByAge(2, 5);      // Display animals aged between 2 and 5

    return 0;
}
