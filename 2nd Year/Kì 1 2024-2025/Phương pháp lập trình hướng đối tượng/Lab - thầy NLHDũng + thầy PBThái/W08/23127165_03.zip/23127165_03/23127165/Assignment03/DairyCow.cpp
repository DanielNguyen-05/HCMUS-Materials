#include "DairyCow.h"

DairyCow::DairyCow() : Animal() {}

DairyCow::DairyCow(int id, float wt, float ag) : Animal(id, wt, ag) {}

DairyCow::DairyCow(const DairyCow& other) : Animal(other) {}

void DairyCow::ToString() const {
    cout << "Dairy Cow -> ";
    Animal::ToString();
    cout << endl;
}

DairyCow& DairyCow::operator=(const DairyCow& other) {
    if (this != &other) {
        Animal::operator=(other);
    }
    return *this;
}
