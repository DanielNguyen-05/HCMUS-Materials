#include "Animal.h"

using namespace std;

// Constructors
Animal::Animal() : identifier(0), weight(0.0f), age(0.0f) {}

Animal::Animal(int id, float wt, float ag) : identifier(id) {
    if (!isValidWeight(wt) || !isValidAge(ag)) {
        throw invalid_argument("Invalid weight or age!!!");
    }
    weight = wt;
    age = ag;
}

Animal::Animal(const Animal& other) : identifier(other.identifier) {
    weight = other.weight;
    age = other.age;
}

// Getters
int Animal::getIdentifier() const { return identifier; }
float Animal::getWeight() const { return weight; }
float Animal::getAge() const { return age; }

// Setters
void Animal::setWeight(float wt) {
    if (isValidWeight(wt)) {
        weight = wt;
    }
    else {
        throw invalid_argument("Weight must be positive.");
    }
}

void Animal::setAge(float ag) {
    if (isValidAge(ag)) {
        age = ag;
    }
    else {
        throw invalid_argument("Age must be positive.");
    }
}

// ToString
void Animal::ToString() const {
    cout << fixed << setprecision(2)
        << "ID: " << identifier << ", Weight: " << weight << " kg, Age: " << age << " years";
}

// Assignment operator
Animal& Animal::operator=(const Animal& other) {
    if (this != &other) {
        weight = other.weight;
        age = other.age;
    }
    return *this;
}

// Validation methods
bool Animal::isValidWeight(float wt) { return wt > 0; }
bool Animal::isValidAge(float ag) { return ag > 0; }
