#pragma once
#include "Animal.h"

class Goat : public Animal {
public:
    Goat();                           // Default Constructor
    Goat(int id, float wt, float ag);  // Parameterized Constructor
    Goat(const Goat& other);          // Copy Constructor

    void ToString() const override;   // Override ToString
    Goat& operator=(const Goat& other);  // Assignment Operator
};

