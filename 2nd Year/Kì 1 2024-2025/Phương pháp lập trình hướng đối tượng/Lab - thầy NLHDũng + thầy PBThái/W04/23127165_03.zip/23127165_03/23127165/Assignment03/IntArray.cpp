#include "IntArray.h"

IntArray::IntArray() {
    this->size = 0;
    this->arr = nullptr;
}

IntArray::IntArray(size_t s) {
    this->size = s;
    this->arr = new int[size];
}

IntArray::IntArray(int* a, size_t s) {
    this->size = s;
    this->arr = new int[size];
    for (size_t i = 0; i < size; ++i) {
        this->arr[i] = a[i];
    }
}

IntArray::IntArray(const IntArray& other) {
    this->size = other.size;
    this->arr = new int[size];
    for (int i = 0; i < size; ++i) {
        arr[i] = other.arr[i];
    }
}

IntArray::~IntArray() {
    delete[] this->arr;
}

IntArray& IntArray::operator = (const IntArray& other) {
    if (this == &other) {
        return *this;
    }
    delete[] arr;
    size = other.size;
    arr = new int[size];
    for (int i = 0; i < size; ++i) {
        arr[i] = other.arr[i];
    }
    return *this;
}

int& IntArray::operator [] (int index) {
    return arr[index];
}

IntArray::operator int() {
    return size;
}

istream& operator >> (istream& in, IntArray& intArray) {
    cout << "- Enter size of array: ";
    in >> intArray.size;
    intArray.arr = new int[intArray.size];
    for (int i = 0; i < intArray.size; ++i) {
        cout << "- Enter element " << i << ": ";
        in >> intArray.arr[i];
    }
    return in;
}

ostream& operator << (ostream& out, const IntArray& intArray) {
    for (int i = 0; i < intArray.size; ++i) {
        out << intArray.arr[i] << " ";
    }
    return out;
}