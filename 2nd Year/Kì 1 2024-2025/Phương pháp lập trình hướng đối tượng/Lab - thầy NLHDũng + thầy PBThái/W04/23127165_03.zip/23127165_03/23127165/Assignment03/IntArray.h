#pragma once
#include <iostream>
using namespace std;

class IntArray {
private:
    int* arr;
    size_t size;

public:
    // Constructor and Destructor
    IntArray();
    IntArray(size_t s);
    IntArray(int* a, size_t s);
    IntArray(const IntArray& other);
    ~IntArray();

    IntArray& operator = (const IntArray& other);

    int& operator [] (int index);

    operator int();

    friend istream& operator >> (istream& in, IntArray& intArray);
    friend ostream& operator << (ostream& out, const IntArray& intArray);
};
