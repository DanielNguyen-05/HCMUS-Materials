#include "Date.h"

bool Date::isLeapYear(int year) {
    return (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);
}

int Date::daysInMonth(int month, int year) {
    if (month == 2) {
        return isLeapYear(year) ? 29 : 28;
    }
    return (month == 4 || month == 6 || month == 9 || month == 11) ? 30 : 31;
}

Date::Date() : day(2), month(11), year(2012) {}

Date::Date(int year) : day(1), month(1), year(year) {}

Date::Date(int year, int month) : day(1), month(month), year(year) {}

Date::Date(int year, int month, int day) : day(day), month(month), year(year) {}

Date::Date(const Date& other) : day(other.day), month(other.month), year(other.year) {}

Date& Date::operator = (const Date& other) {
    if (this != &other) {
        day = other.day;
        month = other.month;
        year = other.year;
    }
    return *this;
}

Date Date::Tomorrow() {
    Date next = *this;
    if (next.day < daysInMonth(next.month, next.year)) {
        next.day++;
    }
    else if (next.month < 12) {
        next.day = 1;
        next.month++;
    }
    else {
        next.day = 1;
        next.month = 1;
        next.year++;
    }
    return next;
}

Date Date::Yesterday() {
    Date previous = *this;
    if (previous.day > 1) {
        previous.day--;
    }
    else if (previous.month > 1) {
        previous.month--;
        previous.day = daysInMonth(previous.month, previous.year);
    }
    else {
        previous.month = 12;
        previous.day = 31;
        previous.year--;
    }
    return previous;
}

Date Date::operator + (int days) {
    Date result = *this;
    for (int i = 0; i < days; i++) {
        result = result.Tomorrow();
    }
    return result;
}

Date Date::operator - (int days) {
    Date result = *this;
    for (int i = 0; i < days; i++) {
        result = result.Yesterday();
    }
    return result;
}

bool Date::operator == (const Date& other) {
    return (day == other.day && month == other.month && year == other.year);
}

bool Date::operator != (const Date& other) {
    return !(*this == other);
}

bool Date::operator >= (const Date& other) {
    return (year > other.year) || (year == other.year && (month > other.month || (month == other.month && day >= other.day)));
}

bool Date::operator <= (const Date& other) {
    return (year < other.year) || (year == other.year && (month < other.month || (month == other.month && day <= other.day)));
}

bool Date::operator > (const Date& other) {
    return !(*this <= other);
}

bool Date::operator < (const Date& other) {
    return !(*this >= other);
}

Date& Date::operator ++ () {
    *this = Tomorrow();
    return *this;
}

Date Date::operator ++ (int) {
    Date temp = *this;
    ++(*this);
    return temp;
}

Date& Date::operator -- () {
    *this = Yesterday();
    return *this;
}

Date Date::operator -- (int) {
    Date temp = *this;
    --(*this);
    return temp;
}

Date::operator int() {
    // from 1/1/2012
    int days = 0;
    for (int i = 2012; i < year; i++) {
        days += isLeapYear(i) ? 366 : 365;
    }
    for (int i = 1; i < month; i++) {
        days += daysInMonth(i, year);
    }
    days += this->day;
    return days;
}

Date::operator long() {
    // from 1/1/1
    long days = 0;
    for (int i = 1; i < year; i++) {
        days += isLeapYear(i) ? 366 : 365;
    }
    for (int i = 1; i < month; i++) {
        days += daysInMonth(i, year);
    }
    days += this->day;
    return days;
}

Date& Date::operator += (int days) {
    for (int i = 0; i < days; i++) {
        *this = Tomorrow();
    }
    return *this;
}

Date& Date::operator -= (int days) {
    for (int i = 0; i < days; i++) {
        *this = Yesterday();
    }
    return *this;
}

ostream& operator << (ostream& os, const Date& date) {
    os << date.day << "/" << date.month << "/" << date.year;
    return os;
}

istream& operator >> (istream& is, Date& date) {
    char delimiter;
    is >> date.day >> delimiter >> date.month >> delimiter >> date.year;
    return is;
}
