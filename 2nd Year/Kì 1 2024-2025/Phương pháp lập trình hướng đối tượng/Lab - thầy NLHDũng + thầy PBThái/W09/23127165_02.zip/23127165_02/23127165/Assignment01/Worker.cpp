#include "Worker.h"

Worker::Worker() : Employee(), itemsProduced(0) {}
Worker::Worker(int id) : Employee(id), itemsProduced(0) {}
Worker::Worker(int id, const string& fullName) : Employee(id, fullName), itemsProduced(0) {}
Worker::Worker(int id, const string& fullName, const string& hireDate) : Employee(id, fullName, hireDate), itemsProduced(0) {}
Worker::Worker(int id, const string& fullName, const string& hireDate, const string& address, int itemsProduced)
    : Employee(id, fullName, hireDate, address), itemsProduced(itemsProduced) {
}

void Worker::input() {
    Employee::input();
    cout << "- Enter Items Produced: ";
    cin >> itemsProduced;
}

void Worker::print() const {
    Employee::print();
    cout << "- Items Produced: " << itemsProduced << "\n- Salary: " << computeSalary() << " VND" << "\n";
}

double Worker::computeSalary() const {
    return itemsProduced * payRate;
}