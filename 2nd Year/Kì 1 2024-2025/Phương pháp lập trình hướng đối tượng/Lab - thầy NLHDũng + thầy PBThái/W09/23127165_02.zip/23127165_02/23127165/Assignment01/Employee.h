#pragma once
#include <iostream>
#include <string>
#include <vector>
#include <limits>
using namespace std;

class Employee {
protected:
    int id;
    string fullName;
    string hireDate;
    string address;

public:
    Employee();
    Employee(int id);
    Employee(int id, const string& fullName);
    Employee(int id, const string& fullName, const string& hireDate);
    Employee(int id, const string& fullName, const string& hireDate, const string& address);

    virtual void input();
    virtual void print() const;
    virtual double computeSalary() const = 0; // Pure virtual method

    virtual ~Employee() = default; // Virtual destructor
};