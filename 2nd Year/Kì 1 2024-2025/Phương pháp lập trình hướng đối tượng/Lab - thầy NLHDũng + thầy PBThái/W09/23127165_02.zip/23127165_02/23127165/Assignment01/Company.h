#pragma once
#include "Worker.h"
#include "OfficeEmployee.h"

class Company {
private:
    vector<Employee*> employees; // Polymorphic array of employees

public:
    ~Company(); // Destructor to free memory
    void inputEmployees();
    void printEmployees() const;
    double computeTotalSalary() const;
    void printHighestSalaryEmployees() const;
};