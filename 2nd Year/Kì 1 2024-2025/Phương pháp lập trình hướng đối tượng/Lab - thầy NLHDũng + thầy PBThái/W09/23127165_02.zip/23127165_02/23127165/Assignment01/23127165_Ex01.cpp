#include "Company.h"

int main() {
    Company company;
    company.inputEmployees();
    company.printEmployees();
    cout << "\n=> Total salary in company: " << company.computeTotalSalary() << " VND" << "\n";
    cout << "------------------" << "\n\n";
    company.printHighestSalaryEmployees();

    return 0;
}