#include "Company.h"

Company::~Company() {
    for (auto emp : employees) {
        delete emp;
    }
}

void Company::inputEmployees() {
    int n;
    cout << "\n- Enter number of employees: ";
    cin >> n;

    for (int i = 0; i < n; ++i) {
        int type;
        cout << "\n- Enter type of employee (1: OfficeEmployee, 2: Worker): ";
        cin >> type;

        Employee* emp = NULL;
        if (type == 1) {
            emp = new OfficeEmployee();
        }
        else if (type == 2) {
            emp = new Worker();
        }
        emp->input();
        employees.push_back(emp);
    }
}

void Company::printEmployees() const {
    for (const auto& emp : employees) {
        emp->print();
        cout << "------------------" << "\n";
    }
}

double Company::computeTotalSalary() const {
    double total = 0;
    for (const auto& emp : employees) {
        total += emp->computeSalary();
    }
    return total;
}

void Company::printHighestSalaryEmployees() const {
    double maxSalary = 0;

    for (const auto& emp : employees) {
        maxSalary = max(maxSalary, emp->computeSalary());
    }

    cout << "Employees with the highest salary:\n";
    for (const auto& emp : employees) {
        if (emp->computeSalary() == maxSalary) {
            emp->print();
            cout << "------------------" << "\n";
        }
    }
}
