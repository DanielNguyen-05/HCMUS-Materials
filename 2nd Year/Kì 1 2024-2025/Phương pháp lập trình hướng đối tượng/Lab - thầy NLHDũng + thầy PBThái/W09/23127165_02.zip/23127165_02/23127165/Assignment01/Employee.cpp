#include "Employee.h"

Employee::Employee() {
    id = 0;
    fullName = "";
    hireDate = "";
    address = "";
}

Employee::Employee(int id) {
    this->id = id;
    fullName = "";
    hireDate = "";
    address = "";
}

Employee::Employee(int id, const string& fullName) {
    this->id = id;
    this->fullName = fullName;
    hireDate = "";
    address = "";
}

Employee::Employee(int id, const string& fullName, const string& hireDate) {
    this->id = id;
    this->fullName = fullName;
    this->hireDate = hireDate;
    address = "";
}
Employee::Employee(int id, const string& fullName, const string& hireDate, const string& address) {
    this->id = id;
    this->fullName = fullName;
    this->hireDate = hireDate;
    this->address = address;
}

void Employee::input() {
    cout << "- Enter ID: ";
    cin >> id;
    cin.ignore(); // Clear input buffer
    cout << "- Enter Full Name: ";
    getline(cin, fullName);
    cout << "- Enter Hire Date (dd/mm/yyy): ";
    getline(cin, hireDate);
    cout << "- Enter Address: ";
    getline(cin, address);
}

void Employee::print() const {
    cout << "ID: " << id << "\nFull Name: " << fullName << "\nHire Date: " << hireDate << "\nAddress: " << address << "\n";
}
