#include "OfficeEmployee.h"

OfficeEmployee::OfficeEmployee() : Employee(), workingDays(0) {}
OfficeEmployee::OfficeEmployee(int id) : Employee(id), workingDays(0) {}
OfficeEmployee::OfficeEmployee(int id, const string& fullName) : Employee(id, fullName), workingDays(0) {}
OfficeEmployee::OfficeEmployee(int id, const string& fullName, const string& hireDate) : Employee(id, fullName, hireDate), workingDays(0) {}
OfficeEmployee::OfficeEmployee(int id, const string& fullName, const string& hireDate, const string& address, int workingDays)
    : Employee(id, fullName, hireDate, address), workingDays(workingDays) {
}

void OfficeEmployee::input() {
    Employee::input();
    cout << "- Enter Working Days: ";
    cin >> workingDays;
}

void OfficeEmployee::print() const {
    Employee::print();
    cout << "Working Days: " << workingDays << "\nSalary: " << computeSalary() << " VND" << "\n";
}

double OfficeEmployee::computeSalary() const {
    return workingDays * payRate;
}