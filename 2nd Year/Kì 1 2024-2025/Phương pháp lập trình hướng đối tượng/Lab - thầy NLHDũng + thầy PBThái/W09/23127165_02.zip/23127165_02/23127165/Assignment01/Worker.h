#pragma once
#include "Employee.h"

// Derived class: Worker
class Worker : public Employee {
private:
    int itemsProduced;
    static constexpr double payRate = 20000; // Static pay rate for Worker

public:
    Worker();
    Worker(int id);
    Worker(int id, const string& fullName);
    Worker(int id, const string& fullName, const string& hireDate);
    Worker(int id, const string& fullName, const string& hireDate, const string& address, int itemsProduced);

    void input() override;
    void print() const override;
    double computeSalary() const override;
};