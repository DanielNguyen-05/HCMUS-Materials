#pragma once
#include "Employee.h"

// Derived class: OfficeEmployee
class OfficeEmployee : public Employee {
private:
    int workingDays;
    static constexpr double payRate = 300000; // Static pay rate for OfficeEmployee

public:
    OfficeEmployee();
    OfficeEmployee(int id);
    OfficeEmployee(int id, const string& fullName);
    OfficeEmployee(int id, const string& fullName, const string& hireDate);
    OfficeEmployee(int id, const string& fullName, const string& hireDate, const string& address, int workingDays);

    void input() override;
    void print() const override;
    double computeSalary() const override;
};