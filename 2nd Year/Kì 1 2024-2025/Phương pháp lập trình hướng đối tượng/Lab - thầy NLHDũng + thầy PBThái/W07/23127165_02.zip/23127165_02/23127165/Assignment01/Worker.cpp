#include "Worker.h"

Worker::Worker() {
    empID = "";
    fullName = "";
    hireDate = "";
    address = "";
    itemsProduced = 0;
}

Worker::Worker(string id, string name, string date, string addr, int items) {
    empID = id;
    fullName = name;
    hireDate = date;
    address = addr;
    itemsProduced = items;
}

Worker::Worker(string id, string name) {
    empID = id;
    fullName = name;
    hireDate = "";
    address = "";
    itemsProduced = 0;
}

Worker::Worker(const Worker& other) {
    empID = other.empID;
    fullName = other.fullName;
    hireDate = other.hireDate;
    address = other.address;
    itemsProduced = other.itemsProduced;
}

Worker::Worker(int items) {
    empID = "";
    fullName = "";
    hireDate = "";
    address = "";
    itemsProduced = items;
}

void Worker::inputInfo() {
    cout << "\n- Enter employee ID: ";
    cin >> empID;
    cout << "- Enter full name: ";
    cin.ignore();
    getline(cin, fullName);
    cout << "- Enter hire date: ";
    cin >> hireDate;
    cout << "- Enter address: ";
    cin.ignore();
    getline(cin, address);
    cout << "- Enter items produced: ";
    cin >> itemsProduced;
}

void Worker::printInfo() {
    cout << "\n- Employee ID: " << empID << "\n";
    cout << "- Full name: " << fullName << "\n";
    cout << "- Hire date: " << hireDate << "\n";
    cout << "- Address: " << address << "\n";
    cout << "- Items produced: " << itemsProduced << "\n";
    cout << "- Salary: " << calculateSalary() << " VND\n";
}

float Worker::calculateSalary() {
    return itemsProduced * PAY_RATE_PER_ITEM;
}

Worker& Worker::operator = (const Worker& other) {
    empID = other.empID;
    fullName = other.fullName;
    hireDate = other.hireDate;
    address = other.address;
    itemsProduced = other.itemsProduced;
    return *this;
}
