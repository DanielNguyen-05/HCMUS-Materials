#pragma once
#include "Worker.h"
#include "OfficeEmployee.h"

class Company {
private:
    vector<Worker> workers;
    vector<OfficeEmployee> officeEmployees;

public:
    Company();
    Company(const vector<OfficeEmployee>& officeEmployees);
    Company(const vector<Worker>& workers);
    Company(const vector<Worker>& workers, const vector<OfficeEmployee>& officeEmployees);
    Company(const Company& other);
    void addWorker(Worker worker);
    void addOfficeEmployee(OfficeEmployee officeEmployee);
    void inputCompanyInfo();
    void printWorkers();
    void printOfficeEmployees();
    void printAllEmployees();
};