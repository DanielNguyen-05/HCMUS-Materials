#include "Company.h"

int main() {
    Company company;
    company.inputCompanyInfo();
    company.printAllEmployees();
    return 0;
}