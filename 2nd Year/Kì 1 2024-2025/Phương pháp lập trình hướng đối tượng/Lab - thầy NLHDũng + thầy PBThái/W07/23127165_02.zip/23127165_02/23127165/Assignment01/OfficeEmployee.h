#pragma once
#include <iostream>
#include <algorithm>
#include <cmath>
#include <string>
#include <vector>
using namespace std;

class OfficeEmployee {
private:
    string empID;
    string fullName;
    string hireDate;
    string address;
    int workingDays;
    const int PAY_RATE_PER_DAY = 300000;

public:
    OfficeEmployee();
    OfficeEmployee(string id, string name, string date, string addr, int days);
    OfficeEmployee(string id, string name);
    OfficeEmployee(const OfficeEmployee& other);
    OfficeEmployee(int days);
    void inputInfo();
    void printInfo();
    float calculateSalary();

    OfficeEmployee& operator = (const OfficeEmployee& other);
};