#include "OfficeEmployee.h"

OfficeEmployee::OfficeEmployee() {
    empID = "";
    fullName = "";
    hireDate = "";
    address = "";
    workingDays = 0;
}

OfficeEmployee::OfficeEmployee(string id, string name, string date, string addr, int days) {
    empID = id;
    fullName = name;
    hireDate = date;
    address = addr;
    workingDays = days;
}

OfficeEmployee::OfficeEmployee(string id, string name) {
    empID = id;
    fullName = name;
    hireDate = "";
    address = "";
    workingDays = 0;
}

OfficeEmployee::OfficeEmployee(const OfficeEmployee& other) {
    empID = other.empID;
    fullName = other.fullName;
    hireDate = other.hireDate;
    address = other.address;
    workingDays = other.workingDays;
}

OfficeEmployee::OfficeEmployee(int days) {
    empID = "";
    fullName = "";
    hireDate = "";
    address = "";
    workingDays = days;
}

void OfficeEmployee::inputInfo() {
    cout << "\n- Enter employee ID: ";
    cin >> empID;
    cout << "- Enter full name: ";
    cin.ignore();
    getline(cin, fullName);
    cout << "- Enter hire date: ";
    cin >> hireDate;
    cout << "- Enter address: ";
    cin.ignore();
    getline(cin, address);
    cout << "- Enter days worked: ";
    cin >> workingDays;
}

void OfficeEmployee::printInfo() {
    cout << "\n- Employee ID: " << empID << "\n";
    cout << "- Full name: " << fullName << "\n";
    cout << "- Hire date: " << hireDate << "\n";
    cout << "- Address: " << address << "\n";
    cout << "- Days worked: " << workingDays << "\n";
    cout << "- Salary: " << calculateSalary() << " VND\n";
}

float OfficeEmployee::calculateSalary() {
    return workingDays * PAY_RATE_PER_DAY;
}

OfficeEmployee& OfficeEmployee::operator = (const OfficeEmployee& other) {
    empID = other.empID;
    fullName = other.fullName;
    hireDate = other.hireDate;
    address = other.address;
    workingDays = other.workingDays;
    return *this;
}