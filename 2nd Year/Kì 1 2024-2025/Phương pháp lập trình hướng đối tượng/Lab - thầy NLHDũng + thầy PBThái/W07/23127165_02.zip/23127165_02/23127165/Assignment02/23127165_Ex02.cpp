#include <iostream>
#include <vector>
#include "BankAccount.h"
#include "SavingBankAccount.h"

using namespace std;

int main() {
    vector<BankAccount> bankAccounts;
    vector<SavingBankAccount> savingAccounts;
    int choice;

    do {
        cout << "\n--- Bank Account Management System ---\n";
        cout << "1. Use Bank Account\n";
        cout << "2. Use Saving Bank Account\n";
        cout << "0. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;
        cin.ignore();

        switch (choice) {
        case 1: {
            int bankChoice;
            do {
                cout << "\n--- Bank Account ---\n";
                cout << "1. Add a Bank Account\n";
                cout << "2. Print All Bank Accounts\n";
                cout << "3. Perform Operations on a Bank Account\n";
                cout << "0. Back to Main Menu\n";
                cout << "Enter your choice: ";
                cin >> bankChoice;
                cin.ignore();

                switch (bankChoice) {
                case 1: {
                    cout << "\nInputting a new Bank Account:\n";
                    BankAccount account;
                    try {
                        account.inputBankAccount();
                        bankAccounts.push_back(account);
                        cout << "Bank account added successfully!\n";
                    }
                    catch (const invalid_argument& e) {
                        cout << "Error: " << e.what();
                    }
                    break;
                }
                case 2: {
                    cout << "\nPrinting all Bank Accounts:\n";
                    for (const auto& account : bankAccounts) {
                        account.printBankAccount();
                    }
                    break;
                }
                case 3: {
                    int accountIndex;
                    cout << "\nEnter the index of the Bank Account to perform operations on (0-based): ";
                    cin >> accountIndex;

                    if (accountIndex >= 0 && accountIndex < bankAccounts.size()) {
                        BankAccount& account = bankAccounts[accountIndex];
                        int operationChoice;

                        do {
                            cout << "\n1. Deposit\n";
                            cout << "2. Withdraw\n";
                            cout << "3. Check Balance\n";
                            cout << "0. Back to Account Menu\n";
                            cout << "Enter your choice: ";
                            cin >> operationChoice;

                            switch (operationChoice) {
                            case 1: {
                                double amount;
                                cout << "Enter deposit amount: ";
                                cin >> amount;
                                account.depositBankAccount(amount);
                                break;
                            }
                            case 2: {
                                double amount;
                                cout << "Enter withdrawal amount: ";
                                cin >> amount;
                                account.withdrawBankAccount(amount);
                                break;
                            }
                            case 3: {
                                account.checkBalance();
                                break;
                            }
                            case 0:
                                break;
                            default:
                                cout << "Invalid choice!\n";
                                break;
                            }
                        } while (operationChoice != 0);
                    }
                    else {
                        cout << "Invalid account index!\n";
                    }
                    break;
                }
                case 0:
                    break;
                default:
                    cout << "Invalid choice!\n";
                    break;
                }
            } while (bankChoice != 0);
            break;
        }
        case 2: {
            int savingChoice;
            do {
                cout << "\n--- Saving Bank Account ---\n";
                cout << "1. Add a Saving Bank Account\n";
                cout << "2. Print All Saving Bank Accounts\n";
                cout << "3. Perform Operations on a Saving Bank Account\n";
                cout << "0. Back to Main Menu\n";
                cout << "Enter your choice: ";
                cin >> savingChoice;
                cin.ignore();

                switch (savingChoice) {
                case 1: {
                    cout << "\nInputting a new Saving Bank Account:\n";
                    SavingBankAccount savingAccount;
                    savingAccount.inputSavingAccount();
                    savingAccounts.push_back(savingAccount);
                    cout << "Saving bank account added successfully!\n";
                    break;
                }
                case 2: {
                    cout << "\nPrinting all Saving Bank Accounts:\n";
                    for (const auto& account : savingAccounts) {
                        account.printSavingAccount();
                    }
                    break;
                }
                case 3: {
                    int accountIndex;
                    cout << "\nEnter the index of the Saving Bank Account to perform operations on (0-based): ";
                    cin >> accountIndex;

                    if (accountIndex >= 0 && accountIndex < savingAccounts.size()) {
                        SavingBankAccount& account = savingAccounts[accountIndex];
                        int operationChoice;

                        do {
                            cout << "\n1. Deposit\n";
                            cout << "2. Withdraw\n";
                            cout << "3. Withdraw Immediately\n";
                            cout << "4. Check Balance\n";
                            cout << "5. Check Interest\n";
                            cout << "0. Back to Account Menu\n";
                            cout << "Enter your choice: ";
                            cin >> operationChoice;

                            switch (operationChoice) {
                            case 1: {
                                double amount;
                                cout << "Enter deposit amount: ";
                                cin >> amount;
                                account.depositSavingAccount(amount);
                                break;
                            }
                            case 2: {
                                double amount;
                                cout << "Enter withdrawal amount: ";
                                cin >> amount;
                                account.withdrawSavingAccount(amount);
                                break;
                            }
                            case 3: {
                                double amount;
                                cout << "Enter withdrawal amount: ";
                                cin >> amount;
                                account.withdrawImmediately(amount);
                                break;
                            }
                            case 4: {
                                account.checkBalanceSavingAccount();
                                break;
                            }
                            case 5: {
                                account.checkInterest();
                                break;
                            }
                            case 0:
                                break;
                            default:
                                cout << "Invalid choice!\n";
                                break;
                            }
                        } while (operationChoice != 0);
                    }
                    else {
                        cout << "Invalid account index!\n";
                    }
                    break;
                }
                case 0:
                    break;
                default:
                    cout << "Invalid choice!\n";
                    break;
                }
            } while (savingChoice != 0);
            break;
        }
        case 0:
            cout << "Exiting...\n";
            break;
        default:
            cout << "Invalid choice! Please try again.\n";
            break;
        }
    } while (choice != 0);

    return 0;
}
