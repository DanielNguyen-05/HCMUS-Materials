#include "Company.h"

Company::Company() {
    workers = vector<Worker>();
    officeEmployees = vector<OfficeEmployee>();
}

Company::Company(const vector<OfficeEmployee>& officeEmployees) {
    this->officeEmployees = officeEmployees;
}

Company::Company(const vector<Worker>& workers) {
    this->workers = workers;
}

Company::Company(const vector<Worker>& workers, const vector<OfficeEmployee>& officeEmployees) {
    this->workers = workers;
    this->officeEmployees = officeEmployees;
}

Company::Company(const Company& other) {
    workers = other.workers;
    officeEmployees = other.officeEmployees;
}

void Company::addWorker(Worker worker) {
    workers.push_back(worker);
}

void Company::addOfficeEmployee(OfficeEmployee officeEmployee) {
    officeEmployees.push_back(officeEmployee);
}

void Company::printWorkers() {
    for (int i = 0; i < workers.size(); i++) {
        workers[i].printInfo();
    }
}

void Company::printOfficeEmployees() {
    for (int i = 0; i < officeEmployees.size(); i++) {
        officeEmployees[i].printInfo();
    }
}

void Company::printAllEmployees() {
    cout << "\n- OFFICE EMPLOYEES: ";
    printOfficeEmployees();
    cout << "\n- WORKERS: ";
    printWorkers();
}

void Company::inputCompanyInfo() {
    int numWorkers, numOfficeEmployees;

    cout << "\n- Enter the number of office employees: ";
    cin >> numOfficeEmployees;
    cout << "\n- Enter the number of workers: ";
    cin >> numWorkers;

    for (int i = 0; i < numOfficeEmployees; i++) {
        cout << "\n ENTER INFO FOR OFFICE EMPLOYEE " << i + 1 << ": ";
        OfficeEmployee tmp;
        tmp.inputInfo();
        officeEmployees.push_back(tmp);
    }

    for (int i = 0; i < numWorkers; i++) {
        cout << "\n ENTER INFO FOR WORKER " << i + 1 << ": ";
        Worker tmp;
        tmp.inputInfo();
        workers.push_back(tmp);
    }
    Company company(workers, officeEmployees);
}
