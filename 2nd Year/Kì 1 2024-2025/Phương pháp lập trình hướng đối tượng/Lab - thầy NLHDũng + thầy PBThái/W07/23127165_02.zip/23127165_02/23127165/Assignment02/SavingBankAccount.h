#pragma once
#include <iostream>
#include <string>
#include <stdexcept>
#include <cmath>
using namespace std;

class SavingBankAccount {
private:
    string accountNumber;
    string ownerName;
    string socialID;
    double balance;
    double annualInterestRate; // e.g., 0.06 for 6% annual interest
    int period;                // in months (e.g., 1, 2, 3, 6, or 12)
    int savingMonths;          // number of saving months until now
    bool isFreePeriod;         // if the account has been withdrawn immediately

public:
    SavingBankAccount();
    void inputSavingAccount();
    void printSavingAccount() const;
    void depositSavingAccount(double amount);
    void withdrawSavingAccount(double amount);
    void withdrawImmediately(double amount);
    void checkBalanceSavingAccount();
    void checkInterest();
    double calculateInterest();
};
