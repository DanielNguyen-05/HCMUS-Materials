#include "SavingBankAccount.h"

SavingBankAccount::SavingBankAccount() {
    accountNumber = "";
    ownerName = "";
    socialID = "";
    balance = 0;
    annualInterestRate = 0;
    period = 0;
    savingMonths = 0;
    isFreePeriod = false;
}

void SavingBankAccount::inputSavingAccount() {
    cout << "Enter account number: ";
    getline(cin, accountNumber);

    cout << "Enter owner's name: ";
    getline(cin, ownerName);

    cout << "Enter social ID of owner: ";
    getline(cin, socialID);

    do {
        cout << "Enter initial balance (must be non-negative): ";
        cin >> balance;
        if (balance < 0) {
            cout << "Invalid balance. Please enter a non-negative value.\n";
        }
    } while (balance < 0);

    do {
        cout << "Enter annual interest rate (e.g., 0.06 for 6%, between 0 and 1): ";
        cin >> annualInterestRate;
        if (annualInterestRate < 0 || annualInterestRate > 1) {
            cout << "Invalid interest rate. Please enter a value between 0 and 1.\n";
        }
    } while (annualInterestRate < 0 || annualInterestRate > 1);

    do {
        cout << "Enter saving period in months (must be positive): ";
        cin >> period;
        if (period <= 0) {
            cout << "Invalid period. Please enter a positive integer.\n";
        }
    } while (period <= 0);

    do {
        cout << "Enter number of saving months until now (must be non-negative): ";
        cin >> savingMonths;
        if (savingMonths < 0) {
            cout << "Invalid saving months. Please enter a non-negative value.\n";
        }
    } while (savingMonths < 0);
    cin.ignore();
    isFreePeriod = false;
}


void SavingBankAccount::printSavingAccount() const {
    cout << "\n- Account Number: " << accountNumber << "\n"
        << "- Owner's Name: " << ownerName << "\n"
        << "- Social ID: " << socialID << "\n"
        << "- Balance: " << balance << " VND\n"
        << "- Annual Interest Rate: " << annualInterestRate * 100 << "%\n"
        << "- Period: " << period << " months\n"
        << "- Saving Months: " << savingMonths << "\n"
        << "- Account Type: " << (isFreePeriod ? "Free-period" : "Fixed-period") << "\n\n";
}

void SavingBankAccount::depositSavingAccount(double amount) {
    if (savingMonths < period) {
        cout << "Cannot deposit. Number of saving months is less than the period. Open a new saving account.\n";
    }
    else {
        balance += amount;
        cout << "Deposited " << amount << " VND successfully.\n";
    }
}

void SavingBankAccount::withdrawSavingAccount(double amount) {
    if (savingMonths < period) {
        cout << "Cannot withdraw. Number of saving months is less than the period.\n";
    }
    else if (amount > balance) {
        cout << "Insufficient balance for withdrawal.\n";
    }
    else {
        balance -= amount;
        cout << "Withdrawn " << amount << " VND successfully.\n";
    }
}

void SavingBankAccount::withdrawImmediately(double amount) {
    if (amount > balance) {
        cout << "Insufficient balance for immediate withdrawal.\n";
    }
    else {
        isFreePeriod = true; // Convert to free-period account
        annualInterestRate = 0.02; // Change interest rate to 2%
        balance -= amount;
        cout << "Withdrawn " << amount << " VND immediately. Account converted to free-period.\n";
    }
}

void SavingBankAccount::checkBalanceSavingAccount() {
    double interest = calculateInterest();
    cout << "=> Current Balance (including interest): " << (balance + interest) << " VND\n";
}

void SavingBankAccount::checkInterest() {
    double interest = calculateInterest();
    cout << "Current Interest: " << interest << " VND\n";
}

double SavingBankAccount::calculateInterest() {
    if (isFreePeriod) {
        // Free-period interest: simple interest calculation
        return balance * (annualInterestRate / 12) * savingMonths;
    }
    else {
        // Fixed-period interest: compound interest calculation
        int monthsToConsider = min(savingMonths, period);
        double monthlyRate = annualInterestRate / 12;
        return balance * pow(1 + monthlyRate, monthsToConsider) - balance;
    }
}
