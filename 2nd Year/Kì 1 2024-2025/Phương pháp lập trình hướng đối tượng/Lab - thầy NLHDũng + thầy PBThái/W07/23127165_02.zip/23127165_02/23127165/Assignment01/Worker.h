#pragma once
#include <iostream>
#include <algorithm>
#include <cmath>
#include <string>
#include <vector>
using namespace std;

class Worker {
private:
    string empID;
    string fullName;
    string hireDate;
    string address;
    int itemsProduced;
    const int PAY_RATE_PER_ITEM = 20000;

public:
    Worker();
    Worker(string id, string name, string date, string addr, int items);
    Worker(string id, string name);
    Worker(const Worker& other);
    Worker(int items);
    void inputInfo();
    void printInfo();
    float calculateSalary();

    Worker& operator = (const Worker& other);
};