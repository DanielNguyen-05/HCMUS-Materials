#include "BankAccount.h"

BankAccount::BankAccount() {
    accountNumber = "";
    ownerName = "";
    socialID = "";
    balance = 0;
}

void BankAccount::inputBankAccount() {
    cout << "\n- Enter account number: ";
    getline(cin, accountNumber);

    cout << "- Enter owner's name: ";
    getline(cin, ownerName);

    cout << "- Enter social ID of owner: ";
    cin >> socialID;

    cout << "- Enter initial balance: ";
    cin >> balance;
    cin.ignore();

    if (balance < 50000.0) {
        throw invalid_argument("Initial balance must be at least 50,000 VND !!!\n");
    }
}

void BankAccount::printBankAccount() const {
    cout << "- Account Number: " << accountNumber << "\n"
        << "- Owner's Name: " << ownerName << "\n"
        << "- Social ID: " << socialID << "\n"
        << "- Balance: " << balance << " VND\n\n";
}

void BankAccount::depositBankAccount(double amount) {
    if (amount > 0) {
        balance += amount;
        cout << "=> Deposited " << amount << " VND successfully.\n";
    }
    else {
        throw invalid_argument("Deposit amount must be positive !!!\n");
    }
}

void BankAccount::withdrawBankAccount(double amount) {
    if (amount > 0) {
        if (balance - amount >= 50000.0) {
            balance -= amount;
            cout << "Withdrawn " << amount << " VND successfully.\n";
        }
        else {
            cout << "Withdrawal failed. Minimum balance of 50,000 VND must be maintained.\n";
        }
    }
    else {
        cout << "Withdrawal amount must be positive.\n";
    }
}

void BankAccount::checkBalance() {
    cout << "=> Current Balance: " << balance << " VND\n";
}