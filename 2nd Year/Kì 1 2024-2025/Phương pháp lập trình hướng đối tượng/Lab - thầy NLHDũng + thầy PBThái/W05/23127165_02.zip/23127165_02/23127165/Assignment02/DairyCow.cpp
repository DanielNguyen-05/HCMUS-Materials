#include "DairyCow.h"

DairyCow::DairyCow() {
    this->identifier = 0;
    this->weight = 0;
    this->age = 0;
}

DairyCow::DairyCow(int identifier, float weight, float age) {
    if (!isPositive(weight) || !isPositive(age)) {
        throw std::invalid_argument("Invalid argument");
    }
    this->identifier = identifier;
    this->weight = weight;
    this->age = age;
}

DairyCow::DairyCow(const DairyCow& cow) {
    this->identifier = cow.identifier;
    this->weight = cow.weight;
    this->age = cow.age;
}

DairyCow::~DairyCow() {
    // cout << "DairyCow destructor" << "\n";
}

int DairyCow::getIdentifier() const {
    return this->identifier;
}

float DairyCow::getWeight() const {
    return this->weight;
}

float DairyCow::getAge() const {
    return this->age;
}

void DairyCow::setWeight(float weight) {
    if (!isPositive(weight)) {
        throw std::invalid_argument("Invalid argument");
    }
    this->weight = weight;
}

void DairyCow::setAge(float age) {
    if (!isPositive(age)) {
        throw std::invalid_argument("Invalid argument");
    }
    this->age = age;
}

string DairyCow::ToString(const DairyCow& cow) {
    stringstream ss;
    ss << "Identifier: " << cow.identifier << ", Weight: " << cow.weight << ", Age: " << cow.age;
    return ss.str();
}

ostream& operator << (ostream& os, const DairyCow& cow) {
    os << "Identifier: " << cow.identifier << ", Weight: " << cow.weight << ", Age: " << cow.age;
    return os;
}

DairyCow& DairyCow::operator = (const DairyCow& cow) {
    this->identifier = cow.identifier;
    this->weight = cow.weight;
    this->age = cow.age;
    return *this;
}

bool DairyCow::isPositive(float number) {
    return number > 0;
}
