#pragma once
#include <iostream>
#include <string>
#include <sstream>
#include <cmath>
#include <algorithm>
#include <vector>
using namespace std;

class DairyCow {
private:
    int identifier;
    float weight;
    float age;
public:
    // Constructor and Destructor
    DairyCow();
    DairyCow(int identifieer, float weight, float age);
    DairyCow(const DairyCow& cow);
    ~DairyCow();

    // Getters
    int getIdentifier() const;
    float getWeight() const;
    float getAge() const;

    // Setters
    void setWeight(float weight);
    void setAge(float age);

    // Output all information of a cow
    string ToString(const DairyCow& cow);

    // Operators
    friend ostream& operator << (ostream& os, const DairyCow& cow);
    DairyCow& operator = (const DairyCow& cow);

    // Check if a number is positive
    bool isPositive(float number);
};

