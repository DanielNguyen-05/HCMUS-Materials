#include "Fraction.h"

Fraction::Fraction() {
    numerator = 0;
    denominator = 1;
}

Fraction::Fraction(int numerator, int denominator) {
    if (denominator == 0) {
        throw invalid_argument("Denominator cannot be zero");
    }
    if (denominator < 0) {
        this->numerator = -numerator;
        this->denominator = -denominator;
    }
    else {
        this->numerator = numerator;
        this->denominator = denominator;
    }
}

Fraction::Fraction(const Fraction& fraction) {
    this->numerator = fraction.numerator;
    this->denominator = fraction.denominator;
}

Fraction& Fraction::operator = (const Fraction& other) {
    this->numerator = other.numerator;
    this->denominator = other.denominator;
    return *this;
}

Fraction Fraction::operator + (const Fraction& other) {
    int num = this->numerator * other.denominator + other.numerator * this->denominator;
    int den = this->denominator * other.denominator;
    return Fraction(num, den);
}

Fraction Fraction::operator - (const Fraction& other) {
    int num = this->numerator * other.denominator - other.numerator * this->denominator;
    int den = this->denominator * other.denominator;
    return Fraction(num, den);
}

Fraction Fraction::operator * (const Fraction& other) {
    int num = this->numerator * other.numerator;
    int den = this->denominator * other.denominator;
    return Fraction(num, den);
}

Fraction Fraction::operator / (const Fraction& other) {
    int num = this->numerator * other.denominator;
    int den = this->denominator * other.numerator;
    return Fraction(num, den);
}

bool Fraction::operator == (const Fraction& other) {
    double result1 = (double)this->numerator / this->denominator;
    double result2 = (double)other.numerator / other.denominator;
    return abs(result1 - result2) < 1e-6;
}

bool Fraction::operator != (const Fraction& other) {
    return !(*this == other);
}

bool Fraction::operator >= (const Fraction& other) {
    double result1 = (double)this->numerator / this->denominator;
    double result2 = (double)other.numerator / other.denominator;
    return result1 >= result2;
}

bool Fraction::operator <= (const Fraction& other) {
    double result1 = (double)this->numerator / this->denominator;
    double result2 = (double)other.numerator / other.denominator;
    return result1 <= result2;
}

bool Fraction::operator > (const Fraction& other) {
    double result1 = (double)this->numerator / this->denominator;
    double result2 = (double)other.numerator / other.denominator;
    return result1 > result2;
}

bool Fraction::operator < (const Fraction& other) {
    double result1 = (double)this->numerator / this->denominator;
    double result2 = (double)other.numerator / other.denominator;
    return result1 < result2;
}

Fraction& Fraction::operator += (const Fraction& other) {
    *this = *this + other;
    return *this;
}

Fraction& Fraction::operator -= (const Fraction& other) {
    *this = *this - other;
    return *this;
}

Fraction& Fraction::operator *= (const Fraction& other) {
    *this = *this * other;
    return *this;
}

Fraction& Fraction::operator /= (const Fraction& other) {
    *this = *this / other;
    return *this;
}

Fraction Fraction::operator + (int number) {
    return *this + Fraction(number, 1);
}

Fraction Fraction::operator - (int number) {
    return *this - Fraction(number, 1);
}

Fraction operator + (int number, const Fraction& fraction) {
    return Fraction(number, 1) + fraction;
}

Fraction operator * (int number, const Fraction& fraction) {
    return Fraction(number, 1) * fraction;
}

Fraction& Fraction::operator ++ () {
    *this += Fraction(1, 1);
    return *this;
}

Fraction Fraction::operator ++ (int) {
    Fraction temp = *this;
    *this += Fraction(1, 1);
    return temp;
}

Fraction& Fraction::operator -- () {
    *this -= Fraction(1, 1);
    return *this;
}

Fraction Fraction::operator -- (int) {
    Fraction temp = *this;
    *this -= Fraction(1, 1);
    return temp;
}

ostream& operator << (ostream& os, const Fraction& fraction) {
    os << fraction.numerator << "/" << fraction.denominator;
    return os;
}

Fraction::operator float() const {
    return (float)numerator / denominator;
}

Fraction::~Fraction() {
    // cout << "Destructor called\n";
}

string Fraction::toString() const {
    ostringstream oss;
    oss << numerator << "/" << denominator;
    return oss.str();
}