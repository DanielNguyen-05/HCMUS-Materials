#include "ABCFarm.h"

void ABCFarm::Input() {
    int n;
    cout << "\n\t INPUT FOR COWS \n";
    cout << "- Enter the number of cows: ";
    cin >> n;
    cout << "\n";
    for (int i = 0; i < n; i++) {
        int identifier;
        float weight, age;
        cout << "- Enter the identifier of cow " << i + 1 << ": ";
        cin >> identifier;
        cout << "- Enter the weight of cow " << i + 1 << ": ";
        cin >> weight;
        cout << "- Enter the age of cow " << i + 1 << ": ";
        cin >> age;
        cout << "\n";
        DairyCow cow(identifier, weight, age);
        cows.push_back(cow);
    }

    cout << "\n\t INPUT FOR GOATS \n";
    cout << "- Enter the number of goats: ";
    cin >> n;
    cout << "\n";
    for (int i = 0; i < n; i++) {
        int identifier;
        float weight, age;
        cout << "- Enter the identifier of goat " << i + 1 << ": ";
        cin >> identifier;
        cout << "- Enter the weight of goat " << i + 1 << ": ";
        cin >> weight;
        cout << "- Enter the age of goat " << i + 1 << ": ";
        cin >> age;
        cout << "\n";
        Goat goat(identifier, weight, age);
        goats.push_back(goat);
    }
}

void ABCFarm::Output() {
    cout << "\n\t OUTPUT FOR COWS\n";
    for (int i = 0; i < cows.size(); i++) {
        cout << cows[i] << "\n";
    }

    cout << "\n\t OUTPUT FOR GOATS\n";
    for (int i = 0; i < goats.size(); i++) {
        cout << goats[i] << "\n";
    }
}

void ABCFarm::OutputByAge(int min, int max) {
    cout << "\n\t OUTPUT BY AGE\n";
    cout << "- Cows: " << "\n";
    for (int i = 0; i < cows.size(); i++) {
        if (cows[i].getAge() >= min && cows[i].getAge() <= max) {
            cout << "  + " << cows[i] << "\n";
        }
    }

    cout << "Goats: " << "\n";
    for (int i = 0; i < goats.size(); i++) {
        if (goats[i].getAge() >= min && goats[i].getAge() <= max) {
            cout << "  + " << goats[i] << "\n";
        }
    }
}


