#pragma once
#include <iostream>
#include <string>
#include <sstream>
#include <cmath>
#include <algorithm>
using namespace std;

class Fraction {
private:
    int numerator;
    int denominator;
public:
    Fraction();
    Fraction(int numerator, int denominator);
    Fraction(const Fraction& fraction);

    Fraction& operator = (const Fraction& other);
    Fraction operator + (const Fraction& other);
    Fraction operator - (const Fraction& other);
    Fraction operator * (const Fraction& other);
    Fraction operator / (const Fraction& other);

    bool operator == (const Fraction& other);
    bool operator != (const Fraction& other);
    bool operator >= (const Fraction& other);
    bool operator <= (const Fraction& other);
    bool operator > (const Fraction& other);
    bool operator < (const Fraction& other);

    Fraction& operator += (const Fraction& other);
    Fraction& operator -= (const Fraction& other);
    Fraction& operator *= (const Fraction& other);
    Fraction& operator /= (const Fraction& other);

    Fraction operator + (int number);
    Fraction operator - (int number);
    friend Fraction operator + (int number, const Fraction& fraction);
    friend Fraction operator * (int number, const Fraction& fraction);

    Fraction& operator ++ ();   // ++f
    Fraction operator ++ (int); // f++
    Fraction& operator -- ();
    Fraction operator -- (int);

    friend ostream& operator << (ostream& os, const Fraction& fraction);
    string toString() const;

    operator float() const;

    ~Fraction();
};

