#include "MyVector.hpp"

int main() {
    // Vector of integers
    cout << "\n\t VECTOR OF INTEGERS\n";
    MyVector<int> intVector;
    intVector.add(5);
    intVector.add(10);
    intVector.addRange(new int[3] {15, 20, 25}, 3);
    intVector.setItem(100, 1);
    cout << "- Item at index 1: " << intVector.getItem(1) << "\n";
    intVector.insert(50, 2);
    cout << "- Index of 100: " << intVector.indexOf(100) << "\n";
    cout << "- Last index of 15: " << intVector.lastIndexOf(15) << "\n";
    intVector.remove(20);
    intVector.removeAt(2);
    intVector.reverse();
    cout << "- Contains 10: " << (intVector.contains(10) ? "Yes" : "No") << "\n";
    cout << "- Size: " << intVector.getSize() << "\n";
    int* arr = new int[intVector.getSize()];
    int size;
    intVector.toArray(arr, size);
    for (int i = 0; i < size; i++) {
        cout << arr[i] << " ";
    }
    cout << "\n";
    intVector.sortAsc();
    cout << "- Ascending: " << intVector.toString() << "\n";
    intVector.sortDesc();
    cout << "- Descending: " << intVector.toString() << "\n";
    intVector.clear();
    cout << "- Size after clear: " << intVector.getSize() << "\n\n";

    // Vector of fractions
    cout << "\n\t VECTOR OF FRACTIONS\n";
    MyVector<Fraction> fractionVector;
    fractionVector.add(Fraction(1, 2));
    fractionVector.add(Fraction(2, 3));
    fractionVector.addRange(new Fraction[2]{ Fraction(3, 4), Fraction(4, 5) }, 2);
    fractionVector.setItem(Fraction(5, 6), 1);
    cout << "- Item at index 1: " << fractionVector.getItem(1).toString() << "\n";
    fractionVector.insert(Fraction(6, 7), 2);
    cout << "- Index of (5/6): " << fractionVector.indexOf(Fraction(5, 6)) << "\n";
    cout << "- Last index of (3/4): " << fractionVector.lastIndexOf(Fraction(3, 4)) << "\n";
    fractionVector.remove(Fraction(4, 5));
    fractionVector.removeAt(2);
    fractionVector.reverse();
    cout << "- Contains (2/3): " << (fractionVector.contains(Fraction(2, 3)) ? "Yes" : "No") << "\n";
    cout << "- Size: " << fractionVector.getSize() << "\n";
    Fraction* fractionArr = new Fraction[fractionVector.getSize()];
    fractionVector.toArray(fractionArr, size);
    for (int i = 0; i < size; i++) {
        cout << fractionArr[i].toString() << " ";
    }
    cout << "\n";
    fractionVector.sortAsc();
    cout << "- Ascending: " << fractionVector.toString() << "\n";
    fractionVector.sortDesc();
    cout << "- Descending: " << fractionVector.toString() << "\n";
    fractionVector.clear();
    cout << "- Size after clear: " << fractionVector.getSize() << "\n\n";

    delete[] arr;
    delete[] fractionArr;
    return 0;
}
