#include "Goat.h"

Goat::Goat() {
    this->identifier = 0;
    this->weight = 0;
    this->age = 0;
}

Goat::Goat(int identifier, float weight, float age) {
    if (!isPositive(weight) || !isPositive(age)) {
        throw std::invalid_argument("Invalid argument");
    }
    this->identifier = identifier;
    this->weight = weight;
    this->age = age;
}

Goat::Goat(const Goat& cow) {
    this->identifier = cow.identifier;
    this->weight = cow.weight;
    this->age = cow.age;
}

Goat::~Goat() {
    // cout << "Goat destructor" << "\n";
}

int Goat::getIdentifier() const {
    return this->identifier;
}

float Goat::getWeight() const {
    return this->weight;
}

float Goat::getAge() const {
    return this->age;
}

void Goat::setWeight(float weight) {
    if (!isPositive(weight)) {
        throw std::invalid_argument("Invalid argument");
    }
    this->weight = weight;
}

void Goat::setAge(float age) {
    if (!isPositive(age)) {
        throw std::invalid_argument("Invalid argument");
    }
    this->age = age;
}

string Goat::ToString(const Goat& cow) {
    stringstream ss;
    ss << "Identifier: " << cow.identifier << ", Weight: " << cow.weight << ", Age: " << cow.age;
    return ss.str();
}

ostream& operator << (ostream& os, const Goat& cow) {
    os << "Identifier: " << cow.identifier << ", Weight: " << cow.weight << ", Age: " << cow.age;
    return os;
}

Goat& Goat::operator = (const Goat& cow) {
    this->identifier = cow.identifier;
    this->weight = cow.weight;
    this->age = cow.age;
    return *this;
}

bool Goat::isPositive(float number) {
    return number > 0;
}

