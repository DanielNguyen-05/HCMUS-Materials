#include "ABCFarm.h"

int main() {
    ABCFarm farm;
    int min, max;
    farm.Input();
    farm.Output();
    cout << "\n- Enter the minimum age: ";
    cin >> min;
    cout << "\n- Enter the maximum age: ";
    cin >> max;
    farm.OutputByAge(min, max);
    return 0;
}