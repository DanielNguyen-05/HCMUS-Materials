#include "headerFile.h"

int main() {
    Fraction frac1, frac2;
    int comparison;

    // Input two fractions
    cout << "\n\t ENTER THE FIRST FRACTION:\n";
    input(frac1);
    cout << "\n\t ENTER THE SECOND FRACTION:\n";
    input(frac2);
    int choice;
    do {
        cout << "\n\t CHOOSE YOUR REQUEST:\n";
        cout << "1. Output the fractions after being reduced\n";
        cout << "2. Add 2 fractions\n";
        cout << "3. Subtract 2 fractions\n";
        cout << "4. Multiply 2 fractions\n";
        cout << "5. Divide 2 fractions\n";
        cout << "6. Compare 2 fractions\n";
        cout << "7. Check if these fractions are positive, negative or zero\n";
        cout << "8. Exit\n";
        cout << "\n- Enter your choice: ";
        cin >> choice;

        cout << "\n";
        switch (choice) {
        case 1:
            cout << "=> First fraction after being reduced: ";
            output(frac1);
            cout << "=> Second fraction after being reduced: ";
            output(frac2);
            break;
        case 2:
            cout << "=> Sum of two fractions: ";
            output(add(frac1, frac2));
            break;
        case 3:
            cout << "=> Substract 2 fractions: ";
            output(subtract(frac1, frac2));
            break;
        case 4:
            cout << "=> Multiply 2 fractions: ";
            output(multiply(frac1, frac2));
            break;
        case 5:
            try {
                cout << "=> Divide 2 fractions: ";
                output(divide(frac1, frac2));
            } catch (const invalid_argument& e) {
                cout << e.what(); 
            }
            break;
        case 6:
            comparison = compare(frac1, frac2);
            if (comparison == 0) cout << "=> The fractions are equal.\n";
            else if (comparison == 1) cout << "=> The first fraction is greater than the second.\n";
            else cout << "=> The first fraction is less than the second.\n";
            break;
        case 7:
            cout << "=> The first fraction is ";
            if (isPositive(frac1)) cout << "positive.\n";
            else if (isNegative(frac1)) cout << "negative.\n";
            else cout << "zero.\n";

            cout << "=> The second fraction is ";
            if (isPositive(frac2)) cout << "positive.\n";
            else if (isNegative(frac2)) cout << "negative.\n";
            else cout << "zero.\n";
            break;
        case 8:
            cout << "=> Thank you for using the program!\n";
            break;
        default:
            cout << "=> Invalid choice! Please enter a valid choice!\n";
            break;
        }
    } while (choice != 8);


    return 0;
}
