#include <iostream>
#include <limits>
using namespace std;

struct Fraction {
    int numerator;
    int denominator;
};

// this function is used to input a fraction
void input(Fraction& frac);

// this function is used to output a fraction
void output(const Fraction& frac);

// this function is used to add two fractions
Fraction add(const Fraction& frac1, const Fraction& frac2);

// this function is used to subtract two fractions
Fraction subtract(const Fraction& frac1, const Fraction& frac2);

// this function is used to multiply two fractions
Fraction multiply(const Fraction& frac1, const Fraction& frac2);

// this function is used to divide two fractions
Fraction divide(const Fraction& frac1, const Fraction& frac2);

// this function is used to reduce a fraction
Fraction reduce(Fraction& frac);

// this function is used to compare two fractions
int compare(const Fraction& frac1, const Fraction& frac2);

// this function is used to check if a fraction is positive
bool isPositive(const Fraction& frac);

// this function is used to check if a fraction is negative
bool isNegative(const Fraction& frac);

// this function is used to check if a fraction is zero
bool isZero(const Fraction& frac);

// this function is used to calculate the greatest common divisor of two numbers
int gcd(int a, int b);
