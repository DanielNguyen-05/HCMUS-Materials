#include "headerFile.h"

void input(Fraction& frac) {
    cout << "- Enter numerator: ";
    while (!(cin >> frac.numerator)) {
        cout << "\nInvalid input! Please enter a valid integer: ";
        cin.clear(); 
        cin.ignore(numeric_limits<streamsize>::max(), '\n'); 
    }

    cout << "- Enter denominator: ";
    while (!(cin >> frac.denominator) || frac.denominator == 0) {
        if (frac.denominator == 0) {
            cout << "\nDenominator cannot be zero! Enter again: ";
        } else {
            cout << "\nInvalid input! Please enter a valid integer: ";
        }
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n'); 
    }
    reduce(frac);
}

void output(const Fraction& frac) {
    if (frac.denominator == 1) {
        cout << frac.numerator << "\n";
    } else {
        cout << frac.numerator << "/" << frac.denominator << "\n";
    }
}

Fraction add(const Fraction& frac1, const Fraction& frac2) {
    int num = frac1.numerator * frac2.denominator + frac2.numerator * frac1.denominator;
    int denom = frac1.denominator * frac2.denominator;
    Fraction result{num, denom};
    result = reduce(result);
    return result;
}

Fraction subtract(const Fraction& frac1, const Fraction& frac2) {
    int num = frac1.numerator * frac2.denominator - frac2.numerator * frac1.denominator;
    int denom = frac1.denominator * frac2.denominator;
    Fraction result{num, denom};
    result = reduce(result);
    return result;
}

Fraction multiply(const Fraction& frac1, const Fraction& frac2) {
    int num = frac1.numerator * frac2.numerator;
    int denom = frac1.denominator * frac2.denominator;
    Fraction result{num, denom};
    result = reduce(result);
    return result;
}

Fraction divide(const Fraction& frac1, const Fraction& frac2) {
    if (frac2.numerator == 0) {
        throw invalid_argument("Division by zero is not allowed!\n");
    }
    int num = frac1.numerator * frac2.denominator;
    int denom = frac1.denominator * frac2.numerator;
    Fraction result{num, denom};
    result = reduce(result);
    return result;
}

Fraction reduce(Fraction& frac) {
    int divisor = gcd(frac.numerator, frac.denominator);
    
    frac.numerator /= divisor;
    frac.denominator /= divisor;
    
    if (frac.denominator < 0) {
        frac.numerator = -frac.numerator;
        frac.denominator = -frac.denominator;
    }
    return frac;
}

int compare(const Fraction& frac1, const Fraction& frac2) {
    int lhs = frac1.numerator * frac2.denominator;
    int rhs = frac2.numerator * frac1.denominator;
    if (lhs == rhs) return 0;
    return (lhs < rhs) ? -1 : 1;
}

bool isPositive(const Fraction& frac) {
    return (frac.numerator > 0 && frac.denominator > 0) || (frac.numerator < 0 && frac.denominator < 0);
}

bool isNegative(const Fraction& frac) {
    return (frac.numerator < 0 && frac.denominator > 0) || (frac.numerator > 0 && frac.denominator < 0);
}

bool isZero(const Fraction& frac) {
    return frac.numerator == 0;
}

int gcd(int a, int b) {
    while (b != 0) {
        int temp = b;
        b = a % b;
        a = temp;
    }
    return a;
}