#include <iostream>
#include <cmath>
#include <algorithm>
using namespace std;

struct Point {
    int x;
    int y;
};

void inputPoint(Point& p);

void outputPoint(Point p);

float distance(Point a, Point b);

float distanceToOx(Point a);

float distanceToOy(Point a);

struct Triangle {
    Point a;
    Point b;
    Point c;
};

void inputTriangle(Triangle& t);

void outputTriangle(Triangle t);

bool isValidTriangle(Triangle t);

void typeOfTriangle(Triangle t);

float perimeter(Triangle t);

float area(Triangle t);

Point centerG(Triangle t);

