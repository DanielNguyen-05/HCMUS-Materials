#include "headerFile.h"

int main() {
    cout << "\n\t WELCOME TO THE PROGRAM\n";
    LinkedListQueue queue;
    int capacity;
    cout << "- Enter the capacity of the queue: ";
    cin >> capacity;
    queue.init(capacity);
    cout << "\nThe queue has been initialized successfully!\n";
    int choice;
    do {
        cout << "\n\t CHOOSE YOUR REQUEST:\n";
        cout << "1. Enqueue\n";
        cout << "2. Dequeue\n";
        cout << "3. Peek\n";
        cout << "4. Check if the queue is empty\n";
        cout << "5. Check if the queue is full\n";
        cout << "6. Clear the queue\n";
        cout << "7. Exit\n";
        cout << "\n- Enter your choice: ";
        cin >> choice;
        cout << "\n";
        switch (choice) {
        case 1:
            int x;
            cout << "- Enter the value to enqueue: ";
            cin >> x;
            queue.enqueue(x);
            cout << "\n=> The value has been enqueued successfully!\n";
            break;
        case 2:
            if (queue.isEmpty()) cout << "\n=> The queue is empty!\n";
            else cout << "=> The value dequeued is: " << queue.dequeue() << "\n";
            break;
        case 3:
            if (queue.isEmpty()) cout << "=> The queue is empty!\n";
            else cout << "=> The value at the front of the queue is: " << queue.peek() << "\n";
            break;
        case 4:
            if (queue.isEmpty()) cout << "=> The queue is empty!\n";
            else cout << "=> The queue is not empty!\n";
            break;
        case 5:
            if (queue.isFull()) cout << "=> The queue is full!\n";
            else cout << "=> The queue is not full!\n";
            break;
        case 6:
            queue.clear();
            cout << "=> The queue has been cleared successfully!\n";
            break;
        case 7:
            cout << "=> Thank you for using the program!\n";
            break;
        default:
            cout << "=> Invalid choice! Please enter a valid choice!\n";
            break;
        }
    } while (choice != 7);
}