#include "headerFile.h"

void inputPoint(Point& p) {
    cout << "- Enter x: ";
    cin >> p.x;
    cout << "- Enter y: ";
    cin >> p.y;
}

void outputPoint(Point p) {
    cout << "(" << p.x << ", " << p.y << ")";
}

float distance(Point a, Point b) {
    return sqrt(pow(a.x - b.x, 2) + pow(a.y - b.y, 2));
}

float distanceToOx(Point a) {
    return abs(a.y);
}

float distanceToOy(Point a) {
    return abs(a.x);
}

void inputTriangle(Triangle& t) {
    cout << "\t INPUT FOR TRIANGLE:\n";
    cout << "Enter the first point of the triangle: " << "\n";
    inputPoint(t.a);
    cout << "Enter the second point of the triangle: " << "\n";
    inputPoint(t.b);
    cout << "Enter the third point of the triangle: " << "\n";
    inputPoint(t.c);
}

void outputTriangle(Triangle t) {
    cout << "=> Your triangle is: ";
    outputPoint(t.a);
    cout << ", ";
    outputPoint(t.b);
    cout << ", ";
    outputPoint(t.c);
}

bool isValidTriangle(Triangle t) {
    return distance(t.a, t.b) + distance(t.b, t.c) > distance(t.a, t.c) &&
           distance(t.a, t.b) + distance(t.a, t.c) > distance(t.b, t.c) &&
           distance(t.a, t.c) + distance(t.b, t.c) > distance(t.a, t.b);
}

void typeOfTriangle(Triangle t) {
    float a = distance(t.a, t.b);
    float b = distance(t.b, t.c);
    float c = distance(t.a, t.c);
    if (a == b && b == c) cout << "=> This is an equilateral triangle." << "\n";
    else if (a == b || b == c || a == c) cout << "=>This is an isosceles triangle." << "\n";
    else if (a * a + b * b == c * c || a * a + c * c == b * b || b * b + c * c == a * a) cout << "=> This is a right triangle." << "\n";
    else if (a * a + b * b < c * c || a * a + c * c < b * b || b * b + c * c < a * a) cout << "=> This is an obtuse triangle." << "\n";
    else cout << "=> This is a acute triangle." << "\n";
}

float perimeter(Triangle t) {
    return distance(t.a, t.b) + distance(t.b, t.c) + distance(t.a, t.c);
}

float area(Triangle t) {
    float p = perimeter(t) / 2;
    return sqrt(p * (p - distance(t.a, t.b)) * (p - distance(t.b, t.c)) * (p - distance(t.a, t.c)));
}

Point centerG(Triangle t) {
    Point center;
    center.x = (t.a.x + t.b.x + t.c.x) / 3;
    center.y = (t.a.y + t.b.y + t.c.y) / 3;
    return center;
}
