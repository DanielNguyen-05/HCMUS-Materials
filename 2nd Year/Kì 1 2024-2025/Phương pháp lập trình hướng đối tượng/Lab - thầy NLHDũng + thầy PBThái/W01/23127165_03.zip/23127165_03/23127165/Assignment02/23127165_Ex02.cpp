#include "headerFile.h"

int main() {
    Point a, b, c;
    Triangle t;
    int choice, choice_1, choice_2;
    float f;
    do {
        cout << "\n\t CHOOSE YOUR TYPE:\n";
        cout << "1. Point\n";
        cout << "2. Triangle\n";
        cout << "3. Exit\n";
        cout << "\n- Enter your choice: ";
        cin >> choice;
        cout << "\n";
        switch (choice) {
        case 1:
            cout << "\t INPUT 2 POINTS:\n";
            cout << "Enter the first point: " << "\n";
            inputPoint(a);
            cout << "Enter the second point: " << "\n";
            inputPoint(b);
            do {
                cout << "\n\t CHOOSE YOUR REQUEST:\n";
                cout << "1. Calculate the distance between 2 points\n";
                cout << "2. Calculate the distance from A(" << a.x << ", " << a.y << ") to Ox and Oy\n";
                cout << "3. Calculate the distance from B(" << b.x << ", " << b.y << ") to Ox and Oy\n";
                cout << "4. Exit\n";
                cout << "\n- Enter your choice: ";
                cin >> choice_1;
                cout << "\n";
                switch (choice_1) {
                case 1:
                    cout << "=> Distance between two points: " << distance(a, b) << "\n";
                    break;
                case 2:
                    cout << "=> Distance from A";
                    outputPoint(a);
                    cout << " to Ox: " << distanceToOx(a) << "\n";
                    cout << "=> Distance from A";
                    outputPoint(a);
                    cout << " to Oy: " << distanceToOy(a) << "\n";
                    break;
                case 3:
                    cout << "=> Distance from B";
                    outputPoint(b);
                    cout << " to Ox: " << distanceToOx(b) << "\n";
                    cout << "=> Distance from B";
                    outputPoint(b);
                    cout << " to Oy: " << distanceToOy(b) << "\n";
                    break;
                case 4:
                    cout << "=> Thank you for using the program!\n";
                    break;
                default:
                    cout << "=> Invalid choice! Please enter a valid choice!\n";
                    break;
                }
            } while (choice_1 != 4);
            break;
        case 2:
            inputTriangle(t);
            do {
                cout << "\n\t CHOOSE YOUR REQUEST:\n";
                cout << "1. Check if three points are a valid triangle\n";
                cout << "2. Determine triangle's type\n";
                cout << "3. Calculate triangle's perimeter\n";
                cout << "4. Calculate triangle's area\n";
                cout << "5. Calculate its center of gravity\n";
                cout << "6. Exit\n";
                cout << "\n- Enter your choice: ";
                cin >> choice_2;
                cout << "\n";
                switch (choice_2) {
                case 1:
                    if (isValidTriangle(t)) cout << "=> Yes, it is a triangle." << "\n";
                    else cout << "=> No, it is not a triangle." << "\n";
                    break;
                case 2:
                    if (!isValidTriangle(t)) {
                        cout << "=> This is not a triangle." << "\n";
                        return -1;
                    }
                    typeOfTriangle(t);
                    break;
                case 3: 
                    if (!isValidTriangle(t)) {
                        cout << "=> This is not a triangle, so cannot calculate its perimeter" << "\n";
                        return -1;
                    }
                    f = perimeter(t);
                    cout << "=> Perimeter: " << f << "\n";
                    break;
                case 4:
                    if (!isValidTriangle(t)) {
                        cout << "=> This is not a triangle, so cannot calculate its area" << "\n";
                        return -1;
                    }
                    f = area(t);
                    cout << "=> Area: " << f << "\n";
                    break;
                case 5:
                    if (!isValidTriangle(t)) {
                        cout << "=> This is not a triangle, so cannot find its center of gravity" << "\n";
                        return -1;
                    }
                    c = centerG(t);
                    cout << "=> Center of gravity: ";
                    outputPoint(c);
                    cout << "\n";
                    break;
                case 6:
                    cout << "=> Thank you for using the program!\n";
                    break;
                default:
                    cout << "=> Invalid choice! Please enter a valid choice!\n";
                    break;
                }
            } while (choice_2 != 6);
            break;
        case 3:
            cout << "=> Thank you for using the program!\n";
            break;
        default:
            cout << "=> Invalid choice! Please enter a valid choice!\n";
            break;
        }
    } while (choice != 3);
    
    return 0;
}