#include <iostream>
#include <stdexcept>
using namespace std;

struct Node {
    int data;
    Node* next;
};

struct LinkedListQueue {
    Node* head;
    Node* tail;
    int capacity; // max number of elements in the queue
    int num; // current number of elements in the queue

    LinkedListQueue();

    void init(int capacity);
    void enqueue(int x);
    int dequeue();
    int peek();
    bool isEmpty();
    bool isFull();
    void clear();
};