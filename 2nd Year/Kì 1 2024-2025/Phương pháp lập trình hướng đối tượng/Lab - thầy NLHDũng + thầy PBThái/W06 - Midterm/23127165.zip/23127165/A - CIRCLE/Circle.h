#pragma once
#include <iostream>
#include <sstream>
using namespace std;

class Circle {
private:
    float radius;
public:
    Circle();
    Circle(float r);

    float getRadius();
    void setRadius(float r);
};