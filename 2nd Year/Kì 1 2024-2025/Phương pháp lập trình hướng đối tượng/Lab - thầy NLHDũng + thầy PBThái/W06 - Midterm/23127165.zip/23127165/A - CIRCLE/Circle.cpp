#include "Circle.h"

Circle::Circle() {
    radius = 1;
}

Circle::Circle(float r) {
    if (r <= 0) __throw_invalid_argument("Radius must be positive");
    radius = r;
}

float Circle::getRadius() {
    return radius;
}

void Circle::setRadius(float r) {
    if (r < 0) __throw_invalid_argument("Radius must be positive");
    radius = r;
}

