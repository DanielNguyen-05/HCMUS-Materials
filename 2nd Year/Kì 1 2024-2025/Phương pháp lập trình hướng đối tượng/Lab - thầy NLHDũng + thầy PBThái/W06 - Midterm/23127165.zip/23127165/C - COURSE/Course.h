#pragma once
#include "Student.h"
#include <vector>

class Course {
private:
    string courseName;
    string courseCode;
    int credits;
    vector<Student> enrolledStudents;
public:
    Course();
    Course(string name, string code, int credits);

    void addStudent(const Student& student);
    void removeStudent(const string& studentID);

    void displayCourseInfo();

    int getTotalStudents();
};