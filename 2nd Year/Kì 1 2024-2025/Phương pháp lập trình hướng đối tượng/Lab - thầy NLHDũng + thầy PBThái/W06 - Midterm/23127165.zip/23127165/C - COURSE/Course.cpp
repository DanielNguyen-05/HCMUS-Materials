#include "Course.h"

Course::Course() {
    courseName = "";
    courseCode = "";
    credits = 0;
}

Course::Course(string name, string code, int credits) {
    courseName = name;
    courseCode = code;
    if (credits < 0) __throw_invalid_argument("Credits must be positive");
    this->credits = credits;
}

void Course::addStudent(const Student& student) {
    enrolledStudents.push_back(student);
}

void Course::removeStudent(const string& studentID) {
    for (int i = 0; i < enrolledStudents.size(); i++) {
        if (enrolledStudents[i].getStudentID() == studentID) {
            enrolledStudents.erase(enrolledStudents.begin() + i);
            break;
        }
    }
}

void Course::displayCourseInfo() {
    cout << "Course Name: " << courseName << "\n"
        << "Course Code: " << courseCode << "\n"
        << "Credits: " << credits << "\n"
        << "Total Students: " << getTotalStudents() << "\n"
        << "Enrolled Students:\n";
    for (int i = 0; i < enrolledStudents.size(); i++) {
        enrolledStudents[i].displayInfo();
    }
}

int Course::getTotalStudents() {
    return enrolledStudents.size();
}
