#pragma once
#include <iostream>
#include <sstream>
#include <string>
#include <iomanip>
using namespace std;

class Student {
private:
    string fullName;
    string studentID;
    int age;
    string address;
    float gpa;
public:
    Student();
    Student(string name, string id, int age, string address, float gpa);

    void displayInfo();

    string getFullName();
    void setFullName(string name);

    string getStudentID();
    void setStudentID(string id);

    int getAge();
    void setAge(int age);

    string getAddress();
    void setAddress(string address);

    float getGPA();
    void setGPA(float gpa);
};