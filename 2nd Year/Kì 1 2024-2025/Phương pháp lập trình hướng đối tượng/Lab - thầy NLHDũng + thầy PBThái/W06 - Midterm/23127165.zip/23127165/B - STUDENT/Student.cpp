#include "Student.h"

Student::Student() {
    fullName = "";
    studentID = "";
    age = 0;
    address = "";
    gpa = 0;
}

Student::Student(string name, string id, int age, string address, float gpa) {
    fullName = name;
    studentID = id;
    this->age = age;
    this->address = address;
    this->gpa = gpa;
}

void Student::displayInfo() {
    cout << "Name: " << fullName << "\n";
    cout << "Student ID: " << studentID << "\n";
    cout << "Age: " << age << "\n";
    cout << "Address: " << address << "\n";
    cout << "GPA: " << fixed << setprecision(3) << gpa << "\n";
}

string Student::getFullName() {
    return fullName;
}

void Student::setFullName(string name) {
    fullName = name;
}

string Student::getStudentID() {
    return studentID;
}

void Student::setStudentID(string id) {
    studentID = id;
}

int Student::getAge() {
    return age;
}

void Student::setAge(int age) {
    if (age < 0) __throw_invalid_argument("Age must be positive");
    this->age = age;
}

string Student::getAddress() {
    return address;
}

void Student::setAddress(string address) {
    this->address = address;
}

float Student::getGPA() {
    return gpa;
}

void Student::setGPA(float gpa) {
    if (gpa < 0) __throw_invalid_argument("GPA must be positive");
    this->gpa = gpa;
}